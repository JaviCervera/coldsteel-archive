int cam;
int map;
int skydome;
int particles;
int mx, my, mxs, mys;

void csInit()
{
	// Device
	DeviceOpen(1024, 768, 32, DF_FULLSCREEN | DF_OPENGL | DF_ANTIALIAS, 0);
	DeviceCaption("ColdSteel Temple01 Example");
	MouseHide(1);

	// Ambient light
	SceneAmbient(GetColor(255, 255, 255, 255));

	// Fog
	SceneFog(GetColor(0,20,20,120), 0, 12500);

	// Load skybox
	int top = TextureLoad("media/skybox/rocky_up.jpg");
	int bottom = TextureLoad("media/skybox/rocky_dn.jpg");
	int left = TextureLoad("media/skybox/rocky_lf.jpg");
	int right = TextureLoad("media/skybox/rocky_rt.jpg");
	int front = TextureLoad("media/skybox/rocky_ft.jpg");
	int back = TextureLoad("media/skybox/rocky_bk.jpg");
	SceneSkybox(top, bottom, left, right, front, back);

	// Load map
	SceneTexturePath("media/maps/temple01/");
	int mesh = MeshLoad("media/maps/temple01/temple01.my3d");
	map = MeshOctreeNode(mesh, 0, CI_OCTREE, 0);
	MeshFree(mesh);

	// Load skydome
	int texture = TextureLoad("media/maps/temple01/clouds.jpg");
	mesh = MeshLoad("media/maps/temple01/skydome.my3d");
	skydome = MeshNode(mesh, 0, 0, 0);
	NodeSetMaterialFast(skydome, MT_ADD, MF_FULLBRIGHT, texture, 0);
	MeshFree(mesh);

	// Load particles
	texture = TextureLoad("media/textures/particle_white.bmp");
	int emitter = EmitterCreate();
	EmitterType(emitter, ET_BOX);
	EmitterBox(emitter, 14, 1, 14);
	EmitterDirection(emitter, 0, 0.03, 0);
	EmitterRate(emitter, 60, 200);
	EmitterColor(emitter, GetColor(0,255,255,100), GetColor(0,0,255,0));
	EmitterLifeTime(emitter, 100, 3400);
	EmitterMaxAngle(emitter, 108);
	particles = ParticlesNode(emitter, 0);
	ParticlesSize(particles, 300, 300);
	ParticlesAddFadeOutAffector(particles, 0, 1000);
	ParticlesAddGravityAffector(particles, 0, 0.3, 0, 2400);
	NodeSetMaterialFast(particles, MT_ADD, MF_FULLBRIGHT, texture, 0);
	NodePosition(particles, -5200, 850, 2000);
	NodeScale(particles, 50, 50, 50);

	// Create sun billboard
	int sun = BillboardNode(0);
	BillboardResize(sun, 30000, 30000);
	NodeSetMaterialFast(sun, MT_ADD, MF_FULLBRIGHT, texture, 0);
	NodePosition(sun, 25000, 25000, 0);

	// Create camera
	cam = CameraNode(0);
	CameraRange(cam, 1, 50000);
	CameraFov(cam, 1.1);
	NodePosition(cam, 240, 305, 2150);
	NodeRotate(cam, 0, 90, 0);
	NodeCollision(cam, map, 32, 128, 32);

	// Move mouse to screen center
	MousePosition(DeviceWidth()/2, DeviceHeight()/2);
	mx = MouseX();
	my = MouseY();
	mxs = 0;
	mys = 0;
}

void csFinish()
{
	DeviceClose();
}

void csInput(int source, int data1, int data2)
{
	// I am not capturing input this way, I am doing it in csFrame() in this example
}

int csFrame(int frame_time)
{
	float elapsed = frame_time / 1000.0;

	// Check if we must exit
	if (DeviceClosed() == 1)				return 1;
	if (KeyHit(KEY_ESCAPE) == 1)		return 1;

	// Get mouse movement
	mxs = MouseX() - mx;
	mys = MouseY() - my;
	MousePosition(DeviceWidth()/2, DeviceHeight()/2);
	mx = MouseX(); my = MouseY();

	// Rotate camera
	float pitch = NodePitch(cam) + (mys * 0.4);
	if (pitch < -80)	pitch = -80;
	if (pitch > 80)		pitch = 80;
	NodeRotate(cam, pitch, NodeYaw(cam) + (mxs * 0.4), 0);

	// Move camera
	if (KeyDown(KEY_UP) == 1)		NodeMove(cam, 0, 0, 512 * elapsed);
	if (KeyDown(KEY_DOWN) == 1)	NodeMove(cam, 0, 0, -512 * elapsed);
	if (KeyDown(KEY_LEFT) == 1)	NodeMove(cam, -512 * elapsed, 0, 0);
	if (KeyDown(KEY_RIGHT) == 1)	NodeMove(cam, 512 * elapsed, 0, 0);
	NodePosition(cam, NodeX(cam,0), NodeY(cam,0) - (512 * elapsed), NodeZ(cam,0));

	// Rotate skydome
	NodeTurn(skydome, 0, 3 * elapsed, 0);

	SceneBegin(CF_BACKBUFFER | CF_ZBUFFER, GetColor(0, 0, 0, 0));
	SceneRender(cam);
	SceneEnd();

	return 0;
}