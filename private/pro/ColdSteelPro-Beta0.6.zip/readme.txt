This beta version of ColdSteel is for testing purposes
only. Redistribution of this package or any products made
with it is not allowed.

ColdSteel has been programmed by Javier "Jedive" San Juan.

The author of the map used in the example is �lvaro F. Celis.

There's a few functions I haven't added to the docs yet:

float MathFloor(float val)
float MathCeil(float val)
float MathAbs(float val)
float MathSqr(float val)
float MathSin(float val)
float MathCos(float val)
float MathTan(float val)
float MathASin(float val)
float MathACos(float val)
float MathATan(float val)
float MathATan2(float x, float y)
float MathExp(float val)
float MathLog(float val)
float MathLog10(float val)
int MathRand(int min, int max)
void MathRandSeed(int seed)

int StringToInt(string str)
float StringToFloat(string str)
string StringFromInt(int number)
string StringFromFloat(float number)
string StringLeft(string str, int num)
string StringRight(string str, int num)
string StringMid(string str, int pos, int num)
string StringReplace(string str, string find, string replace)
int StringFind(string str, string find, int offset)
string StringUpper(string str)
string StringLower(string str)
string StringChar(int ascii)
int StringAscii(string str)
int StringLen(string str)
string StringField(string str, string delimiter, int index)

www.coldsteelengine.com