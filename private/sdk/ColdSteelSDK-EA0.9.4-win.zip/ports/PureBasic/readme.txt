PureBasic import files for the ColdSteel SDK.

Usage:

1) Include "coldsteel.pbi" file in all your programs
 That's all!

Remember to always have the "coldsteel.dll" file together with the exe of your programs!

Example program:

XIncludeFile "coldsteel.pbi"

csCoreInit()
csDisplayOpen(800, 600, 32, 0, 0)
csDisplayClose()
csCoreFinish()