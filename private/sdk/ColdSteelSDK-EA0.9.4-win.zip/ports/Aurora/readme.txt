Aurora import files for the ColdSteel SDK.

Usage:

1) Copy "coldsteel.inc" to the "bin" folder of Aurora.
2) Open the IDE, select "Tools -> Create Import Library", and select "coldsteel.dll".
 That's all!

Remember to always have the "coldsteel.dll" file together with the exe of your programs!

Example program:

global sub main()
{ 
	csCoreInit();
	csDisplayOpen(800, 600, 32, 0, 0) ;
	csDisplayClose();
	csCoreFinish();
}