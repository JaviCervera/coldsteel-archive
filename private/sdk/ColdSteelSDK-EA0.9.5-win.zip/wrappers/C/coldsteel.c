#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "coldsteel.h"

typedef void (_stdcall* csCoreInitPtr)();
typedef void (_stdcall* csCoreFinishPtr)();
typedef void (_stdcall* csCoreMessagePtr)(const char*, int);
typedef void (_stdcall* csListenerUpdatePtr)(int);
typedef void (_stdcall* csSoundSetMasterVolumePtr)(float);
typedef float (_stdcall* csSoundGetMasterVolumePtr)(float);
typedef int (_stdcall* csSoundLoadPtr)(const char*);
typedef void (_stdcall* csSoundFreePtr)(int);
typedef int (_stdcall* csSoundPlay2DPtr)(int, int);
typedef int (_stdcall* csSoundPlay3DPtr)(int, float, float, float, int);
typedef int (_stdcall* csSoundIsPlayingPtr)(int);
typedef int (_stdcall* csChannelPausedPtr)(int);
typedef int (_stdcall* csChannelFinishedPtr)(int);
typedef int (_stdcall* csChannelLoopedPtr)(int);
typedef float (_stdcall* csChannelGetMinDistancePtr)(int);
typedef float (_stdcall* csChannelGetMaxDistancePtr)(int);
typedef float (_stdcall* csChannelGetPanPtr)(int);
typedef int (_stdcall* csChannelGetPlayPositionPtr)(int);
typedef float (_stdcall* csChannelXPtr)(int);
typedef float (_stdcall* csChannelYPtr)(int);
typedef float (_stdcall* csChannelZPtr)(int);
typedef float (_stdcall* csChannelGetVolumePtr)(int);
typedef void (_stdcall* csChannelPausePtr)(int);
typedef void (_stdcall* csChannelResumePtr)(int);
typedef void (_stdcall* csChannelSetDistancePtr)(int, float, float);
typedef void (_stdcall* csChannelSetPanPtr)(int, float);
typedef void (_stdcall* csChannelSetPositionPtr)(int, float, float, float);
typedef void (_stdcall* csChannelSetVolumePtr)(int, float);
typedef void (_stdcall* csChannelStopPtr)(int);
typedef int (_stdcall* csBillboardNodePtr)(int);
typedef void (_stdcall* csBillboardResizePtr)(int, float, float);
typedef float (_stdcall* csBillboardWidthPtr)(int);
typedef float (_stdcall* csBillboardHeightPtr)(int);
typedef int (_stdcall* csCameraNodePtr)(int);
typedef void (_stdcall* csCameraViewportPtr)(int, float, float, float, float);
typedef void (_stdcall* csCameraRangePtr)(int, float, float);
typedef void (_stdcall* csCameraFovPtr)(int, float);
typedef void (_stdcall* csCameraAspectRatioPtr)(int, float);
typedef void (_stdcall* csCameraProjectionPtr)(int, float, float, float, float, int);
typedef void (_stdcall* csCameraLinePtr)(int, int, int, int, int);
typedef int (_stdcall* csCameraPickNodePtr)(int, int, int, int);
typedef void (_stdcall* csCameraToScreenPtr)(int, float, float, float, int);
typedef void (_stdcall* csCameraRenderTargetPtr)(int, int);
typedef void (_stdcall* csCameraClearFlagsPtr)(int, int, int);
typedef void (_stdcall* csCollisionSlidePtr)(int, float, float, float, float, float, float, float, float, float, int, int, int, int);
typedef int (_stdcall* csCollisionLinePickPtr)(int, float, float, float, float, float, float, int, int, int, int);
typedef int (_stdcall* csCollisionLineNodePtr)(float, float, float, float, float, float);
typedef void (_stdcall* csPackageAddPtr)(const char*);
typedef int (_stdcall* csDirListPtr)(const char*);
typedef void (_stdcall* csDirClosePtr)(int);
typedef int (_stdcall* csDirFileCountPtr)(int);
typedef const char* (_stdcall* csDirFileNamePtr)(int, int);
typedef int (_stdcall* csDirFileIsDirPtr)(int, int);
typedef void (_stdcall* csDisplayOpenPtr)(int, int, int, int, int);
typedef void (_stdcall* csDisplayClosePtr)();
typedef void (_stdcall* csDisplayCaptionPtr)(const char*);
typedef int (_stdcall* csDisplayClosedPtr)();
typedef int (_stdcall* csDisplayWidthPtr)();
typedef int (_stdcall* csDisplayHeightPtr)();
typedef int (_stdcall* csDisplayFpsPtr)();
typedef int (_stdcall* csDisplayFeaturePtr)(int);
typedef void (_stdcall* csDisplayResizePtr)(int, int);
typedef int (_stdcall* csDisplayActivePtr)();
typedef void (_stdcall* csDisplayScreenshotPtr)(const char*);
typedef int (_stdcall* csGetColorPtr)(int, int, int, int);
typedef int (_stdcall* csGetRedPtr)(int);
typedef int (_stdcall* csGetGreenPtr)(int);
typedef int (_stdcall* csGetBluePtr)(int);
typedef int (_stdcall* csGetAlphaPtr)(int);
typedef void (_stdcall* csSetColorPtr)(int);
typedef void (_stdcall* csViewportPtr)(int, int, int, int);
typedef void (_stdcall* csDrawLinePtr)(int, int, int, int);
typedef void (_stdcall* csDrawRectPtr)(int, int, int, int);
typedef void (_stdcall* csDrawTexturePtr)(int, int, int);
typedef void (_stdcall* csDrawTextPtr)(int, const char*, int, int);
typedef int (_stdcall* csTextWidthPtr)(int, const char*);
typedef int (_stdcall* csTextHeightPtr)(int, const char*);
typedef int (_stdcall* csEffectRegisterPtr)(const char*, int);
typedef int (_stdcall* csEffectRegisterFilePtr)(const char*, int);
typedef void (_stdcall* csEffectSetTechniquePtr)(int, const char*);
typedef void (_stdcall* csEffectSetTexturePtr)(int, const char*, int);
typedef void (_stdcall* csEffectSetBoolPtr)(int, const char*, int);
typedef void (_stdcall* csEffectSetIntPtr)(int, const char*, int);
typedef void (_stdcall* csEffectSetFloatPtr)(int, const char*, float);
typedef void (_stdcall* csEffectSetVectorPtr)(int, const char*, int);
typedef void (_stdcall* csEffectSetMatrixPtr)(int, const char*, int);
typedef int (_stdcall* csEmitterNodePtr)(int, int);
typedef void (_stdcall* csEmitterAddFadeOutAffectorPtr)(int, int, int);
typedef void (_stdcall* csEmitterAddGravityAffectorPtr)(int, float, float, float, int);
typedef void (_stdcall* csEmitterRemoveAffectorsPtr)(int);
typedef int (_stdcall* csEventGetPtr)();
typedef int (_stdcall* csEventPollPtr)();
typedef void (_stdcall* csEventPostPtr)(int, int, int, float, float, float, const char*);
typedef int (_stdcall* csEventIdPtr)();
typedef int (_stdcall* csEventFromPtr)();
typedef int (_stdcall* csEventToPtr)();
typedef float (_stdcall* csEventAPtr)();
typedef float (_stdcall* csEventBPtr)();
typedef float (_stdcall* csEventCPtr)();
typedef const char* (_stdcall* csEventDataPtr)();
typedef int (_stdcall* csFileReadPtr)(const char*);
typedef int (_stdcall* csFileWritePtr)(const char*);
typedef void (_stdcall* csFileClosePtr)(int);
typedef int (_stdcall* csFileSizePtr)(int);
typedef int (_stdcall* csFilePosPtr)(int);
typedef void (_stdcall* csFileSeekPtr)(int, int, int);
typedef int (_stdcall* csFileReadBytePtr)(int);
typedef int (_stdcall* csFileReadShortPtr)(int);
typedef int (_stdcall* csFileReadIntPtr)(int);
typedef float (_stdcall* csFileReadFloatPtr)(int);
typedef const char* (_stdcall* csFileReadStringPtr)(int);
typedef void (_stdcall* csFileReadBytesPtr)(int, int, int);
typedef void (_stdcall* csFileWriteBytePtr)(int, int);
typedef void (_stdcall* csFileWriteShortPtr)(int, int);
typedef void (_stdcall* csFileWriteIntPtr)(int, int);
typedef void (_stdcall* csFileWriteFloatPtr)(int, float);
typedef void (_stdcall* csFileWriteStringPtr)(int, const char*);
typedef void (_stdcall* csFileWriteBytesPtr)(int, int, int);
typedef const char* (_stdcall* csFileGetExtPtr)(const char*);
typedef const char* (_stdcall* csFileGetDirPtr)(const char*);
typedef const char* (_stdcall* csFileStripExtPtr)(const char*);
typedef const char* (_stdcall* csFileStripDirPtr)(const char*);
typedef int (_stdcall* csFontLoadPtr)(const char*);
typedef void (_stdcall* csFontFreePtr)(int);
typedef void (_stdcall* csMousePositionPtr)(int, int);
typedef void (_stdcall* csMouseHidePtr)(int);
typedef int (_stdcall* csMouseXPtr)();
typedef int (_stdcall* csMouseYPtr)();
typedef int (_stdcall* csMouseHitPtr)(int);
typedef int (_stdcall* csMouseDownPtr)(int);
typedef int (_stdcall* csMouseGetPtr)();
typedef int (_stdcall* csMouseReleasedPtr)();
typedef int (_stdcall* csKeyHitPtr)(int);
typedef int (_stdcall* csKeyDownPtr)(int);
typedef int (_stdcall* csKeyGetPtr)();
typedef int (_stdcall* csKeyReleasedPtr)();
typedef const char* (_stdcall* csJoyNamePtr)(int);
typedef int (_stdcall* csJoyButtonPtr)(int, int);
typedef float (_stdcall* csJoyAxisPtr)(int, int);
typedef int (_stdcall* csJoyNumAxesPtr)(int);
typedef int (_stdcall* csLightNodePtr)(int);
typedef void (_stdcall* csLightTypePtr)(int, int);
typedef void (_stdcall* csLightRadiusPtr)(int, float);
typedef void (_stdcall* csLightAmbientPtr)(int, int);
typedef void (_stdcall* csLightDiffusePtr)(int, int);
typedef void (_stdcall* csLightSpecularPtr)(int, int);
typedef int (_stdcall* csMaterialCreatePtr)(const char*);
typedef int (_stdcall* csMaterialLoadPtr)(const char*);
typedef void (_stdcall* csMaterialSavePtr)(int, const char*, const char*);
typedef void (_stdcall* csMaterialFreePtr)(int);
typedef int (_stdcall* csMaterialFindPtr)(const char*);
typedef void (_stdcall* csMaterialSetTypePtr)(int, int);
typedef void (_stdcall* csMaterialSetFlagsPtr)(int, int);
typedef void (_stdcall* csMaterialSetTexturePtr)(int, int, int);
typedef void (_stdcall* csMaterialSetAmbientPtr)(int, int);
typedef void (_stdcall* csMaterialSetDiffusePtr)(int, int);
typedef void (_stdcall* csMaterialSetEmissivePtr)(int, int);
typedef void (_stdcall* csMaterialSetSpecularPtr)(int, int);
typedef void (_stdcall* csMaterialSetShininessPtr)(int, float);
typedef void (_stdcall* csMaterialSetParamPtr)(int, float);
typedef const char* (_stdcall* csMaterialGetNamePtr)(int);
typedef int (_stdcall* csMaterialGetTypePtr)(int);
typedef int (_stdcall* csMaterialGetFlagsPtr)(int);
typedef int (_stdcall* csMaterialGetTexturePtr)(int, int);
typedef int (_stdcall* csMaterialGetAmbientPtr)(int);
typedef int (_stdcall* csMaterialGetDiffusePtr)(int);
typedef int (_stdcall* csMaterialGetEmissivePtr)(int);
typedef int (_stdcall* csMaterialGetSpecularPtr)(int);
typedef float (_stdcall* csMaterialGetShininessPtr)(int);
typedef float (_stdcall* csMaterialGetParamPtr)(int);
typedef float (_stdcall* csMathFloorPtr)(float);
typedef float (_stdcall* csMathCeilPtr)(float);
typedef float (_stdcall* csMathAbsPtr)(float);
typedef float (_stdcall* csMathSqrPtr)(float);
typedef float (_stdcall* csMathSinPtr)(float);
typedef float (_stdcall* csMathCosPtr)(float);
typedef float (_stdcall* csMathTanPtr)(float);
typedef float (_stdcall* csMathASinPtr)(float);
typedef float (_stdcall* csMathACosPtr)(float);
typedef float (_stdcall* csMathATanPtr)(float);
typedef float (_stdcall* csMathATan2Ptr)(float, float);
typedef float (_stdcall* csMathExpPtr)(float);
typedef float (_stdcall* csMathLogPtr)(float);
typedef float (_stdcall* csMathLog10Ptr)(float);
typedef int (_stdcall* csMathRandPtr)(int, int);
typedef void (_stdcall* csMathRandSeedPtr)(int);
typedef int (_stdcall* csMatrixCreatePtr)();
typedef void (_stdcall* csMatrixFreePtr)(int);
typedef void (_stdcall* csMatrixAddPtr)(int, int);
typedef void (_stdcall* csMatrixCopyPtr)(int, int);
typedef void (_stdcall* csMatrixDivPtr)(int, int);
typedef float (_stdcall* csMatrixElementPtr)(int, int, int);
typedef int (_stdcall* csMatrixEqualPtr)(int, int);
typedef void (_stdcall* csMatrixGetRotationPtr)(int, int);
typedef void (_stdcall* csMatrixGetTranslationPtr)(int, int);
typedef void (_stdcall* csMatrixIdentityPtr)(int);
typedef void (_stdcall* csMatrixInterpolatePtr)(int, int, float);
typedef int (_stdcall* csMatrixInvertPtr)(int);
typedef void (_stdcall* csMatrixMulPtr)(int, int);
typedef void (_stdcall* csMatrixSetPtr)(int, int, int, float);
typedef void (_stdcall* csMatrixSetRotationPtr)(int, int);
typedef void (_stdcall* csMatrixSetScalePtr)(int, int);
typedef void (_stdcall* csMatrixSetTranslationPtr)(int, int);
typedef void (_stdcall* csMatrixSubPtr)(int, int);
typedef void (_stdcall* csMatrixTransposePtr)(int);
typedef int (_stdcall* csMeshLoadPtr)(const char*);
typedef int (_stdcall* csMeshTerrainLoadPtr)(const char*);
typedef void (_stdcall* csMeshFreePtr)(int);
typedef int (_stdcall* csMeshNodePtr)(int, int, int, int);
typedef int (_stdcall* csMeshOctreeNodePtr)(int, int, int, int);
typedef void (_stdcall* csMeshScalePtr)(int, float, float, float);
typedef void (_stdcall* csMeshFlipPtr)(int);
typedef void (_stdcall* csMeshUpdateNormalsPtr)(int);
typedef void (_stdcall* csMeshVerticesColorPtr)(int, int, int);
typedef void (_stdcall* csMeshPlanarMappingPtr)(int, float);
typedef float (_stdcall* csMeshWidthPtr)(int);
typedef float (_stdcall* csMeshHeightPtr)(int);
typedef float (_stdcall* csMeshDepthPtr)(int);
typedef int (_stdcall* csNodeEmptyPtr)(int);
typedef void (_stdcall* csNodeFreePtr)(int);
typedef int (_stdcall* csNodeTypePtr)(int);
typedef void (_stdcall* csNodeSetNamePtr)(int, const char*);
typedef const char* (_stdcall* csNodeGetNamePtr)(int);
typedef void (_stdcall* csNodePositionPtr)(int, float, float, float);
typedef void (_stdcall* csNodeMovePtr)(int, float, float, float);
typedef void (_stdcall* csNodeRotatePtr)(int, float, float, float);
typedef void (_stdcall* csNodeTurnPtr)(int, float, float, float);
typedef void (_stdcall* csNodeScalePtr)(int, float, float, float);
typedef float (_stdcall* csNodeXPtr)(int, int);
typedef float (_stdcall* csNodeYPtr)(int, int);
typedef float (_stdcall* csNodeZPtr)(int, int);
typedef float (_stdcall* csNodePitchPtr)(int);
typedef float (_stdcall* csNodeYawPtr)(int);
typedef float (_stdcall* csNodeRollPtr)(int);
typedef float (_stdcall* csNodeScaleXPtr)(int);
typedef float (_stdcall* csNodeScaleYPtr)(int);
typedef float (_stdcall* csNodeScaleZPtr)(int);
typedef float (_stdcall* csNodeWidthPtr)(int);
typedef float (_stdcall* csNodeHeightPtr)(int);
typedef float (_stdcall* csNodeDepthPtr)(int);
typedef void (_stdcall* csNodeCastShadowPtr)(int, int);
typedef void (_stdcall* csNodeHidePtr)(int, int);
typedef int (_stdcall* csNodeMaterialsPtr)(int);
typedef int (_stdcall* csNodeGetMaterialPtr)(int, int);
typedef void (_stdcall* csNodeSetMaterialPtr)(int, int, int);
typedef void (_stdcall* csNodeSetMaterialFastPtr)(int, int, int, int, int, int);
typedef void (_stdcall* csNodeSetMaterialFlagPtr)(int, int, int, int);
typedef void (_stdcall* csNodeSetPickGroupPtr)(int, int);
typedef void (_stdcall* csNodeSetPropertyPtr)(int, const char*, const char*);
typedef int (_stdcall* csNodePropertiesPtr)(int);
typedef int (_stdcall* csNodeFindPropertyPtr)(int, const char*);
typedef const char* (_stdcall* csNodePropertyNamePtr)(int, int);
typedef const char* (_stdcall* csNodePropertyValuePtr)(int, int);
typedef void (_stdcall* csNodeRemovePropertyPtr)(int, int);
typedef void (_stdcall* csNodeSetParentPtr)(int, int);
typedef int (_stdcall* csNodeGetParentPtr)(int);
typedef int (_stdcall* csNodeChildrenPtr)(int);
typedef int (_stdcall* csNodeChildPtr)(int, int);
typedef int (_stdcall* csNodeFindChildPtr)(int, const char*, int);
typedef void (_stdcall* csNodeSpeedPtr)(int, float);
typedef void (_stdcall* csNodeLoopPtr)(int, int);
typedef void (_stdcall* csNodeSetFramePtr)(int, int, int);
typedef int (_stdcall* csNodeGetFramePtr)(int);
typedef void (_stdcall* csNodeAttachToBonePtr)(int, int, const char*);
typedef void (_stdcall* csNodeLookAtPtr)(int, float, float, float);
typedef int (_stdcall* csParticleDataCreatePtr)(const char*);
typedef int (_stdcall* csParticleDataLoadPtr)(const char*);
typedef void (_stdcall* csParticleDataSavePtr)(int, const char*);
typedef void (_stdcall* csParticleDataFreePtr)(int);
typedef int (_stdcall* csParticleDataFindPtr)(const char*);
typedef void (_stdcall* csParticleDataSetMaterialPtr)(int, const char*);
typedef void (_stdcall* csParticleDataSetTypePtr)(int, int);
typedef void (_stdcall* csParticleDataSetBoxPtr)(int, float, float, float);
typedef void (_stdcall* csParticleDataSetDirectionPtr)(int, float, float, float);
typedef void (_stdcall* csParticleDataSetRatePtr)(int, int, int);
typedef void (_stdcall* csParticleDataSetColorPtr)(int, int, int);
typedef void (_stdcall* csParticleDataSetLifeTimePtr)(int, int, int);
typedef void (_stdcall* csParticleDataSetMaxAnglePtr)(int, int);
typedef void (_stdcall* csParticleDataSetSizePtr)(int, float, float);
typedef void (_stdcall* csParticleDataAddFadeOutAffectorPtr)(int, int, int);
typedef void (_stdcall* csParticleDataAddGravityAffectorPtr)(int, float, float, float, int);
typedef const char* (_stdcall* csParticleDataGetNamePtr)(int);
typedef const char* (_stdcall* csParticleDataGetMaterialPtr)(int);
typedef int (_stdcall* csParticleDataGetTypePtr)(int);
typedef float (_stdcall* csParticleDataGetBoxWidthPtr)(int);
typedef float (_stdcall* csParticleDataGetBoxHeightPtr)(int);
typedef float (_stdcall* csParticleDataGetBoxDepthPtr)(int);
typedef float (_stdcall* csParticleDataGetDirectionXPtr)(int);
typedef float (_stdcall* csParticleDataGetDirectionYPtr)(int);
typedef float (_stdcall* csParticleDataGetDirectionZPtr)(int);
typedef int (_stdcall* csParticleDataGetMinRatePtr)(int);
typedef int (_stdcall* csParticleDataGetMaxRatePtr)(int);
typedef int (_stdcall* csParticleDataGetMinColorPtr)(int);
typedef int (_stdcall* csParticleDataGetMaxColorPtr)(int);
typedef int (_stdcall* csParticleDataGetMinLifeTimePtr)(int);
typedef int (_stdcall* csParticleDataGetMaxLifeTimePtr)(int);
typedef int (_stdcall* csParticleDataGetMaxAnglePtr)(int);
typedef float (_stdcall* csParticleDataGetWidthPtr)(int);
typedef float (_stdcall* csParticleDataGetHeightPtr)(int);
typedef int (_stdcall* csParticleDataAffectorsPtr)(int);
typedef int (_stdcall* csParticleDataGetAffectorTypePtr)(int, int);
typedef int (_stdcall* csParticleDataGetAffectorColorPtr)(int, int);
typedef int (_stdcall* csParticleDataGetAffectorTimePtr)(int, int);
typedef float (_stdcall* csParticleDataGetAffectorGravityXPtr)(int, int);
typedef float (_stdcall* csParticleDataGetAffectorGravityYPtr)(int, int);
typedef float (_stdcall* csParticleDataGetAffectorGravityZPtr)(int, int);
typedef void (_stdcall* csSceneBeginPtr)();
typedef void (_stdcall* csSceneEndPtr)();
typedef void (_stdcall* csSceneRenderPtr)(int);
typedef void (_stdcall* csSceneAmbientPtr)(int);
typedef void (_stdcall* csSceneShadowPtr)(int);
typedef void (_stdcall* csSceneFogPtr)(int, float, float);
typedef void (_stdcall* csSceneSkyboxPtr)(int, int, int, int, int, int);
typedef void (_stdcall* csSceneSkydomePtr)(int, float, float, float, float);
typedef void (_stdcall* csSceneTransformationPtr)(int, int);
typedef int (_stdcall* csShaderRegisterPtr)(const char*, const char*, int, const char*, const char*, int, int);
typedef int (_stdcall* csShaderRegisterFilePtr)(const char*, const char*, int, const char*, const char*, int, int);
typedef int (_stdcall* csShaderAsmRegisterPtr)(const char*, const char*, int);
typedef int (_stdcall* csShaderAsmRegisterFilePtr)(const char*, const char*, int);
typedef void (_stdcall* csShaderPixelConstantPtr)(int, const char*, int, int, int);
typedef void (_stdcall* csShaderVertexConstantPtr)(int, const char*, int, int, int);
typedef int (_stdcall* csStringToIntPtr)(const char*);
typedef float (_stdcall* csStringToFloatPtr)(const char*);
typedef const char* (_stdcall* csStringFromIntPtr)(int);
typedef const char* (_stdcall* csStringFromFloatPtr)(float);
typedef const char* (_stdcall* csStringLeftPtr)(const char*, int);
typedef const char* (_stdcall* csStringRightPtr)(const char*, int);
typedef const char* (_stdcall* csStringMidPtr)(const char*, int, int);
typedef const char* (_stdcall* csStringReplacePtr)(const char*, const char*, const char*);
typedef int (_stdcall* csStringFindPtr)(const char*, const char*, int);
typedef const char* (_stdcall* csStringUpperPtr)(const char*);
typedef const char* (_stdcall* csStringLowerPtr)(const char*);
typedef const char* (_stdcall* csStringTrimPtr)(const char*);
typedef const char* (_stdcall* csStringCharPtr)(int);
typedef int (_stdcall* csStringAsciiPtr)(const char*);
typedef int (_stdcall* csStringLenPtr)(const char*);
typedef const char* (_stdcall* csStringFieldPtr)(const char*, const char*, int);
typedef int (_stdcall* csTerrainNodePtr)(const char*, int, float, float, float, int);
typedef void (_stdcall* csTerrainScaleTexturePtr)(int, float, float);
typedef int (_stdcall* csTextureCreatePtr)(int, int);
typedef int (_stdcall* csTextureTargetCreatePtr)(int, int);
typedef int (_stdcall* csTextureLoadPtr)(const char*, int);
typedef void (_stdcall* csTextureFreePtr)(int);
typedef const char* (_stdcall* csTextureFilePtr)(int);
typedef int (_stdcall* csTextureWidthPtr)(int, int);
typedef int (_stdcall* csTextureHeightPtr)(int, int);
typedef int (_stdcall* csTextureLockPtr)(int);
typedef void (_stdcall* csTextureUnlockPtr)(int);
typedef void (_stdcall* csTextureColorKeyPtr)(int, int);
typedef void (_stdcall* csTextureNormalizePtr)(int, float);
typedef int (_stdcall* csTextureHWPointerPtr)(int);
typedef int (_stdcall* csVectorCreatePtr)();
typedef void (_stdcall* csVectorFreePtr)(int);
typedef void (_stdcall* csVectorAddPtr)(int, int);
typedef void (_stdcall* csVectorAddScalePtr)(int, int, float);
typedef int (_stdcall* csVectorBetweenPtr)(int, float, float, float, float, float, float);
typedef void (_stdcall* csVectorCopyPtr)(int, int);
typedef void (_stdcall* csVectorCrossProductPtr)(int, int);
typedef float (_stdcall* csVectorDotProductPtr)(int, int);
typedef int (_stdcall* csVectorEqualPtr)(int, int, float);
typedef float (_stdcall* csVectorDistancePtr)(int, float, float, float);
typedef float (_stdcall* csVectorDistanceSquaredPtr)(int, float, float, float);
typedef void (_stdcall* csVectorDivPtr)(int, int);
typedef void (_stdcall* csVectorInterpolatePtr)(int, int, float);
typedef void (_stdcall* csVectorInvertPtr)(int);
typedef float (_stdcall* csVectorLengthPtr)(int);
typedef float (_stdcall* csVectorLengthSquaredPtr)(int);
typedef void (_stdcall* csVectorMulPtr)(int, int);
typedef void (_stdcall* csVectorNormalizePtr)(int);
typedef void (_stdcall* csVectorScalePtr)(int, float);
typedef void (_stdcall* csVectorSetPtr)(int, float, float, float);
typedef void (_stdcall* csVectorSubPtr)(int, int);
typedef float (_stdcall* csVectorXPtr)(int);
typedef float (_stdcall* csVectorYPtr)(int);
typedef float (_stdcall* csVectorZPtr)(int);
typedef int (_stdcall* csXMLReadPtr)(const char*);
typedef int (_stdcall* csXMLWritePtr)(const char*);
typedef void (_stdcall* csXMLClosePtr)(int);
typedef int (_stdcall* csXMLReadNodePtr)(int);
typedef int (_stdcall* csXMLNodeTypePtr)(int);
typedef const char* (_stdcall* csXMLNodeNamePtr)(int);
typedef const char* (_stdcall* csXMLNodeDataPtr)(int);
typedef int (_stdcall* csXMLAttributeCountPtr)(int);
typedef const char* (_stdcall* csXMLAttributeNamePtr)(int, int);
typedef const char* (_stdcall* csXMLAttributeValuePtr)(int, int);
typedef void (_stdcall* csXMLWriteHeaderPtr)(int);
typedef void (_stdcall* csXMLWriteElementPtr)(int, const char*, const char*, int);
typedef void (_stdcall* csXMLWriteClosingTagPtr)(int, const char*);
typedef void (_stdcall* csXMLWriteTextPtr)(int, const char*);
typedef void (_stdcall* csXMLWriteLineBreakPtr)(int);

struct csApi_t
{
	HMODULE lib;
	csCoreInitPtr csCoreInit;
	csCoreFinishPtr csCoreFinish;
	csCoreMessagePtr csCoreMessage;
	csListenerUpdatePtr csListenerUpdate;
	csSoundSetMasterVolumePtr csSoundSetMasterVolume;
	csSoundGetMasterVolumePtr csSoundGetMasterVolume;
	csSoundLoadPtr csSoundLoad;
	csSoundFreePtr csSoundFree;
	csSoundPlay2DPtr csSoundPlay2D;
	csSoundPlay3DPtr csSoundPlay3D;
	csSoundIsPlayingPtr csSoundIsPlaying;
	csChannelPausedPtr csChannelPaused;
	csChannelFinishedPtr csChannelFinished;
	csChannelLoopedPtr csChannelLooped;
	csChannelGetMinDistancePtr csChannelGetMinDistance;
	csChannelGetMaxDistancePtr csChannelGetMaxDistance;
	csChannelGetPanPtr csChannelGetPan;
	csChannelGetPlayPositionPtr csChannelGetPlayPosition;
	csChannelXPtr csChannelX;
	csChannelYPtr csChannelY;
	csChannelZPtr csChannelZ;
	csChannelGetVolumePtr csChannelGetVolume;
	csChannelPausePtr csChannelPause;
	csChannelResumePtr csChannelResume;
	csChannelSetDistancePtr csChannelSetDistance;
	csChannelSetPanPtr csChannelSetPan;
	csChannelSetPositionPtr csChannelSetPosition;
	csChannelSetVolumePtr csChannelSetVolume;
	csChannelStopPtr csChannelStop;
	csBillboardNodePtr csBillboardNode;
	csBillboardResizePtr csBillboardResize;
	csBillboardWidthPtr csBillboardWidth;
	csBillboardHeightPtr csBillboardHeight;
	csCameraNodePtr csCameraNode;
	csCameraViewportPtr csCameraViewport;
	csCameraRangePtr csCameraRange;
	csCameraFovPtr csCameraFov;
	csCameraAspectRatioPtr csCameraAspectRatio;
	csCameraProjectionPtr csCameraProjection;
	csCameraLinePtr csCameraLine;
	csCameraPickNodePtr csCameraPickNode;
	csCameraToScreenPtr csCameraToScreen;
	csCameraRenderTargetPtr csCameraRenderTarget;
	csCameraClearFlagsPtr csCameraClearFlags;
	csCollisionSlidePtr csCollisionSlide;
	csCollisionLinePickPtr csCollisionLinePick;
	csCollisionLineNodePtr csCollisionLineNode;
	csPackageAddPtr csPackageAdd;
	csDirListPtr csDirList;
	csDirClosePtr csDirClose;
	csDirFileCountPtr csDirFileCount;
	csDirFileNamePtr csDirFileName;
	csDirFileIsDirPtr csDirFileIsDir;
	csDisplayOpenPtr csDisplayOpen;
	csDisplayClosePtr csDisplayClose;
	csDisplayCaptionPtr csDisplayCaption;
	csDisplayClosedPtr csDisplayClosed;
	csDisplayWidthPtr csDisplayWidth;
	csDisplayHeightPtr csDisplayHeight;
	csDisplayFpsPtr csDisplayFps;
	csDisplayFeaturePtr csDisplayFeature;
	csDisplayResizePtr csDisplayResize;
	csDisplayActivePtr csDisplayActive;
	csDisplayScreenshotPtr csDisplayScreenshot;
	csGetColorPtr csGetColor;
	csGetRedPtr csGetRed;
	csGetGreenPtr csGetGreen;
	csGetBluePtr csGetBlue;
	csGetAlphaPtr csGetAlpha;
	csSetColorPtr csSetColor;
	csViewportPtr csViewport;
	csDrawLinePtr csDrawLine;
	csDrawRectPtr csDrawRect;
	csDrawTexturePtr csDrawTexture;
	csDrawTextPtr csDrawText;
	csTextWidthPtr csTextWidth;
	csTextHeightPtr csTextHeight;
	csEffectRegisterPtr csEffectRegister;
	csEffectRegisterFilePtr csEffectRegisterFile;
	csEffectSetTechniquePtr csEffectSetTechnique;
	csEffectSetTexturePtr csEffectSetTexture;
	csEffectSetBoolPtr csEffectSetBool;
	csEffectSetIntPtr csEffectSetInt;
	csEffectSetFloatPtr csEffectSetFloat;
	csEffectSetVectorPtr csEffectSetVector;
	csEffectSetMatrixPtr csEffectSetMatrix;
	csEmitterNodePtr csEmitterNode;
	csEmitterAddFadeOutAffectorPtr csEmitterAddFadeOutAffector;
	csEmitterAddGravityAffectorPtr csEmitterAddGravityAffector;
	csEmitterRemoveAffectorsPtr csEmitterRemoveAffectors;
	csEventGetPtr csEventGet;
	csEventPollPtr csEventPoll;
	csEventPostPtr csEventPost;
	csEventIdPtr csEventId;
	csEventFromPtr csEventFrom;
	csEventToPtr csEventTo;
	csEventAPtr csEventA;
	csEventBPtr csEventB;
	csEventCPtr csEventC;
	csEventDataPtr csEventData;
	csFileReadPtr csFileRead;
	csFileWritePtr csFileWrite;
	csFileClosePtr csFileClose;
	csFileSizePtr csFileSize;
	csFilePosPtr csFilePos;
	csFileSeekPtr csFileSeek;
	csFileReadBytePtr csFileReadByte;
	csFileReadShortPtr csFileReadShort;
	csFileReadIntPtr csFileReadInt;
	csFileReadFloatPtr csFileReadFloat;
	csFileReadStringPtr csFileReadString;
	csFileReadBytesPtr csFileReadBytes;
	csFileWriteBytePtr csFileWriteByte;
	csFileWriteShortPtr csFileWriteShort;
	csFileWriteIntPtr csFileWriteInt;
	csFileWriteFloatPtr csFileWriteFloat;
	csFileWriteStringPtr csFileWriteString;
	csFileWriteBytesPtr csFileWriteBytes;
	csFileGetExtPtr csFileGetExt;
	csFileGetDirPtr csFileGetDir;
	csFileStripExtPtr csFileStripExt;
	csFileStripDirPtr csFileStripDir;
	csFontLoadPtr csFontLoad;
	csFontFreePtr csFontFree;
	csMousePositionPtr csMousePosition;
	csMouseHidePtr csMouseHide;
	csMouseXPtr csMouseX;
	csMouseYPtr csMouseY;
	csMouseHitPtr csMouseHit;
	csMouseDownPtr csMouseDown;
	csMouseGetPtr csMouseGet;
	csMouseReleasedPtr csMouseReleased;
	csKeyHitPtr csKeyHit;
	csKeyDownPtr csKeyDown;
	csKeyGetPtr csKeyGet;
	csKeyReleasedPtr csKeyReleased;
	csJoyNamePtr csJoyName;
	csJoyButtonPtr csJoyButton;
	csJoyAxisPtr csJoyAxis;
	csJoyNumAxesPtr csJoyNumAxes;
	csLightNodePtr csLightNode;
	csLightTypePtr csLightType;
	csLightRadiusPtr csLightRadius;
	csLightAmbientPtr csLightAmbient;
	csLightDiffusePtr csLightDiffuse;
	csLightSpecularPtr csLightSpecular;
	csMaterialCreatePtr csMaterialCreate;
	csMaterialLoadPtr csMaterialLoad;
	csMaterialSavePtr csMaterialSave;
	csMaterialFreePtr csMaterialFree;
	csMaterialFindPtr csMaterialFind;
	csMaterialSetTypePtr csMaterialSetType;
	csMaterialSetFlagsPtr csMaterialSetFlags;
	csMaterialSetTexturePtr csMaterialSetTexture;
	csMaterialSetAmbientPtr csMaterialSetAmbient;
	csMaterialSetDiffusePtr csMaterialSetDiffuse;
	csMaterialSetEmissivePtr csMaterialSetEmissive;
	csMaterialSetSpecularPtr csMaterialSetSpecular;
	csMaterialSetShininessPtr csMaterialSetShininess;
	csMaterialSetParamPtr csMaterialSetParam;
	csMaterialGetNamePtr csMaterialGetName;
	csMaterialGetTypePtr csMaterialGetType;
	csMaterialGetFlagsPtr csMaterialGetFlags;
	csMaterialGetTexturePtr csMaterialGetTexture;
	csMaterialGetAmbientPtr csMaterialGetAmbient;
	csMaterialGetDiffusePtr csMaterialGetDiffuse;
	csMaterialGetEmissivePtr csMaterialGetEmissive;
	csMaterialGetSpecularPtr csMaterialGetSpecular;
	csMaterialGetShininessPtr csMaterialGetShininess;
	csMaterialGetParamPtr csMaterialGetParam;
	csMathFloorPtr csMathFloor;
	csMathCeilPtr csMathCeil;
	csMathAbsPtr csMathAbs;
	csMathSqrPtr csMathSqr;
	csMathSinPtr csMathSin;
	csMathCosPtr csMathCos;
	csMathTanPtr csMathTan;
	csMathASinPtr csMathASin;
	csMathACosPtr csMathACos;
	csMathATanPtr csMathATan;
	csMathATan2Ptr csMathATan2;
	csMathExpPtr csMathExp;
	csMathLogPtr csMathLog;
	csMathLog10Ptr csMathLog10;
	csMathRandPtr csMathRand;
	csMathRandSeedPtr csMathRandSeed;
	csMatrixCreatePtr csMatrixCreate;
	csMatrixFreePtr csMatrixFree;
	csMatrixAddPtr csMatrixAdd;
	csMatrixCopyPtr csMatrixCopy;
	csMatrixDivPtr csMatrixDiv;
	csMatrixElementPtr csMatrixElement;
	csMatrixEqualPtr csMatrixEqual;
	csMatrixGetRotationPtr csMatrixGetRotation;
	csMatrixGetTranslationPtr csMatrixGetTranslation;
	csMatrixIdentityPtr csMatrixIdentity;
	csMatrixInterpolatePtr csMatrixInterpolate;
	csMatrixInvertPtr csMatrixInvert;
	csMatrixMulPtr csMatrixMul;
	csMatrixSetPtr csMatrixSet;
	csMatrixSetRotationPtr csMatrixSetRotation;
	csMatrixSetScalePtr csMatrixSetScale;
	csMatrixSetTranslationPtr csMatrixSetTranslation;
	csMatrixSubPtr csMatrixSub;
	csMatrixTransposePtr csMatrixTranspose;
	csMeshLoadPtr csMeshLoad;
	csMeshTerrainLoadPtr csMeshTerrainLoad;
	csMeshFreePtr csMeshFree;
	csMeshNodePtr csMeshNode;
	csMeshOctreeNodePtr csMeshOctreeNode;
	csMeshScalePtr csMeshScale;
	csMeshFlipPtr csMeshFlip;
	csMeshUpdateNormalsPtr csMeshUpdateNormals;
	csMeshVerticesColorPtr csMeshVerticesColor;
	csMeshPlanarMappingPtr csMeshPlanarMapping;
	csMeshWidthPtr csMeshWidth;
	csMeshHeightPtr csMeshHeight;
	csMeshDepthPtr csMeshDepth;
	csNodeEmptyPtr csNodeEmpty;
	csNodeFreePtr csNodeFree;
	csNodeTypePtr csNodeType;
	csNodeSetNamePtr csNodeSetName;
	csNodeGetNamePtr csNodeGetName;
	csNodePositionPtr csNodePosition;
	csNodeMovePtr csNodeMove;
	csNodeRotatePtr csNodeRotate;
	csNodeTurnPtr csNodeTurn;
	csNodeScalePtr csNodeScale;
	csNodeXPtr csNodeX;
	csNodeYPtr csNodeY;
	csNodeZPtr csNodeZ;
	csNodePitchPtr csNodePitch;
	csNodeYawPtr csNodeYaw;
	csNodeRollPtr csNodeRoll;
	csNodeScaleXPtr csNodeScaleX;
	csNodeScaleYPtr csNodeScaleY;
	csNodeScaleZPtr csNodeScaleZ;
	csNodeWidthPtr csNodeWidth;
	csNodeHeightPtr csNodeHeight;
	csNodeDepthPtr csNodeDepth;
	csNodeCastShadowPtr csNodeCastShadow;
	csNodeHidePtr csNodeHide;
	csNodeMaterialsPtr csNodeMaterials;
	csNodeGetMaterialPtr csNodeGetMaterial;
	csNodeSetMaterialPtr csNodeSetMaterial;
	csNodeSetMaterialFastPtr csNodeSetMaterialFast;
	csNodeSetMaterialFlagPtr csNodeSetMaterialFlag;
	csNodeSetPickGroupPtr csNodeSetPickGroup;
	csNodeSetPropertyPtr csNodeSetProperty;
	csNodePropertiesPtr csNodeProperties;
	csNodeFindPropertyPtr csNodeFindProperty;
	csNodePropertyNamePtr csNodePropertyName;
	csNodePropertyValuePtr csNodePropertyValue;
	csNodeRemovePropertyPtr csNodeRemoveProperty;
	csNodeSetParentPtr csNodeSetParent;
	csNodeGetParentPtr csNodeGetParent;
	csNodeChildrenPtr csNodeChildren;
	csNodeChildPtr csNodeChild;
	csNodeFindChildPtr csNodeFindChild;
	csNodeSpeedPtr csNodeSpeed;
	csNodeLoopPtr csNodeLoop;
	csNodeSetFramePtr csNodeSetFrame;
	csNodeGetFramePtr csNodeGetFrame;
	csNodeAttachToBonePtr csNodeAttachToBone;
	csNodeLookAtPtr csNodeLookAt;
	csParticleDataCreatePtr csParticleDataCreate;
	csParticleDataLoadPtr csParticleDataLoad;
	csParticleDataSavePtr csParticleDataSave;
	csParticleDataFreePtr csParticleDataFree;
	csParticleDataFindPtr csParticleDataFind;
	csParticleDataSetMaterialPtr csParticleDataSetMaterial;
	csParticleDataSetTypePtr csParticleDataSetType;
	csParticleDataSetBoxPtr csParticleDataSetBox;
	csParticleDataSetDirectionPtr csParticleDataSetDirection;
	csParticleDataSetRatePtr csParticleDataSetRate;
	csParticleDataSetColorPtr csParticleDataSetColor;
	csParticleDataSetLifeTimePtr csParticleDataSetLifeTime;
	csParticleDataSetMaxAnglePtr csParticleDataSetMaxAngle;
	csParticleDataSetSizePtr csParticleDataSetSize;
	csParticleDataAddFadeOutAffectorPtr csParticleDataAddFadeOutAffector;
	csParticleDataAddGravityAffectorPtr csParticleDataAddGravityAffector;
	csParticleDataGetNamePtr csParticleDataGetName;
	csParticleDataGetMaterialPtr csParticleDataGetMaterial;
	csParticleDataGetTypePtr csParticleDataGetType;
	csParticleDataGetBoxWidthPtr csParticleDataGetBoxWidth;
	csParticleDataGetBoxHeightPtr csParticleDataGetBoxHeight;
	csParticleDataGetBoxDepthPtr csParticleDataGetBoxDepth;
	csParticleDataGetDirectionXPtr csParticleDataGetDirectionX;
	csParticleDataGetDirectionYPtr csParticleDataGetDirectionY;
	csParticleDataGetDirectionZPtr csParticleDataGetDirectionZ;
	csParticleDataGetMinRatePtr csParticleDataGetMinRate;
	csParticleDataGetMaxRatePtr csParticleDataGetMaxRate;
	csParticleDataGetMinColorPtr csParticleDataGetMinColor;
	csParticleDataGetMaxColorPtr csParticleDataGetMaxColor;
	csParticleDataGetMinLifeTimePtr csParticleDataGetMinLifeTime;
	csParticleDataGetMaxLifeTimePtr csParticleDataGetMaxLifeTime;
	csParticleDataGetMaxAnglePtr csParticleDataGetMaxAngle;
	csParticleDataGetWidthPtr csParticleDataGetWidth;
	csParticleDataGetHeightPtr csParticleDataGetHeight;
	csParticleDataAffectorsPtr csParticleDataAffectors;
	csParticleDataGetAffectorTypePtr csParticleDataGetAffectorType;
	csParticleDataGetAffectorColorPtr csParticleDataGetAffectorColor;
	csParticleDataGetAffectorTimePtr csParticleDataGetAffectorTime;
	csParticleDataGetAffectorGravityXPtr csParticleDataGetAffectorGravityX;
	csParticleDataGetAffectorGravityYPtr csParticleDataGetAffectorGravityY;
	csParticleDataGetAffectorGravityZPtr csParticleDataGetAffectorGravityZ;
	csSceneBeginPtr csSceneBegin;
	csSceneEndPtr csSceneEnd;
	csSceneRenderPtr csSceneRender;
	csSceneAmbientPtr csSceneAmbient;
	csSceneShadowPtr csSceneShadow;
	csSceneFogPtr csSceneFog;
	csSceneSkyboxPtr csSceneSkybox;
	csSceneSkydomePtr csSceneSkydome;
	csSceneTransformationPtr csSceneTransformation;
	csShaderRegisterPtr csShaderRegister;
	csShaderRegisterFilePtr csShaderRegisterFile;
	csShaderAsmRegisterPtr csShaderAsmRegister;
	csShaderAsmRegisterFilePtr csShaderAsmRegisterFile;
	csShaderPixelConstantPtr csShaderPixelConstant;
	csShaderVertexConstantPtr csShaderVertexConstant;
	csStringToIntPtr csStringToInt;
	csStringToFloatPtr csStringToFloat;
	csStringFromIntPtr csStringFromInt;
	csStringFromFloatPtr csStringFromFloat;
	csStringLeftPtr csStringLeft;
	csStringRightPtr csStringRight;
	csStringMidPtr csStringMid;
	csStringReplacePtr csStringReplace;
	csStringFindPtr csStringFind;
	csStringUpperPtr csStringUpper;
	csStringLowerPtr csStringLower;
	csStringTrimPtr csStringTrim;
	csStringCharPtr csStringChar;
	csStringAsciiPtr csStringAscii;
	csStringLenPtr csStringLen;
	csStringFieldPtr csStringField;
	csTerrainNodePtr csTerrainNode;
	csTerrainScaleTexturePtr csTerrainScaleTexture;
	csTextureCreatePtr csTextureCreate;
	csTextureTargetCreatePtr csTextureTargetCreate;
	csTextureLoadPtr csTextureLoad;
	csTextureFreePtr csTextureFree;
	csTextureFilePtr csTextureFile;
	csTextureWidthPtr csTextureWidth;
	csTextureHeightPtr csTextureHeight;
	csTextureLockPtr csTextureLock;
	csTextureUnlockPtr csTextureUnlock;
	csTextureColorKeyPtr csTextureColorKey;
	csTextureNormalizePtr csTextureNormalize;
	csTextureHWPointerPtr csTextureHWPointer;
	csVectorCreatePtr csVectorCreate;
	csVectorFreePtr csVectorFree;
	csVectorAddPtr csVectorAdd;
	csVectorAddScalePtr csVectorAddScale;
	csVectorBetweenPtr csVectorBetween;
	csVectorCopyPtr csVectorCopy;
	csVectorCrossProductPtr csVectorCrossProduct;
	csVectorDotProductPtr csVectorDotProduct;
	csVectorEqualPtr csVectorEqual;
	csVectorDistancePtr csVectorDistance;
	csVectorDistanceSquaredPtr csVectorDistanceSquared;
	csVectorDivPtr csVectorDiv;
	csVectorInterpolatePtr csVectorInterpolate;
	csVectorInvertPtr csVectorInvert;
	csVectorLengthPtr csVectorLength;
	csVectorLengthSquaredPtr csVectorLengthSquared;
	csVectorMulPtr csVectorMul;
	csVectorNormalizePtr csVectorNormalize;
	csVectorScalePtr csVectorScale;
	csVectorSetPtr csVectorSet;
	csVectorSubPtr csVectorSub;
	csVectorXPtr csVectorX;
	csVectorYPtr csVectorY;
	csVectorZPtr csVectorZ;
	csXMLReadPtr csXMLRead;
	csXMLWritePtr csXMLWrite;
	csXMLClosePtr csXMLClose;
	csXMLReadNodePtr csXMLReadNode;
	csXMLNodeTypePtr csXMLNodeType;
	csXMLNodeNamePtr csXMLNodeName;
	csXMLNodeDataPtr csXMLNodeData;
	csXMLAttributeCountPtr csXMLAttributeCount;
	csXMLAttributeNamePtr csXMLAttributeName;
	csXMLAttributeValuePtr csXMLAttributeValue;
	csXMLWriteHeaderPtr csXMLWriteHeader;
	csXMLWriteElementPtr csXMLWriteElement;
	csXMLWriteClosingTagPtr csXMLWriteClosingTag;
	csXMLWriteTextPtr csXMLWriteText;
	csXMLWriteLineBreakPtr csXMLWriteLineBreak;
} csApi;

void csCoreInit()
{
	csApi.lib = LoadLibrary("coldsteel.dll");
	csApi.csCoreInit = (csCoreInitPtr) GetProcAddress(csApi.lib, "_csCoreInit@0");
	csApi.csCoreFinish = (csCoreFinishPtr) GetProcAddress(csApi.lib, "_csCoreFinish@0");
	csApi.csCoreMessage = (csCoreMessagePtr) GetProcAddress(csApi.lib, "_csCoreMessage@8");
	csApi.csListenerUpdate = (csListenerUpdatePtr) GetProcAddress(csApi.lib, "_csListenerUpdate@4");
	csApi.csSoundSetMasterVolume = (csSoundSetMasterVolumePtr) GetProcAddress(csApi.lib, "_csSoundSetMasterVolume@4");
	csApi.csSoundGetMasterVolume = (csSoundGetMasterVolumePtr) GetProcAddress(csApi.lib, "_csSoundGetMasterVolume@4");
	csApi.csSoundLoad = (csSoundLoadPtr) GetProcAddress(csApi.lib, "_csSoundLoad@4");
	csApi.csSoundFree = (csSoundFreePtr) GetProcAddress(csApi.lib, "_csSoundFree@4");
	csApi.csSoundPlay2D = (csSoundPlay2DPtr) GetProcAddress(csApi.lib, "_csSoundPlay2D@8");
	csApi.csSoundPlay3D = (csSoundPlay3DPtr) GetProcAddress(csApi.lib, "_csSoundPlay3D@20");
	csApi.csSoundIsPlaying = (csSoundIsPlayingPtr) GetProcAddress(csApi.lib, "_csSoundIsPlaying@4");
	csApi.csChannelPaused = (csChannelPausedPtr) GetProcAddress(csApi.lib, "_csChannelPaused@4");
	csApi.csChannelFinished = (csChannelFinishedPtr) GetProcAddress(csApi.lib, "_csChannelFinished@4");
	csApi.csChannelLooped = (csChannelLoopedPtr) GetProcAddress(csApi.lib, "_csChannelLooped@4");
	csApi.csChannelGetMinDistance = (csChannelGetMinDistancePtr) GetProcAddress(csApi.lib, "_csChannelGetMinDistance@4");
	csApi.csChannelGetMaxDistance = (csChannelGetMaxDistancePtr) GetProcAddress(csApi.lib, "_csChannelGetMaxDistance@4");
	csApi.csChannelGetPan = (csChannelGetPanPtr) GetProcAddress(csApi.lib, "_csChannelGetPan@4");
	csApi.csChannelGetPlayPosition = (csChannelGetPlayPositionPtr) GetProcAddress(csApi.lib, "_csChannelGetPlayPosition@4");
	csApi.csChannelX = (csChannelXPtr) GetProcAddress(csApi.lib, "_csChannelX@4");
	csApi.csChannelY = (csChannelYPtr) GetProcAddress(csApi.lib, "_csChannelY@4");
	csApi.csChannelZ = (csChannelZPtr) GetProcAddress(csApi.lib, "_csChannelZ@4");
	csApi.csChannelGetVolume = (csChannelGetVolumePtr) GetProcAddress(csApi.lib, "_csChannelGetVolume@4");
	csApi.csChannelPause = (csChannelPausePtr) GetProcAddress(csApi.lib, "_csChannelPause@4");
	csApi.csChannelResume = (csChannelResumePtr) GetProcAddress(csApi.lib, "_csChannelResume@4");
	csApi.csChannelSetDistance = (csChannelSetDistancePtr) GetProcAddress(csApi.lib, "_csChannelSetDistance@12");
	csApi.csChannelSetPan = (csChannelSetPanPtr) GetProcAddress(csApi.lib, "_csChannelSetPan@8");
	csApi.csChannelSetPosition = (csChannelSetPositionPtr) GetProcAddress(csApi.lib, "_csChannelSetPosition@16");
	csApi.csChannelSetVolume = (csChannelSetVolumePtr) GetProcAddress(csApi.lib, "_csChannelSetVolume@8");
	csApi.csChannelStop = (csChannelStopPtr) GetProcAddress(csApi.lib, "_csChannelStop@4");
	csApi.csBillboardNode = (csBillboardNodePtr) GetProcAddress(csApi.lib, "_csBillboardNode@4");
	csApi.csBillboardResize = (csBillboardResizePtr) GetProcAddress(csApi.lib, "_csBillboardResize@12");
	csApi.csBillboardWidth = (csBillboardWidthPtr) GetProcAddress(csApi.lib, "_csBillboardWidth@4");
	csApi.csBillboardHeight = (csBillboardHeightPtr) GetProcAddress(csApi.lib, "_csBillboardHeight@4");
	csApi.csCameraNode = (csCameraNodePtr) GetProcAddress(csApi.lib, "_csCameraNode@4");
	csApi.csCameraViewport = (csCameraViewportPtr) GetProcAddress(csApi.lib, "_csCameraViewport@20");
	csApi.csCameraRange = (csCameraRangePtr) GetProcAddress(csApi.lib, "_csCameraRange@12");
	csApi.csCameraFov = (csCameraFovPtr) GetProcAddress(csApi.lib, "_csCameraFov@8");
	csApi.csCameraAspectRatio = (csCameraAspectRatioPtr) GetProcAddress(csApi.lib, "_csCameraAspectRatio@8");
	csApi.csCameraProjection = (csCameraProjectionPtr) GetProcAddress(csApi.lib, "_csCameraProjection@24");
	csApi.csCameraLine = (csCameraLinePtr) GetProcAddress(csApi.lib, "_csCameraLine@20");
	csApi.csCameraPickNode = (csCameraPickNodePtr) GetProcAddress(csApi.lib, "_csCameraPickNode@16");
	csApi.csCameraToScreen = (csCameraToScreenPtr) GetProcAddress(csApi.lib, "_csCameraToScreen@20");
	csApi.csCameraRenderTarget = (csCameraRenderTargetPtr) GetProcAddress(csApi.lib, "_csCameraRenderTarget@8");
	csApi.csCameraClearFlags = (csCameraClearFlagsPtr) GetProcAddress(csApi.lib, "_csCameraClearFlags@12");
	csApi.csCollisionSlide = (csCollisionSlidePtr) GetProcAddress(csApi.lib, "_csCollisionSlide@56");
	csApi.csCollisionLinePick = (csCollisionLinePickPtr) GetProcAddress(csApi.lib, "_csCollisionLinePick@44");
	csApi.csCollisionLineNode = (csCollisionLineNodePtr) GetProcAddress(csApi.lib, "_csCollisionLineNode@24");
	csApi.csPackageAdd = (csPackageAddPtr) GetProcAddress(csApi.lib, "_csPackageAdd@4");
	csApi.csDirList = (csDirListPtr) GetProcAddress(csApi.lib, "_csDirList@4");
	csApi.csDirClose = (csDirClosePtr) GetProcAddress(csApi.lib, "_csDirClose@4");
	csApi.csDirFileCount = (csDirFileCountPtr) GetProcAddress(csApi.lib, "_csDirFileCount@4");
	csApi.csDirFileName = (csDirFileNamePtr) GetProcAddress(csApi.lib, "_csDirFileName@8");
	csApi.csDirFileIsDir = (csDirFileIsDirPtr) GetProcAddress(csApi.lib, "_csDirFileIsDir@8");
	csApi.csDisplayOpen = (csDisplayOpenPtr) GetProcAddress(csApi.lib, "_csDisplayOpen@20");
	csApi.csDisplayClose = (csDisplayClosePtr) GetProcAddress(csApi.lib, "_csDisplayClose@0");
	csApi.csDisplayCaption = (csDisplayCaptionPtr) GetProcAddress(csApi.lib, "_csDisplayCaption@4");
	csApi.csDisplayClosed = (csDisplayClosedPtr) GetProcAddress(csApi.lib, "_csDisplayClosed@0");
	csApi.csDisplayWidth = (csDisplayWidthPtr) GetProcAddress(csApi.lib, "_csDisplayWidth@0");
	csApi.csDisplayHeight = (csDisplayHeightPtr) GetProcAddress(csApi.lib, "_csDisplayHeight@0");
	csApi.csDisplayFps = (csDisplayFpsPtr) GetProcAddress(csApi.lib, "_csDisplayFps@0");
	csApi.csDisplayFeature = (csDisplayFeaturePtr) GetProcAddress(csApi.lib, "_csDisplayFeature@4");
	csApi.csDisplayResize = (csDisplayResizePtr) GetProcAddress(csApi.lib, "_csDisplayResize@8");
	csApi.csDisplayActive = (csDisplayActivePtr) GetProcAddress(csApi.lib, "_csDisplayActive@0");
	csApi.csDisplayScreenshot = (csDisplayScreenshotPtr) GetProcAddress(csApi.lib, "_csDisplayScreenshot@4");
	csApi.csGetColor = (csGetColorPtr) GetProcAddress(csApi.lib, "_csGetColor@16");
	csApi.csGetRed = (csGetRedPtr) GetProcAddress(csApi.lib, "_csGetRed@4");
	csApi.csGetGreen = (csGetGreenPtr) GetProcAddress(csApi.lib, "_csGetGreen@4");
	csApi.csGetBlue = (csGetBluePtr) GetProcAddress(csApi.lib, "_csGetBlue@4");
	csApi.csGetAlpha = (csGetAlphaPtr) GetProcAddress(csApi.lib, "_csGetAlpha@4");
	csApi.csSetColor = (csSetColorPtr) GetProcAddress(csApi.lib, "_csSetColor@4");
	csApi.csViewport = (csViewportPtr) GetProcAddress(csApi.lib, "_csViewport@16");
	csApi.csDrawLine = (csDrawLinePtr) GetProcAddress(csApi.lib, "_csDrawLine@16");
	csApi.csDrawRect = (csDrawRectPtr) GetProcAddress(csApi.lib, "_csDrawRect@16");
	csApi.csDrawTexture = (csDrawTexturePtr) GetProcAddress(csApi.lib, "_csDrawTexture@12");
	csApi.csDrawText = (csDrawTextPtr) GetProcAddress(csApi.lib, "_csDrawText@16");
	csApi.csTextWidth = (csTextWidthPtr) GetProcAddress(csApi.lib, "_csTextWidth@8");
	csApi.csTextHeight = (csTextHeightPtr) GetProcAddress(csApi.lib, "_csTextHeight@8");
	csApi.csEffectRegister = (csEffectRegisterPtr) GetProcAddress(csApi.lib, "_csEffectRegister@8");
	csApi.csEffectRegisterFile = (csEffectRegisterFilePtr) GetProcAddress(csApi.lib, "_csEffectRegisterFile@8");
	csApi.csEffectSetTechnique = (csEffectSetTechniquePtr) GetProcAddress(csApi.lib, "_csEffectSetTechnique@8");
	csApi.csEffectSetTexture = (csEffectSetTexturePtr) GetProcAddress(csApi.lib, "_csEffectSetTexture@12");
	csApi.csEffectSetBool = (csEffectSetBoolPtr) GetProcAddress(csApi.lib, "_csEffectSetBool@12");
	csApi.csEffectSetInt = (csEffectSetIntPtr) GetProcAddress(csApi.lib, "_csEffectSetInt@12");
	csApi.csEffectSetFloat = (csEffectSetFloatPtr) GetProcAddress(csApi.lib, "_csEffectSetFloat@12");
	csApi.csEffectSetVector = (csEffectSetVectorPtr) GetProcAddress(csApi.lib, "_csEffectSetVector@12");
	csApi.csEffectSetMatrix = (csEffectSetMatrixPtr) GetProcAddress(csApi.lib, "_csEffectSetMatrix@12");
	csApi.csEmitterNode = (csEmitterNodePtr) GetProcAddress(csApi.lib, "_csEmitterNode@8");
	csApi.csEmitterAddFadeOutAffector = (csEmitterAddFadeOutAffectorPtr) GetProcAddress(csApi.lib, "_csEmitterAddFadeOutAffector@12");
	csApi.csEmitterAddGravityAffector = (csEmitterAddGravityAffectorPtr) GetProcAddress(csApi.lib, "_csEmitterAddGravityAffector@20");
	csApi.csEmitterRemoveAffectors = (csEmitterRemoveAffectorsPtr) GetProcAddress(csApi.lib, "_csEmitterRemoveAffectors@4");
	csApi.csEventGet = (csEventGetPtr) GetProcAddress(csApi.lib, "_csEventGet@0");
	csApi.csEventPoll = (csEventPollPtr) GetProcAddress(csApi.lib, "_csEventPoll@0");
	csApi.csEventPost = (csEventPostPtr) GetProcAddress(csApi.lib, "_csEventPost@28");
	csApi.csEventId = (csEventIdPtr) GetProcAddress(csApi.lib, "_csEventId@0");
	csApi.csEventFrom = (csEventFromPtr) GetProcAddress(csApi.lib, "_csEventFrom@0");
	csApi.csEventTo = (csEventToPtr) GetProcAddress(csApi.lib, "_csEventTo@0");
	csApi.csEventA = (csEventAPtr) GetProcAddress(csApi.lib, "_csEventA@0");
	csApi.csEventB = (csEventBPtr) GetProcAddress(csApi.lib, "_csEventB@0");
	csApi.csEventC = (csEventCPtr) GetProcAddress(csApi.lib, "_csEventC@0");
	csApi.csEventData = (csEventDataPtr) GetProcAddress(csApi.lib, "_csEventData@0");
	csApi.csFileRead = (csFileReadPtr) GetProcAddress(csApi.lib, "_csFileRead@4");
	csApi.csFileWrite = (csFileWritePtr) GetProcAddress(csApi.lib, "_csFileWrite@4");
	csApi.csFileClose = (csFileClosePtr) GetProcAddress(csApi.lib, "_csFileClose@4");
	csApi.csFileSize = (csFileSizePtr) GetProcAddress(csApi.lib, "_csFileSize@4");
	csApi.csFilePos = (csFilePosPtr) GetProcAddress(csApi.lib, "_csFilePos@4");
	csApi.csFileSeek = (csFileSeekPtr) GetProcAddress(csApi.lib, "_csFileSeek@12");
	csApi.csFileReadByte = (csFileReadBytePtr) GetProcAddress(csApi.lib, "_csFileReadByte@4");
	csApi.csFileReadShort = (csFileReadShortPtr) GetProcAddress(csApi.lib, "_csFileReadShort@4");
	csApi.csFileReadInt = (csFileReadIntPtr) GetProcAddress(csApi.lib, "_csFileReadInt@4");
	csApi.csFileReadFloat = (csFileReadFloatPtr) GetProcAddress(csApi.lib, "_csFileReadFloat@4");
	csApi.csFileReadString = (csFileReadStringPtr) GetProcAddress(csApi.lib, "_csFileReadString@4");
	csApi.csFileReadBytes = (csFileReadBytesPtr) GetProcAddress(csApi.lib, "_csFileReadBytes@12");
	csApi.csFileWriteByte = (csFileWriteBytePtr) GetProcAddress(csApi.lib, "_csFileWriteByte@8");
	csApi.csFileWriteShort = (csFileWriteShortPtr) GetProcAddress(csApi.lib, "_csFileWriteShort@8");
	csApi.csFileWriteInt = (csFileWriteIntPtr) GetProcAddress(csApi.lib, "_csFileWriteInt@8");
	csApi.csFileWriteFloat = (csFileWriteFloatPtr) GetProcAddress(csApi.lib, "_csFileWriteFloat@8");
	csApi.csFileWriteString = (csFileWriteStringPtr) GetProcAddress(csApi.lib, "_csFileWriteString@8");
	csApi.csFileWriteBytes = (csFileWriteBytesPtr) GetProcAddress(csApi.lib, "_csFileWriteBytes@12");
	csApi.csFileGetExt = (csFileGetExtPtr) GetProcAddress(csApi.lib, "_csFileGetExt@4");
	csApi.csFileGetDir = (csFileGetDirPtr) GetProcAddress(csApi.lib, "_csFileGetDir@4");
	csApi.csFileStripExt = (csFileStripExtPtr) GetProcAddress(csApi.lib, "_csFileStripExt@4");
	csApi.csFileStripDir = (csFileStripDirPtr) GetProcAddress(csApi.lib, "_csFileStripDir@4");
	csApi.csFontLoad = (csFontLoadPtr) GetProcAddress(csApi.lib, "_csFontLoad@4");
	csApi.csFontFree = (csFontFreePtr) GetProcAddress(csApi.lib, "_csFontFree@4");
	csApi.csMousePosition = (csMousePositionPtr) GetProcAddress(csApi.lib, "_csMousePosition@8");
	csApi.csMouseHide = (csMouseHidePtr) GetProcAddress(csApi.lib, "_csMouseHide@4");
	csApi.csMouseX = (csMouseXPtr) GetProcAddress(csApi.lib, "_csMouseX@0");
	csApi.csMouseY = (csMouseYPtr) GetProcAddress(csApi.lib, "_csMouseY@0");
	csApi.csMouseHit = (csMouseHitPtr) GetProcAddress(csApi.lib, "_csMouseHit@4");
	csApi.csMouseDown = (csMouseDownPtr) GetProcAddress(csApi.lib, "_csMouseDown@4");
	csApi.csMouseGet = (csMouseGetPtr) GetProcAddress(csApi.lib, "_csMouseGet@0");
	csApi.csMouseReleased = (csMouseReleasedPtr) GetProcAddress(csApi.lib, "_csMouseReleased@0");
	csApi.csKeyHit = (csKeyHitPtr) GetProcAddress(csApi.lib, "_csKeyHit@4");
	csApi.csKeyDown = (csKeyDownPtr) GetProcAddress(csApi.lib, "_csKeyDown@4");
	csApi.csKeyGet = (csKeyGetPtr) GetProcAddress(csApi.lib, "_csKeyGet@0");
	csApi.csKeyReleased = (csKeyReleasedPtr) GetProcAddress(csApi.lib, "_csKeyReleased@0");
	csApi.csJoyName = (csJoyNamePtr) GetProcAddress(csApi.lib, "_csJoyName@4");
	csApi.csJoyButton = (csJoyButtonPtr) GetProcAddress(csApi.lib, "_csJoyButton@8");
	csApi.csJoyAxis = (csJoyAxisPtr) GetProcAddress(csApi.lib, "_csJoyAxis@8");
	csApi.csJoyNumAxes = (csJoyNumAxesPtr) GetProcAddress(csApi.lib, "_csJoyNumAxes@4");
	csApi.csLightNode = (csLightNodePtr) GetProcAddress(csApi.lib, "_csLightNode@4");
	csApi.csLightType = (csLightTypePtr) GetProcAddress(csApi.lib, "_csLightType@8");
	csApi.csLightRadius = (csLightRadiusPtr) GetProcAddress(csApi.lib, "_csLightRadius@8");
	csApi.csLightAmbient = (csLightAmbientPtr) GetProcAddress(csApi.lib, "_csLightAmbient@8");
	csApi.csLightDiffuse = (csLightDiffusePtr) GetProcAddress(csApi.lib, "_csLightDiffuse@8");
	csApi.csLightSpecular = (csLightSpecularPtr) GetProcAddress(csApi.lib, "_csLightSpecular@8");
	csApi.csMaterialCreate = (csMaterialCreatePtr) GetProcAddress(csApi.lib, "_csMaterialCreate@4");
	csApi.csMaterialLoad = (csMaterialLoadPtr) GetProcAddress(csApi.lib, "_csMaterialLoad@4");
	csApi.csMaterialSave = (csMaterialSavePtr) GetProcAddress(csApi.lib, "_csMaterialSave@12");
	csApi.csMaterialFree = (csMaterialFreePtr) GetProcAddress(csApi.lib, "_csMaterialFree@4");
	csApi.csMaterialFind = (csMaterialFindPtr) GetProcAddress(csApi.lib, "_csMaterialFind@4");
	csApi.csMaterialSetType = (csMaterialSetTypePtr) GetProcAddress(csApi.lib, "_csMaterialSetType@8");
	csApi.csMaterialSetFlags = (csMaterialSetFlagsPtr) GetProcAddress(csApi.lib, "_csMaterialSetFlags@8");
	csApi.csMaterialSetTexture = (csMaterialSetTexturePtr) GetProcAddress(csApi.lib, "_csMaterialSetTexture@12");
	csApi.csMaterialSetAmbient = (csMaterialSetAmbientPtr) GetProcAddress(csApi.lib, "_csMaterialSetAmbient@8");
	csApi.csMaterialSetDiffuse = (csMaterialSetDiffusePtr) GetProcAddress(csApi.lib, "_csMaterialSetDiffuse@8");
	csApi.csMaterialSetEmissive = (csMaterialSetEmissivePtr) GetProcAddress(csApi.lib, "_csMaterialSetEmissive@8");
	csApi.csMaterialSetSpecular = (csMaterialSetSpecularPtr) GetProcAddress(csApi.lib, "_csMaterialSetSpecular@8");
	csApi.csMaterialSetShininess = (csMaterialSetShininessPtr) GetProcAddress(csApi.lib, "_csMaterialSetShininess@8");
	csApi.csMaterialSetParam = (csMaterialSetParamPtr) GetProcAddress(csApi.lib, "_csMaterialSetParam@8");
	csApi.csMaterialGetName = (csMaterialGetNamePtr) GetProcAddress(csApi.lib, "_csMaterialGetName@4");
	csApi.csMaterialGetType = (csMaterialGetTypePtr) GetProcAddress(csApi.lib, "_csMaterialGetType@4");
	csApi.csMaterialGetFlags = (csMaterialGetFlagsPtr) GetProcAddress(csApi.lib, "_csMaterialGetFlags@4");
	csApi.csMaterialGetTexture = (csMaterialGetTexturePtr) GetProcAddress(csApi.lib, "_csMaterialGetTexture@8");
	csApi.csMaterialGetAmbient = (csMaterialGetAmbientPtr) GetProcAddress(csApi.lib, "_csMaterialGetAmbient@4");
	csApi.csMaterialGetDiffuse = (csMaterialGetDiffusePtr) GetProcAddress(csApi.lib, "_csMaterialGetDiffuse@4");
	csApi.csMaterialGetEmissive = (csMaterialGetEmissivePtr) GetProcAddress(csApi.lib, "_csMaterialGetEmissive@4");
	csApi.csMaterialGetSpecular = (csMaterialGetSpecularPtr) GetProcAddress(csApi.lib, "_csMaterialGetSpecular@4");
	csApi.csMaterialGetShininess = (csMaterialGetShininessPtr) GetProcAddress(csApi.lib, "_csMaterialGetShininess@4");
	csApi.csMaterialGetParam = (csMaterialGetParamPtr) GetProcAddress(csApi.lib, "_csMaterialGetParam@4");
	csApi.csMathFloor = (csMathFloorPtr) GetProcAddress(csApi.lib, "_csMathFloor@4");
	csApi.csMathCeil = (csMathCeilPtr) GetProcAddress(csApi.lib, "_csMathCeil@4");
	csApi.csMathAbs = (csMathAbsPtr) GetProcAddress(csApi.lib, "_csMathAbs@4");
	csApi.csMathSqr = (csMathSqrPtr) GetProcAddress(csApi.lib, "_csMathSqr@4");
	csApi.csMathSin = (csMathSinPtr) GetProcAddress(csApi.lib, "_csMathSin@4");
	csApi.csMathCos = (csMathCosPtr) GetProcAddress(csApi.lib, "_csMathCos@4");
	csApi.csMathTan = (csMathTanPtr) GetProcAddress(csApi.lib, "_csMathTan@4");
	csApi.csMathASin = (csMathASinPtr) GetProcAddress(csApi.lib, "_csMathASin@4");
	csApi.csMathACos = (csMathACosPtr) GetProcAddress(csApi.lib, "_csMathACos@4");
	csApi.csMathATan = (csMathATanPtr) GetProcAddress(csApi.lib, "_csMathATan@4");
	csApi.csMathATan2 = (csMathATan2Ptr) GetProcAddress(csApi.lib, "_csMathATan2@8");
	csApi.csMathExp = (csMathExpPtr) GetProcAddress(csApi.lib, "_csMathExp@4");
	csApi.csMathLog = (csMathLogPtr) GetProcAddress(csApi.lib, "_csMathLog@4");
	csApi.csMathLog10 = (csMathLog10Ptr) GetProcAddress(csApi.lib, "_csMathLog10@4");
	csApi.csMathRand = (csMathRandPtr) GetProcAddress(csApi.lib, "_csMathRand@8");
	csApi.csMathRandSeed = (csMathRandSeedPtr) GetProcAddress(csApi.lib, "_csMathRandSeed@4");
	csApi.csMatrixCreate = (csMatrixCreatePtr) GetProcAddress(csApi.lib, "_csMatrixCreate@0");
	csApi.csMatrixFree = (csMatrixFreePtr) GetProcAddress(csApi.lib, "_csMatrixFree@4");
	csApi.csMatrixAdd = (csMatrixAddPtr) GetProcAddress(csApi.lib, "_csMatrixAdd@8");
	csApi.csMatrixCopy = (csMatrixCopyPtr) GetProcAddress(csApi.lib, "_csMatrixCopy@8");
	csApi.csMatrixDiv = (csMatrixDivPtr) GetProcAddress(csApi.lib, "_csMatrixDiv@8");
	csApi.csMatrixElement = (csMatrixElementPtr) GetProcAddress(csApi.lib, "_csMatrixElement@12");
	csApi.csMatrixEqual = (csMatrixEqualPtr) GetProcAddress(csApi.lib, "_csMatrixEqual@8");
	csApi.csMatrixGetRotation = (csMatrixGetRotationPtr) GetProcAddress(csApi.lib, "_csMatrixGetRotation@8");
	csApi.csMatrixGetTranslation = (csMatrixGetTranslationPtr) GetProcAddress(csApi.lib, "_csMatrixGetTranslation@8");
	csApi.csMatrixIdentity = (csMatrixIdentityPtr) GetProcAddress(csApi.lib, "_csMatrixIdentity@4");
	csApi.csMatrixInterpolate = (csMatrixInterpolatePtr) GetProcAddress(csApi.lib, "_csMatrixInterpolate@12");
	csApi.csMatrixInvert = (csMatrixInvertPtr) GetProcAddress(csApi.lib, "_csMatrixInvert@4");
	csApi.csMatrixMul = (csMatrixMulPtr) GetProcAddress(csApi.lib, "_csMatrixMul@8");
	csApi.csMatrixSet = (csMatrixSetPtr) GetProcAddress(csApi.lib, "_csMatrixSet@16");
	csApi.csMatrixSetRotation = (csMatrixSetRotationPtr) GetProcAddress(csApi.lib, "_csMatrixSetRotation@8");
	csApi.csMatrixSetScale = (csMatrixSetScalePtr) GetProcAddress(csApi.lib, "_csMatrixSetScale@8");
	csApi.csMatrixSetTranslation = (csMatrixSetTranslationPtr) GetProcAddress(csApi.lib, "_csMatrixSetTranslation@8");
	csApi.csMatrixSub = (csMatrixSubPtr) GetProcAddress(csApi.lib, "_csMatrixSub@8");
	csApi.csMatrixTranspose = (csMatrixTransposePtr) GetProcAddress(csApi.lib, "_csMatrixTranspose@4");
	csApi.csMeshLoad = (csMeshLoadPtr) GetProcAddress(csApi.lib, "_csMeshLoad@4");
	csApi.csMeshTerrainLoad = (csMeshTerrainLoadPtr) GetProcAddress(csApi.lib, "_csMeshTerrainLoad@4");
	csApi.csMeshFree = (csMeshFreePtr) GetProcAddress(csApi.lib, "_csMeshFree@4");
	csApi.csMeshNode = (csMeshNodePtr) GetProcAddress(csApi.lib, "_csMeshNode@16");
	csApi.csMeshOctreeNode = (csMeshOctreeNodePtr) GetProcAddress(csApi.lib, "_csMeshOctreeNode@16");
	csApi.csMeshScale = (csMeshScalePtr) GetProcAddress(csApi.lib, "_csMeshScale@16");
	csApi.csMeshFlip = (csMeshFlipPtr) GetProcAddress(csApi.lib, "_csMeshFlip@4");
	csApi.csMeshUpdateNormals = (csMeshUpdateNormalsPtr) GetProcAddress(csApi.lib, "_csMeshUpdateNormals@4");
	csApi.csMeshVerticesColor = (csMeshVerticesColorPtr) GetProcAddress(csApi.lib, "_csMeshVerticesColor@12");
	csApi.csMeshPlanarMapping = (csMeshPlanarMappingPtr) GetProcAddress(csApi.lib, "_csMeshPlanarMapping@8");
	csApi.csMeshWidth = (csMeshWidthPtr) GetProcAddress(csApi.lib, "_csMeshWidth@4");
	csApi.csMeshHeight = (csMeshHeightPtr) GetProcAddress(csApi.lib, "_csMeshHeight@4");
	csApi.csMeshDepth = (csMeshDepthPtr) GetProcAddress(csApi.lib, "_csMeshDepth@4");
	csApi.csNodeEmpty = (csNodeEmptyPtr) GetProcAddress(csApi.lib, "_csNodeEmpty@4");
	csApi.csNodeFree = (csNodeFreePtr) GetProcAddress(csApi.lib, "_csNodeFree@4");
	csApi.csNodeType = (csNodeTypePtr) GetProcAddress(csApi.lib, "_csNodeType@4");
	csApi.csNodeSetName = (csNodeSetNamePtr) GetProcAddress(csApi.lib, "_csNodeSetName@8");
	csApi.csNodeGetName = (csNodeGetNamePtr) GetProcAddress(csApi.lib, "_csNodeGetName@4");
	csApi.csNodePosition = (csNodePositionPtr) GetProcAddress(csApi.lib, "_csNodePosition@16");
	csApi.csNodeMove = (csNodeMovePtr) GetProcAddress(csApi.lib, "_csNodeMove@16");
	csApi.csNodeRotate = (csNodeRotatePtr) GetProcAddress(csApi.lib, "_csNodeRotate@16");
	csApi.csNodeTurn = (csNodeTurnPtr) GetProcAddress(csApi.lib, "_csNodeTurn@16");
	csApi.csNodeScale = (csNodeScalePtr) GetProcAddress(csApi.lib, "_csNodeScale@16");
	csApi.csNodeX = (csNodeXPtr) GetProcAddress(csApi.lib, "_csNodeX@8");
	csApi.csNodeY = (csNodeYPtr) GetProcAddress(csApi.lib, "_csNodeY@8");
	csApi.csNodeZ = (csNodeZPtr) GetProcAddress(csApi.lib, "_csNodeZ@8");
	csApi.csNodePitch = (csNodePitchPtr) GetProcAddress(csApi.lib, "_csNodePitch@4");
	csApi.csNodeYaw = (csNodeYawPtr) GetProcAddress(csApi.lib, "_csNodeYaw@4");
	csApi.csNodeRoll = (csNodeRollPtr) GetProcAddress(csApi.lib, "_csNodeRoll@4");
	csApi.csNodeScaleX = (csNodeScaleXPtr) GetProcAddress(csApi.lib, "_csNodeScaleX@4");
	csApi.csNodeScaleY = (csNodeScaleYPtr) GetProcAddress(csApi.lib, "_csNodeScaleY@4");
	csApi.csNodeScaleZ = (csNodeScaleZPtr) GetProcAddress(csApi.lib, "_csNodeScaleZ@4");
	csApi.csNodeWidth = (csNodeWidthPtr) GetProcAddress(csApi.lib, "_csNodeWidth@4");
	csApi.csNodeHeight = (csNodeHeightPtr) GetProcAddress(csApi.lib, "_csNodeHeight@4");
	csApi.csNodeDepth = (csNodeDepthPtr) GetProcAddress(csApi.lib, "_csNodeDepth@4");
	csApi.csNodeCastShadow = (csNodeCastShadowPtr) GetProcAddress(csApi.lib, "_csNodeCastShadow@8");
	csApi.csNodeHide = (csNodeHidePtr) GetProcAddress(csApi.lib, "_csNodeHide@8");
	csApi.csNodeMaterials = (csNodeMaterialsPtr) GetProcAddress(csApi.lib, "_csNodeMaterials@4");
	csApi.csNodeGetMaterial = (csNodeGetMaterialPtr) GetProcAddress(csApi.lib, "_csNodeGetMaterial@8");
	csApi.csNodeSetMaterial = (csNodeSetMaterialPtr) GetProcAddress(csApi.lib, "_csNodeSetMaterial@12");
	csApi.csNodeSetMaterialFast = (csNodeSetMaterialFastPtr) GetProcAddress(csApi.lib, "_csNodeSetMaterialFast@24");
	csApi.csNodeSetMaterialFlag = (csNodeSetMaterialFlagPtr) GetProcAddress(csApi.lib, "_csNodeSetMaterialFlag@16");
	csApi.csNodeSetPickGroup = (csNodeSetPickGroupPtr) GetProcAddress(csApi.lib, "_csNodeSetPickGroup@8");
	csApi.csNodeSetProperty = (csNodeSetPropertyPtr) GetProcAddress(csApi.lib, "_csNodeSetProperty@12");
	csApi.csNodeProperties = (csNodePropertiesPtr) GetProcAddress(csApi.lib, "_csNodeProperties@4");
	csApi.csNodeFindProperty = (csNodeFindPropertyPtr) GetProcAddress(csApi.lib, "_csNodeFindProperty@8");
	csApi.csNodePropertyName = (csNodePropertyNamePtr) GetProcAddress(csApi.lib, "_csNodePropertyName@8");
	csApi.csNodePropertyValue = (csNodePropertyValuePtr) GetProcAddress(csApi.lib, "_csNodePropertyValue@8");
	csApi.csNodeRemoveProperty = (csNodeRemovePropertyPtr) GetProcAddress(csApi.lib, "_csNodeRemoveProperty@8");
	csApi.csNodeSetParent = (csNodeSetParentPtr) GetProcAddress(csApi.lib, "_csNodeSetParent@8");
	csApi.csNodeGetParent = (csNodeGetParentPtr) GetProcAddress(csApi.lib, "_csNodeGetParent@4");
	csApi.csNodeChildren = (csNodeChildrenPtr) GetProcAddress(csApi.lib, "_csNodeChildren@4");
	csApi.csNodeChild = (csNodeChildPtr) GetProcAddress(csApi.lib, "_csNodeChild@8");
	csApi.csNodeFindChild = (csNodeFindChildPtr) GetProcAddress(csApi.lib, "_csNodeFindChild@12");
	csApi.csNodeSpeed = (csNodeSpeedPtr) GetProcAddress(csApi.lib, "_csNodeSpeed@8");
	csApi.csNodeLoop = (csNodeLoopPtr) GetProcAddress(csApi.lib, "_csNodeLoop@8");
	csApi.csNodeSetFrame = (csNodeSetFramePtr) GetProcAddress(csApi.lib, "_csNodeSetFrame@12");
	csApi.csNodeGetFrame = (csNodeGetFramePtr) GetProcAddress(csApi.lib, "_csNodeGetFrame@4");
	csApi.csNodeAttachToBone = (csNodeAttachToBonePtr) GetProcAddress(csApi.lib, "_csNodeAttachToBone@12");
	csApi.csNodeLookAt = (csNodeLookAtPtr) GetProcAddress(csApi.lib, "_csNodeLookAt@16");
	csApi.csParticleDataCreate = (csParticleDataCreatePtr) GetProcAddress(csApi.lib, "_csParticleDataCreate@4");
	csApi.csParticleDataLoad = (csParticleDataLoadPtr) GetProcAddress(csApi.lib, "_csParticleDataLoad@4");
	csApi.csParticleDataSave = (csParticleDataSavePtr) GetProcAddress(csApi.lib, "_csParticleDataSave@8");
	csApi.csParticleDataFree = (csParticleDataFreePtr) GetProcAddress(csApi.lib, "_csParticleDataFree@4");
	csApi.csParticleDataFind = (csParticleDataFindPtr) GetProcAddress(csApi.lib, "_csParticleDataFind@4");
	csApi.csParticleDataSetMaterial = (csParticleDataSetMaterialPtr) GetProcAddress(csApi.lib, "_csParticleDataSetMaterial@8");
	csApi.csParticleDataSetType = (csParticleDataSetTypePtr) GetProcAddress(csApi.lib, "_csParticleDataSetType@8");
	csApi.csParticleDataSetBox = (csParticleDataSetBoxPtr) GetProcAddress(csApi.lib, "_csParticleDataSetBox@16");
	csApi.csParticleDataSetDirection = (csParticleDataSetDirectionPtr) GetProcAddress(csApi.lib, "_csParticleDataSetDirection@16");
	csApi.csParticleDataSetRate = (csParticleDataSetRatePtr) GetProcAddress(csApi.lib, "_csParticleDataSetRate@12");
	csApi.csParticleDataSetColor = (csParticleDataSetColorPtr) GetProcAddress(csApi.lib, "_csParticleDataSetColor@12");
	csApi.csParticleDataSetLifeTime = (csParticleDataSetLifeTimePtr) GetProcAddress(csApi.lib, "_csParticleDataSetLifeTime@12");
	csApi.csParticleDataSetMaxAngle = (csParticleDataSetMaxAnglePtr) GetProcAddress(csApi.lib, "_csParticleDataSetMaxAngle@8");
	csApi.csParticleDataSetSize = (csParticleDataSetSizePtr) GetProcAddress(csApi.lib, "_csParticleDataSetSize@12");
	csApi.csParticleDataAddFadeOutAffector = (csParticleDataAddFadeOutAffectorPtr) GetProcAddress(csApi.lib, "_csParticleDataAddFadeOutAffector@12");
	csApi.csParticleDataAddGravityAffector = (csParticleDataAddGravityAffectorPtr) GetProcAddress(csApi.lib, "_csParticleDataAddGravityAffector@20");
	csApi.csParticleDataGetName = (csParticleDataGetNamePtr) GetProcAddress(csApi.lib, "_csParticleDataGetName@4");
	csApi.csParticleDataGetMaterial = (csParticleDataGetMaterialPtr) GetProcAddress(csApi.lib, "_csParticleDataGetMaterial@4");
	csApi.csParticleDataGetType = (csParticleDataGetTypePtr) GetProcAddress(csApi.lib, "_csParticleDataGetType@4");
	csApi.csParticleDataGetBoxWidth = (csParticleDataGetBoxWidthPtr) GetProcAddress(csApi.lib, "_csParticleDataGetBoxWidth@4");
	csApi.csParticleDataGetBoxHeight = (csParticleDataGetBoxHeightPtr) GetProcAddress(csApi.lib, "_csParticleDataGetBoxHeight@4");
	csApi.csParticleDataGetBoxDepth = (csParticleDataGetBoxDepthPtr) GetProcAddress(csApi.lib, "_csParticleDataGetBoxDepth@4");
	csApi.csParticleDataGetDirectionX = (csParticleDataGetDirectionXPtr) GetProcAddress(csApi.lib, "_csParticleDataGetDirectionX@4");
	csApi.csParticleDataGetDirectionY = (csParticleDataGetDirectionYPtr) GetProcAddress(csApi.lib, "_csParticleDataGetDirectionY@4");
	csApi.csParticleDataGetDirectionZ = (csParticleDataGetDirectionZPtr) GetProcAddress(csApi.lib, "_csParticleDataGetDirectionZ@4");
	csApi.csParticleDataGetMinRate = (csParticleDataGetMinRatePtr) GetProcAddress(csApi.lib, "_csParticleDataGetMinRate@4");
	csApi.csParticleDataGetMaxRate = (csParticleDataGetMaxRatePtr) GetProcAddress(csApi.lib, "_csParticleDataGetMaxRate@4");
	csApi.csParticleDataGetMinColor = (csParticleDataGetMinColorPtr) GetProcAddress(csApi.lib, "_csParticleDataGetMinColor@4");
	csApi.csParticleDataGetMaxColor = (csParticleDataGetMaxColorPtr) GetProcAddress(csApi.lib, "_csParticleDataGetMaxColor@4");
	csApi.csParticleDataGetMinLifeTime = (csParticleDataGetMinLifeTimePtr) GetProcAddress(csApi.lib, "_csParticleDataGetMinLifeTime@4");
	csApi.csParticleDataGetMaxLifeTime = (csParticleDataGetMaxLifeTimePtr) GetProcAddress(csApi.lib, "_csParticleDataGetMaxLifeTime@4");
	csApi.csParticleDataGetMaxAngle = (csParticleDataGetMaxAnglePtr) GetProcAddress(csApi.lib, "_csParticleDataGetMaxAngle@4");
	csApi.csParticleDataGetWidth = (csParticleDataGetWidthPtr) GetProcAddress(csApi.lib, "_csParticleDataGetWidth@4");
	csApi.csParticleDataGetHeight = (csParticleDataGetHeightPtr) GetProcAddress(csApi.lib, "_csParticleDataGetHeight@4");
	csApi.csParticleDataAffectors = (csParticleDataAffectorsPtr) GetProcAddress(csApi.lib, "_csParticleDataAffectors@4");
	csApi.csParticleDataGetAffectorType = (csParticleDataGetAffectorTypePtr) GetProcAddress(csApi.lib, "_csParticleDataGetAffectorType@8");
	csApi.csParticleDataGetAffectorColor = (csParticleDataGetAffectorColorPtr) GetProcAddress(csApi.lib, "_csParticleDataGetAffectorColor@8");
	csApi.csParticleDataGetAffectorTime = (csParticleDataGetAffectorTimePtr) GetProcAddress(csApi.lib, "_csParticleDataGetAffectorTime@8");
	csApi.csParticleDataGetAffectorGravityX = (csParticleDataGetAffectorGravityXPtr) GetProcAddress(csApi.lib, "_csParticleDataGetAffectorGravityX@8");
	csApi.csParticleDataGetAffectorGravityY = (csParticleDataGetAffectorGravityYPtr) GetProcAddress(csApi.lib, "_csParticleDataGetAffectorGravityY@8");
	csApi.csParticleDataGetAffectorGravityZ = (csParticleDataGetAffectorGravityZPtr) GetProcAddress(csApi.lib, "_csParticleDataGetAffectorGravityZ@8");
	csApi.csSceneBegin = (csSceneBeginPtr) GetProcAddress(csApi.lib, "_csSceneBegin@0");
	csApi.csSceneEnd = (csSceneEndPtr) GetProcAddress(csApi.lib, "_csSceneEnd@0");
	csApi.csSceneRender = (csSceneRenderPtr) GetProcAddress(csApi.lib, "_csSceneRender@4");
	csApi.csSceneAmbient = (csSceneAmbientPtr) GetProcAddress(csApi.lib, "_csSceneAmbient@4");
	csApi.csSceneShadow = (csSceneShadowPtr) GetProcAddress(csApi.lib, "_csSceneShadow@4");
	csApi.csSceneFog = (csSceneFogPtr) GetProcAddress(csApi.lib, "_csSceneFog@12");
	csApi.csSceneSkybox = (csSceneSkyboxPtr) GetProcAddress(csApi.lib, "_csSceneSkybox@24");
	csApi.csSceneSkydome = (csSceneSkydomePtr) GetProcAddress(csApi.lib, "_csSceneSkydome@20");
	csApi.csSceneTransformation = (csSceneTransformationPtr) GetProcAddress(csApi.lib, "_csSceneTransformation@8");
	csApi.csShaderRegister = (csShaderRegisterPtr) GetProcAddress(csApi.lib, "_csShaderRegister@28");
	csApi.csShaderRegisterFile = (csShaderRegisterFilePtr) GetProcAddress(csApi.lib, "_csShaderRegisterFile@28");
	csApi.csShaderAsmRegister = (csShaderAsmRegisterPtr) GetProcAddress(csApi.lib, "_csShaderAsmRegister@12");
	csApi.csShaderAsmRegisterFile = (csShaderAsmRegisterFilePtr) GetProcAddress(csApi.lib, "_csShaderAsmRegisterFile@12");
	csApi.csShaderPixelConstant = (csShaderPixelConstantPtr) GetProcAddress(csApi.lib, "_csShaderPixelConstant@20");
	csApi.csShaderVertexConstant = (csShaderVertexConstantPtr) GetProcAddress(csApi.lib, "_csShaderVertexConstant@20");
	csApi.csStringToInt = (csStringToIntPtr) GetProcAddress(csApi.lib, "_csStringToInt@4");
	csApi.csStringToFloat = (csStringToFloatPtr) GetProcAddress(csApi.lib, "_csStringToFloat@4");
	csApi.csStringFromInt = (csStringFromIntPtr) GetProcAddress(csApi.lib, "_csStringFromInt@4");
	csApi.csStringFromFloat = (csStringFromFloatPtr) GetProcAddress(csApi.lib, "_csStringFromFloat@4");
	csApi.csStringLeft = (csStringLeftPtr) GetProcAddress(csApi.lib, "_csStringLeft@8");
	csApi.csStringRight = (csStringRightPtr) GetProcAddress(csApi.lib, "_csStringRight@8");
	csApi.csStringMid = (csStringMidPtr) GetProcAddress(csApi.lib, "_csStringMid@12");
	csApi.csStringReplace = (csStringReplacePtr) GetProcAddress(csApi.lib, "_csStringReplace@12");
	csApi.csStringFind = (csStringFindPtr) GetProcAddress(csApi.lib, "_csStringFind@12");
	csApi.csStringUpper = (csStringUpperPtr) GetProcAddress(csApi.lib, "_csStringUpper@4");
	csApi.csStringLower = (csStringLowerPtr) GetProcAddress(csApi.lib, "_csStringLower@4");
	csApi.csStringTrim = (csStringTrimPtr) GetProcAddress(csApi.lib, "_csStringTrim@4");
	csApi.csStringChar = (csStringCharPtr) GetProcAddress(csApi.lib, "_csStringChar@4");
	csApi.csStringAscii = (csStringAsciiPtr) GetProcAddress(csApi.lib, "_csStringAscii@4");
	csApi.csStringLen = (csStringLenPtr) GetProcAddress(csApi.lib, "_csStringLen@4");
	csApi.csStringField = (csStringFieldPtr) GetProcAddress(csApi.lib, "_csStringField@12");
	csApi.csTerrainNode = (csTerrainNodePtr) GetProcAddress(csApi.lib, "_csTerrainNode@24");
	csApi.csTerrainScaleTexture = (csTerrainScaleTexturePtr) GetProcAddress(csApi.lib, "_csTerrainScaleTexture@12");
	csApi.csTextureCreate = (csTextureCreatePtr) GetProcAddress(csApi.lib, "_csTextureCreate@8");
	csApi.csTextureTargetCreate = (csTextureTargetCreatePtr) GetProcAddress(csApi.lib, "_csTextureTargetCreate@8");
	csApi.csTextureLoad = (csTextureLoadPtr) GetProcAddress(csApi.lib, "_csTextureLoad@8");
	csApi.csTextureFree = (csTextureFreePtr) GetProcAddress(csApi.lib, "_csTextureFree@4");
	csApi.csTextureFile = (csTextureFilePtr) GetProcAddress(csApi.lib, "_csTextureFile@4");
	csApi.csTextureWidth = (csTextureWidthPtr) GetProcAddress(csApi.lib, "_csTextureWidth@8");
	csApi.csTextureHeight = (csTextureHeightPtr) GetProcAddress(csApi.lib, "_csTextureHeight@8");
	csApi.csTextureLock = (csTextureLockPtr) GetProcAddress(csApi.lib, "_csTextureLock@4");
	csApi.csTextureUnlock = (csTextureUnlockPtr) GetProcAddress(csApi.lib, "_csTextureUnlock@4");
	csApi.csTextureColorKey = (csTextureColorKeyPtr) GetProcAddress(csApi.lib, "_csTextureColorKey@8");
	csApi.csTextureNormalize = (csTextureNormalizePtr) GetProcAddress(csApi.lib, "_csTextureNormalize@8");
	csApi.csTextureHWPointer = (csTextureHWPointerPtr) GetProcAddress(csApi.lib, "_csTextureHWPointer@4");
	csApi.csVectorCreate = (csVectorCreatePtr) GetProcAddress(csApi.lib, "_csVectorCreate@0");
	csApi.csVectorFree = (csVectorFreePtr) GetProcAddress(csApi.lib, "_csVectorFree@4");
	csApi.csVectorAdd = (csVectorAddPtr) GetProcAddress(csApi.lib, "_csVectorAdd@8");
	csApi.csVectorAddScale = (csVectorAddScalePtr) GetProcAddress(csApi.lib, "_csVectorAddScale@12");
	csApi.csVectorBetween = (csVectorBetweenPtr) GetProcAddress(csApi.lib, "_csVectorBetween@28");
	csApi.csVectorCopy = (csVectorCopyPtr) GetProcAddress(csApi.lib, "_csVectorCopy@8");
	csApi.csVectorCrossProduct = (csVectorCrossProductPtr) GetProcAddress(csApi.lib, "_csVectorCrossProduct@8");
	csApi.csVectorDotProduct = (csVectorDotProductPtr) GetProcAddress(csApi.lib, "_csVectorDotProduct@8");
	csApi.csVectorEqual = (csVectorEqualPtr) GetProcAddress(csApi.lib, "_csVectorEqual@12");
	csApi.csVectorDistance = (csVectorDistancePtr) GetProcAddress(csApi.lib, "_csVectorDistance@16");
	csApi.csVectorDistanceSquared = (csVectorDistanceSquaredPtr) GetProcAddress(csApi.lib, "_csVectorDistanceSquared@16");
	csApi.csVectorDiv = (csVectorDivPtr) GetProcAddress(csApi.lib, "_csVectorDiv@8");
	csApi.csVectorInterpolate = (csVectorInterpolatePtr) GetProcAddress(csApi.lib, "_csVectorInterpolate@12");
	csApi.csVectorInvert = (csVectorInvertPtr) GetProcAddress(csApi.lib, "_csVectorInvert@4");
	csApi.csVectorLength = (csVectorLengthPtr) GetProcAddress(csApi.lib, "_csVectorLength@4");
	csApi.csVectorLengthSquared = (csVectorLengthSquaredPtr) GetProcAddress(csApi.lib, "_csVectorLengthSquared@4");
	csApi.csVectorMul = (csVectorMulPtr) GetProcAddress(csApi.lib, "_csVectorMul@8");
	csApi.csVectorNormalize = (csVectorNormalizePtr) GetProcAddress(csApi.lib, "_csVectorNormalize@4");
	csApi.csVectorScale = (csVectorScalePtr) GetProcAddress(csApi.lib, "_csVectorScale@8");
	csApi.csVectorSet = (csVectorSetPtr) GetProcAddress(csApi.lib, "_csVectorSet@16");
	csApi.csVectorSub = (csVectorSubPtr) GetProcAddress(csApi.lib, "_csVectorSub@8");
	csApi.csVectorX = (csVectorXPtr) GetProcAddress(csApi.lib, "_csVectorX@4");
	csApi.csVectorY = (csVectorYPtr) GetProcAddress(csApi.lib, "_csVectorY@4");
	csApi.csVectorZ = (csVectorZPtr) GetProcAddress(csApi.lib, "_csVectorZ@4");
	csApi.csXMLRead = (csXMLReadPtr) GetProcAddress(csApi.lib, "_csXMLRead@4");
	csApi.csXMLWrite = (csXMLWritePtr) GetProcAddress(csApi.lib, "_csXMLWrite@4");
	csApi.csXMLClose = (csXMLClosePtr) GetProcAddress(csApi.lib, "_csXMLClose@4");
	csApi.csXMLReadNode = (csXMLReadNodePtr) GetProcAddress(csApi.lib, "_csXMLReadNode@4");
	csApi.csXMLNodeType = (csXMLNodeTypePtr) GetProcAddress(csApi.lib, "_csXMLNodeType@4");
	csApi.csXMLNodeName = (csXMLNodeNamePtr) GetProcAddress(csApi.lib, "_csXMLNodeName@4");
	csApi.csXMLNodeData = (csXMLNodeDataPtr) GetProcAddress(csApi.lib, "_csXMLNodeData@4");
	csApi.csXMLAttributeCount = (csXMLAttributeCountPtr) GetProcAddress(csApi.lib, "_csXMLAttributeCount@4");
	csApi.csXMLAttributeName = (csXMLAttributeNamePtr) GetProcAddress(csApi.lib, "_csXMLAttributeName@8");
	csApi.csXMLAttributeValue = (csXMLAttributeValuePtr) GetProcAddress(csApi.lib, "_csXMLAttributeValue@8");
	csApi.csXMLWriteHeader = (csXMLWriteHeaderPtr) GetProcAddress(csApi.lib, "_csXMLWriteHeader@4");
	csApi.csXMLWriteElement = (csXMLWriteElementPtr) GetProcAddress(csApi.lib, "_csXMLWriteElement@16");
	csApi.csXMLWriteClosingTag = (csXMLWriteClosingTagPtr) GetProcAddress(csApi.lib, "_csXMLWriteClosingTag@8");
	csApi.csXMLWriteText = (csXMLWriteTextPtr) GetProcAddress(csApi.lib, "_csXMLWriteText@8");
	csApi.csXMLWriteLineBreak = (csXMLWriteLineBreakPtr) GetProcAddress(csApi.lib, "_csXMLWriteLineBreak@4");
	csApi.csCoreInit();
}

void csCoreFinish()
{
	csApi.csCoreFinish();
	FreeLibrary(csApi.lib);
}

void csCoreMessage(const char* msg_, int error_)
{
	csApi.csCoreMessage(msg_, error_);
}

void csListenerUpdate(int node_)
{
	csApi.csListenerUpdate(node_);
}

void csSoundSetMasterVolume(float volume_)
{
	csApi.csSoundSetMasterVolume(volume_);
}

float csSoundGetMasterVolume(float volume_)
{
	return csApi.csSoundGetMasterVolume(volume_);
}

int csSoundLoad(const char* file_)
{
	return csApi.csSoundLoad(file_);
}

void csSoundFree(int sound_)
{
	csApi.csSoundFree(sound_);
}

int csSoundPlay2D(int sound_, int loop_)
{
	return csApi.csSoundPlay2D(sound_, loop_);
}

int csSoundPlay3D(int sound_, float x_, float y_, float z_, int loop_)
{
	return csApi.csSoundPlay3D(sound_, x_, y_, z_, loop_);
}

int csSoundIsPlaying(int sound_)
{
	return csApi.csSoundIsPlaying(sound_);
}

int csChannelPaused(int channel_)
{
	return csApi.csChannelPaused(channel_);
}

int csChannelFinished(int channel_)
{
	return csApi.csChannelFinished(channel_);
}

int csChannelLooped(int channel_)
{
	return csApi.csChannelLooped(channel_);
}

float csChannelGetMinDistance(int channel_)
{
	return csApi.csChannelGetMinDistance(channel_);
}

float csChannelGetMaxDistance(int channel_)
{
	return csApi.csChannelGetMaxDistance(channel_);
}

float csChannelGetPan(int channel_)
{
	return csApi.csChannelGetPan(channel_);
}

int csChannelGetPlayPosition(int channel_)
{
	return csApi.csChannelGetPlayPosition(channel_);
}

float csChannelX(int channel_)
{
	return csApi.csChannelX(channel_);
}

float csChannelY(int channel_)
{
	return csApi.csChannelY(channel_);
}

float csChannelZ(int channel_)
{
	return csApi.csChannelZ(channel_);
}

float csChannelGetVolume(int channel_)
{
	return csApi.csChannelGetVolume(channel_);
}

void csChannelPause(int channel_)
{
	csApi.csChannelPause(channel_);
}

void csChannelResume(int channel_)
{
	csApi.csChannelResume(channel_);
}

void csChannelSetDistance(int channel_, float min_, float max_)
{
	csApi.csChannelSetDistance(channel_, min_, max_);
}

void csChannelSetPan(int channel_, float pan_)
{
	csApi.csChannelSetPan(channel_, pan_);
}

void csChannelSetPosition(int channel_, float x_, float y_, float z_)
{
	csApi.csChannelSetPosition(channel_, x_, y_, z_);
}

void csChannelSetVolume(int channel_, float volume_)
{
	csApi.csChannelSetVolume(channel_, volume_);
}

void csChannelStop(int channel_)
{
	csApi.csChannelStop(channel_);
}

int csBillboardNode(int parent_)
{
	return csApi.csBillboardNode(parent_);
}

void csBillboardResize(int billboard_, float width_, float height_)
{
	csApi.csBillboardResize(billboard_, width_, height_);
}

float csBillboardWidth(int billboard_)
{
	return csApi.csBillboardWidth(billboard_);
}

float csBillboardHeight(int billboard_)
{
	return csApi.csBillboardHeight(billboard_);
}

int csCameraNode(int parent_)
{
	return csApi.csCameraNode(parent_);
}

void csCameraViewport(int cam_, float x1_, float y1_, float x2_, float y2_)
{
	csApi.csCameraViewport(cam_, x1_, y1_, x2_, y2_);
}

void csCameraRange(int cam_, float near_, float far_)
{
	csApi.csCameraRange(cam_, near_, far_);
}

void csCameraFov(int cam_, float fov_)
{
	csApi.csCameraFov(cam_, fov_);
}

void csCameraAspectRatio(int cam_, float ratio_)
{
	csApi.csCameraAspectRatio(cam_, ratio_);
}

void csCameraProjection(int cam_, float width_, float height_, float near_, float far_, int ortho_)
{
	csApi.csCameraProjection(cam_, width_, height_, near_, far_, ortho_);
}

void csCameraLine(int cam_, int x_, int y_, int line_vec_start_, int line_vec_end_)
{
	csApi.csCameraLine(cam_, x_, y_, line_vec_start_, line_vec_end_);
}

int csCameraPickNode(int cam_, int x_, int y_, int group_)
{
	return csApi.csCameraPickNode(cam_, x_, y_, group_);
}

void csCameraToScreen(int cam_, float x_, float y_, float z_, int vec_out_)
{
	csApi.csCameraToScreen(cam_, x_, y_, z_, vec_out_);
}

void csCameraRenderTarget(int cam_, int texture_)
{
	csApi.csCameraRenderTarget(cam_, texture_);
}

void csCameraClearFlags(int cam_, int flags_, int color_)
{
	csApi.csCameraClearFlags(cam_, flags_, color_);
}

void csCollisionSlide(int node_, float pos_x_, float pos_y_, float pos_z_, float dest_x_, float dest_y_, float dest_z_, float rad_x_, float rad_y_, float rad_z_, int vec_pos_, int vec_tri_a_, int vec_tri_b_, int vec_tri_c_)
{
	csApi.csCollisionSlide(node_, pos_x_, pos_y_, pos_z_, dest_x_, dest_y_, dest_z_, rad_x_, rad_y_, rad_z_, vec_pos_, vec_tri_a_, vec_tri_b_, vec_tri_c_);
}

int csCollisionLinePick(int node_, float pos_x_, float pos_y_, float pos_z_, float dest_x_, float dest_y_, float dest_z_, int vec_pos_, int vec_tri_a_, int vec_tri_b_, int vec_tri_c_)
{
	return csApi.csCollisionLinePick(node_, pos_x_, pos_y_, pos_z_, dest_x_, dest_y_, dest_z_, vec_pos_, vec_tri_a_, vec_tri_b_, vec_tri_c_);
}

int csCollisionLineNode(float pos_x_, float pos_y_, float pos_z_, float dest_x_, float dest_y_, float dest_z_)
{
	return csApi.csCollisionLineNode(pos_x_, pos_y_, pos_z_, dest_x_, dest_y_, dest_z_);
}

void csPackageAdd(const char* pak_)
{
	csApi.csPackageAdd(pak_);
}

int csDirList(const char* dir_)
{
	return csApi.csDirList(dir_);
}

void csDirClose(int dir_)
{
	csApi.csDirClose(dir_);
}

int csDirFileCount(int dir_)
{
	return csApi.csDirFileCount(dir_);
}

const char* csDirFileName(int dir_, int index_)
{
	return csApi.csDirFileName(dir_, index_);
}

int csDirFileIsDir(int dir_, int index_)
{
	return csApi.csDirFileIsDir(dir_, index_);
}

void csDisplayOpen(int width_, int height_, int depth_, int flags_, int win_)
{
	csApi.csDisplayOpen(width_, height_, depth_, flags_, win_);
}

void csDisplayClose()
{
	csApi.csDisplayClose();
}

void csDisplayCaption(const char* caption_)
{
	csApi.csDisplayCaption(caption_);
}

int csDisplayClosed()
{
	return csApi.csDisplayClosed();
}

int csDisplayWidth()
{
	return csApi.csDisplayWidth();
}

int csDisplayHeight()
{
	return csApi.csDisplayHeight();
}

int csDisplayFps()
{
	return csApi.csDisplayFps();
}

int csDisplayFeature(int feature_)
{
	return csApi.csDisplayFeature(feature_);
}

void csDisplayResize(int width_, int height_)
{
	csApi.csDisplayResize(width_, height_);
}

int csDisplayActive()
{
	return csApi.csDisplayActive();
}

void csDisplayScreenshot(const char* file_)
{
	csApi.csDisplayScreenshot(file_);
}

int csGetColor(int red_, int green_, int blue_, int alpha_)
{
	return csApi.csGetColor(red_, green_, blue_, alpha_);
}

int csGetRed(int color_)
{
	return csApi.csGetRed(color_);
}

int csGetGreen(int color_)
{
	return csApi.csGetGreen(color_);
}

int csGetBlue(int color_)
{
	return csApi.csGetBlue(color_);
}

int csGetAlpha(int color_)
{
	return csApi.csGetAlpha(color_);
}

void csSetColor(int color_)
{
	csApi.csSetColor(color_);
}

void csViewport(int x_, int y_, int w_, int h_)
{
	csApi.csViewport(x_, y_, w_, h_);
}

void csDrawLine(int x_, int y_, int x1_, int y1_)
{
	csApi.csDrawLine(x_, y_, x1_, y1_);
}

void csDrawRect(int x_, int y_, int w_, int h_)
{
	csApi.csDrawRect(x_, y_, w_, h_);
}

void csDrawTexture(int tex_, int x_, int y_)
{
	csApi.csDrawTexture(tex_, x_, y_);
}

void csDrawText(int font_, const char* text_, int x_, int y_)
{
	csApi.csDrawText(font_, text_, x_, y_);
}

int csTextWidth(int font_, const char* text_)
{
	return csApi.csTextWidth(font_, text_);
}

int csTextHeight(int font_, const char* text_)
{
	return csApi.csTextHeight(font_, text_);
}

int csEffectRegister(const char* effect_, int base_mat_)
{
	return csApi.csEffectRegister(effect_, base_mat_);
}

int csEffectRegisterFile(const char* effect_file_, int base_mat_)
{
	return csApi.csEffectRegisterFile(effect_file_, base_mat_);
}

void csEffectSetTechnique(int effect_, const char* technique_)
{
	csApi.csEffectSetTechnique(effect_, technique_);
}

void csEffectSetTexture(int effect_, const char* var_name_, int texture_)
{
	csApi.csEffectSetTexture(effect_, var_name_, texture_);
}

void csEffectSetBool(int effect_, const char* var_name_, int value_)
{
	csApi.csEffectSetBool(effect_, var_name_, value_);
}

void csEffectSetInt(int effect_, const char* var_name_, int value_)
{
	csApi.csEffectSetInt(effect_, var_name_, value_);
}

void csEffectSetFloat(int effect_, const char* var_name_, float value_)
{
	csApi.csEffectSetFloat(effect_, var_name_, value_);
}

void csEffectSetVector(int effect_, const char* var_name_, int vector_)
{
	csApi.csEffectSetVector(effect_, var_name_, vector_);
}

void csEffectSetMatrix(int effect_, const char* var_name_, int matrix_)
{
	csApi.csEffectSetMatrix(effect_, var_name_, matrix_);
}

int csEmitterNode(int particle_data_, int parent_)
{
	return csApi.csEmitterNode(particle_data_, parent_);
}

void csEmitterAddFadeOutAffector(int emitter_, int color_, int time_)
{
	csApi.csEmitterAddFadeOutAffector(emitter_, color_, time_);
}

void csEmitterAddGravityAffector(int emitter_, float grav_x_, float grav_y_, float grav_z_, int time_)
{
	csApi.csEmitterAddGravityAffector(emitter_, grav_x_, grav_y_, grav_z_, time_);
}

void csEmitterRemoveAffectors(int emitter_)
{
	csApi.csEmitterRemoveAffectors(emitter_);
}

int csEventGet()
{
	return csApi.csEventGet();
}

int csEventPoll()
{
	return csApi.csEventPoll();
}

void csEventPost(int id_, int from_, int to_, float a_, float b_, float c_, const char* str_)
{
	csApi.csEventPost(id_, from_, to_, a_, b_, c_, str_);
}

int csEventId()
{
	return csApi.csEventId();
}

int csEventFrom()
{
	return csApi.csEventFrom();
}

int csEventTo()
{
	return csApi.csEventTo();
}

float csEventA()
{
	return csApi.csEventA();
}

float csEventB()
{
	return csApi.csEventB();
}

float csEventC()
{
	return csApi.csEventC();
}

const char* csEventData()
{
	return csApi.csEventData();
}

int csFileRead(const char* file_)
{
	return csApi.csFileRead(file_);
}

int csFileWrite(const char* file_)
{
	return csApi.csFileWrite(file_);
}

void csFileClose(int file_)
{
	csApi.csFileClose(file_);
}

int csFileSize(int file_)
{
	return csApi.csFileSize(file_);
}

int csFilePos(int file_)
{
	return csApi.csFilePos(file_);
}

void csFileSeek(int file_, int pos_, int relative_)
{
	csApi.csFileSeek(file_, pos_, relative_);
}

int csFileReadByte(int file_)
{
	return csApi.csFileReadByte(file_);
}

int csFileReadShort(int file_)
{
	return csApi.csFileReadShort(file_);
}

int csFileReadInt(int file_)
{
	return csApi.csFileReadInt(file_);
}

float csFileReadFloat(int file_)
{
	return csApi.csFileReadFloat(file_);
}

const char* csFileReadString(int file_)
{
	return csApi.csFileReadString(file_);
}

void csFileReadBytes(int file_, int buf_, int size_)
{
	csApi.csFileReadBytes(file_, buf_, size_);
}

void csFileWriteByte(int file_, int value_)
{
	csApi.csFileWriteByte(file_, value_);
}

void csFileWriteShort(int file_, int value_)
{
	csApi.csFileWriteShort(file_, value_);
}

void csFileWriteInt(int file_, int value_)
{
	csApi.csFileWriteInt(file_, value_);
}

void csFileWriteFloat(int file_, float value_)
{
	csApi.csFileWriteFloat(file_, value_);
}

void csFileWriteString(int file_, const char* str_)
{
	csApi.csFileWriteString(file_, str_);
}

void csFileWriteBytes(int file_, int buf_, int size_)
{
	csApi.csFileWriteBytes(file_, buf_, size_);
}

const char* csFileGetExt(const char* filename_)
{
	return csApi.csFileGetExt(filename_);
}

const char* csFileGetDir(const char* filename_)
{
	return csApi.csFileGetDir(filename_);
}

const char* csFileStripExt(const char* filename_)
{
	return csApi.csFileStripExt(filename_);
}

const char* csFileStripDir(const char* filename_)
{
	return csApi.csFileStripDir(filename_);
}

int csFontLoad(const char* file_)
{
	return csApi.csFontLoad(file_);
}

void csFontFree(int font_)
{
	csApi.csFontFree(font_);
}

void csMousePosition(int x_, int y_)
{
	csApi.csMousePosition(x_, y_);
}

void csMouseHide(int hide_)
{
	csApi.csMouseHide(hide_);
}

int csMouseX()
{
	return csApi.csMouseX();
}

int csMouseY()
{
	return csApi.csMouseY();
}

int csMouseHit(int button_)
{
	return csApi.csMouseHit(button_);
}

int csMouseDown(int button_)
{
	return csApi.csMouseDown(button_);
}

int csMouseGet()
{
	return csApi.csMouseGet();
}

int csMouseReleased()
{
	return csApi.csMouseReleased();
}

int csKeyHit(int key_)
{
	return csApi.csKeyHit(key_);
}

int csKeyDown(int key_)
{
	return csApi.csKeyDown(key_);
}

int csKeyGet()
{
	return csApi.csKeyGet();
}

int csKeyReleased()
{
	return csApi.csKeyReleased();
}

const char* csJoyName(int id_)
{
	return csApi.csJoyName(id_);
}

int csJoyButton(int id_, int button_)
{
	return csApi.csJoyButton(id_, button_);
}

float csJoyAxis(int id_, int axis_)
{
	return csApi.csJoyAxis(id_, axis_);
}

int csJoyNumAxes(int id_)
{
	return csApi.csJoyNumAxes(id_);
}

int csLightNode(int parent_)
{
	return csApi.csLightNode(parent_);
}

void csLightType(int light_, int type_)
{
	csApi.csLightType(light_, type_);
}

void csLightRadius(int light_, float radius_)
{
	csApi.csLightRadius(light_, radius_);
}

void csLightAmbient(int light_, int color_)
{
	csApi.csLightAmbient(light_, color_);
}

void csLightDiffuse(int light_, int color_)
{
	csApi.csLightDiffuse(light_, color_);
}

void csLightSpecular(int light_, int color_)
{
	csApi.csLightSpecular(light_, color_);
}

int csMaterialCreate(const char* name_)
{
	return csApi.csMaterialCreate(name_);
}

int csMaterialLoad(const char* file_)
{
	return csApi.csMaterialLoad(file_);
}

void csMaterialSave(int mat_, const char* file_, const char* rel_path_)
{
	csApi.csMaterialSave(mat_, file_, rel_path_);
}

void csMaterialFree(int mat_)
{
	csApi.csMaterialFree(mat_);
}

int csMaterialFind(const char* name_)
{
	return csApi.csMaterialFind(name_);
}

void csMaterialSetType(int mat_, int newtype_)
{
	csApi.csMaterialSetType(mat_, newtype_);
}

void csMaterialSetFlags(int mat_, int flags_)
{
	csApi.csMaterialSetFlags(mat_, flags_);
}

void csMaterialSetTexture(int mat_, int tex_, int layer_)
{
	csApi.csMaterialSetTexture(mat_, tex_, layer_);
}

void csMaterialSetAmbient(int mat_, int color_)
{
	csApi.csMaterialSetAmbient(mat_, color_);
}

void csMaterialSetDiffuse(int mat_, int color_)
{
	csApi.csMaterialSetDiffuse(mat_, color_);
}

void csMaterialSetEmissive(int mat_, int color_)
{
	csApi.csMaterialSetEmissive(mat_, color_);
}

void csMaterialSetSpecular(int mat_, int color_)
{
	csApi.csMaterialSetSpecular(mat_, color_);
}

void csMaterialSetShininess(int mat_, float shininess_)
{
	csApi.csMaterialSetShininess(mat_, shininess_);
}

void csMaterialSetParam(int mat_, float param_)
{
	csApi.csMaterialSetParam(mat_, param_);
}

const char* csMaterialGetName(int mat_)
{
	return csApi.csMaterialGetName(mat_);
}

int csMaterialGetType(int mat_)
{
	return csApi.csMaterialGetType(mat_);
}

int csMaterialGetFlags(int mat_)
{
	return csApi.csMaterialGetFlags(mat_);
}

int csMaterialGetTexture(int mat_, int layer_)
{
	return csApi.csMaterialGetTexture(mat_, layer_);
}

int csMaterialGetAmbient(int mat_)
{
	return csApi.csMaterialGetAmbient(mat_);
}

int csMaterialGetDiffuse(int mat_)
{
	return csApi.csMaterialGetDiffuse(mat_);
}

int csMaterialGetEmissive(int mat_)
{
	return csApi.csMaterialGetEmissive(mat_);
}

int csMaterialGetSpecular(int mat_)
{
	return csApi.csMaterialGetSpecular(mat_);
}

float csMaterialGetShininess(int mat_)
{
	return csApi.csMaterialGetShininess(mat_);
}

float csMaterialGetParam(int mat_)
{
	return csApi.csMaterialGetParam(mat_);
}

float csMathFloor(float val_)
{
	return csApi.csMathFloor(val_);
}

float csMathCeil(float val_)
{
	return csApi.csMathCeil(val_);
}

float csMathAbs(float val_)
{
	return csApi.csMathAbs(val_);
}

float csMathSqr(float val_)
{
	return csApi.csMathSqr(val_);
}

float csMathSin(float val_)
{
	return csApi.csMathSin(val_);
}

float csMathCos(float val_)
{
	return csApi.csMathCos(val_);
}

float csMathTan(float val_)
{
	return csApi.csMathTan(val_);
}

float csMathASin(float val_)
{
	return csApi.csMathASin(val_);
}

float csMathACos(float val_)
{
	return csApi.csMathACos(val_);
}

float csMathATan(float val_)
{
	return csApi.csMathATan(val_);
}

float csMathATan2(float x_, float y_)
{
	return csApi.csMathATan2(x_, y_);
}

float csMathExp(float val_)
{
	return csApi.csMathExp(val_);
}

float csMathLog(float val_)
{
	return csApi.csMathLog(val_);
}

float csMathLog10(float val_)
{
	return csApi.csMathLog10(val_);
}

int csMathRand(int min_, int max_)
{
	return csApi.csMathRand(min_, max_);
}

void csMathRandSeed(int seed_)
{
	csApi.csMathRandSeed(seed_);
}

int csMatrixCreate()
{
	return csApi.csMatrixCreate();
}

void csMatrixFree(int matrix_)
{
	csApi.csMatrixFree(matrix_);
}

void csMatrixAdd(int matrix_, int matrix2_)
{
	csApi.csMatrixAdd(matrix_, matrix2_);
}

void csMatrixCopy(int matrix_, int matrix2_)
{
	csApi.csMatrixCopy(matrix_, matrix2_);
}

void csMatrixDiv(int matrix_, int matrix2_)
{
	csApi.csMatrixDiv(matrix_, matrix2_);
}

float csMatrixElement(int matrix_, int row_, int column_)
{
	return csApi.csMatrixElement(matrix_, row_, column_);
}

int csMatrixEqual(int matrix_, int matrix2_)
{
	return csApi.csMatrixEqual(matrix_, matrix2_);
}

void csMatrixGetRotation(int matrix_, int vector_)
{
	csApi.csMatrixGetRotation(matrix_, vector_);
}

void csMatrixGetTranslation(int matrix_, int vector_)
{
	csApi.csMatrixGetTranslation(matrix_, vector_);
}

void csMatrixIdentity(int matrix_)
{
	csApi.csMatrixIdentity(matrix_);
}

void csMatrixInterpolate(int matrix_, int matrix2_, float time_)
{
	csApi.csMatrixInterpolate(matrix_, matrix2_, time_);
}

int csMatrixInvert(int matrix_)
{
	return csApi.csMatrixInvert(matrix_);
}

void csMatrixMul(int matrix_, int matrix2_)
{
	csApi.csMatrixMul(matrix_, matrix2_);
}

void csMatrixSet(int matrix_, int row_, int column_, float val_)
{
	csApi.csMatrixSet(matrix_, row_, column_, val_);
}

void csMatrixSetRotation(int matrix_, int vector_)
{
	csApi.csMatrixSetRotation(matrix_, vector_);
}

void csMatrixSetScale(int matrix_, int vector_)
{
	csApi.csMatrixSetScale(matrix_, vector_);
}

void csMatrixSetTranslation(int matrix_, int vector_)
{
	csApi.csMatrixSetTranslation(matrix_, vector_);
}

void csMatrixSub(int matrix_, int matrix2_)
{
	csApi.csMatrixSub(matrix_, matrix2_);
}

void csMatrixTranspose(int matrix_)
{
	csApi.csMatrixTranspose(matrix_);
}

int csMeshLoad(const char* file_)
{
	return csApi.csMeshLoad(file_);
}

int csMeshTerrainLoad(const char* heightmap_)
{
	return csApi.csMeshTerrainLoad(heightmap_);
}

void csMeshFree(int mesh_)
{
	csApi.csMeshFree(mesh_);
}

int csMeshNode(int mesh_, int parent_, int col_info_, int tangent_mesh_)
{
	return csApi.csMeshNode(mesh_, parent_, col_info_, tangent_mesh_);
}

int csMeshOctreeNode(int mesh_, int parent_, int col_info_, int tangent_mesh_)
{
	return csApi.csMeshOctreeNode(mesh_, parent_, col_info_, tangent_mesh_);
}

void csMeshScale(int mesh_, float sx_, float sy_, float sz_)
{
	csApi.csMeshScale(mesh_, sx_, sy_, sz_);
}

void csMeshFlip(int mesh_)
{
	csApi.csMeshFlip(mesh_);
}

void csMeshUpdateNormals(int mesh_)
{
	csApi.csMeshUpdateNormals(mesh_);
}

void csMeshVerticesColor(int mesh_, int color_, int change_alpha_)
{
	csApi.csMeshVerticesColor(mesh_, color_, change_alpha_);
}

void csMeshPlanarMapping(int mesh_, float resolution_)
{
	csApi.csMeshPlanarMapping(mesh_, resolution_);
}

float csMeshWidth(int mesh_)
{
	return csApi.csMeshWidth(mesh_);
}

float csMeshHeight(int mesh_)
{
	return csApi.csMeshHeight(mesh_);
}

float csMeshDepth(int mesh_)
{
	return csApi.csMeshDepth(mesh_);
}

int csNodeEmpty(int parent_)
{
	return csApi.csNodeEmpty(parent_);
}

void csNodeFree(int node_)
{
	csApi.csNodeFree(node_);
}

int csNodeType(int node_)
{
	return csApi.csNodeType(node_);
}

void csNodeSetName(int node_, const char* name_)
{
	csApi.csNodeSetName(node_, name_);
}

const char* csNodeGetName(int node_)
{
	return csApi.csNodeGetName(node_);
}

void csNodePosition(int node_, float x_, float y_, float z_)
{
	csApi.csNodePosition(node_, x_, y_, z_);
}

void csNodeMove(int node_, float x_, float y_, float z_)
{
	csApi.csNodeMove(node_, x_, y_, z_);
}

void csNodeRotate(int node_, float pitch_, float yaw_, float roll_)
{
	csApi.csNodeRotate(node_, pitch_, yaw_, roll_);
}

void csNodeTurn(int node_, float pitch_, float yaw_, float roll_)
{
	csApi.csNodeTurn(node_, pitch_, yaw_, roll_);
}

void csNodeScale(int node_, float x_, float y_, float z_)
{
	csApi.csNodeScale(node_, x_, y_, z_);
}

float csNodeX(int node_, int absolute_)
{
	return csApi.csNodeX(node_, absolute_);
}

float csNodeY(int node_, int absolute_)
{
	return csApi.csNodeY(node_, absolute_);
}

float csNodeZ(int node_, int absolute_)
{
	return csApi.csNodeZ(node_, absolute_);
}

float csNodePitch(int node_)
{
	return csApi.csNodePitch(node_);
}

float csNodeYaw(int node_)
{
	return csApi.csNodeYaw(node_);
}

float csNodeRoll(int node_)
{
	return csApi.csNodeRoll(node_);
}

float csNodeScaleX(int node_)
{
	return csApi.csNodeScaleX(node_);
}

float csNodeScaleY(int node_)
{
	return csApi.csNodeScaleY(node_);
}

float csNodeScaleZ(int node_)
{
	return csApi.csNodeScaleZ(node_);
}

float csNodeWidth(int node_)
{
	return csApi.csNodeWidth(node_);
}

float csNodeHeight(int node_)
{
	return csApi.csNodeHeight(node_);
}

float csNodeDepth(int node_)
{
	return csApi.csNodeDepth(node_);
}

void csNodeCastShadow(int node_, int cast_)
{
	csApi.csNodeCastShadow(node_, cast_);
}

void csNodeHide(int node_, int state_)
{
	csApi.csNodeHide(node_, state_);
}

int csNodeMaterials(int node_)
{
	return csApi.csNodeMaterials(node_);
}

int csNodeGetMaterial(int node_, int mat_index_)
{
	return csApi.csNodeGetMaterial(node_, mat_index_);
}

void csNodeSetMaterial(int node_, int mat_, int mat_index_)
{
	csApi.csNodeSetMaterial(node_, mat_, mat_index_);
}

void csNodeSetMaterialFast(int node_, int index_, int type_, int flags_, int tex1_, int tex2_)
{
	csApi.csNodeSetMaterialFast(node_, index_, type_, flags_, tex1_, tex2_);
}

void csNodeSetMaterialFlag(int node_, int index_, int flag_, int state_)
{
	csApi.csNodeSetMaterialFlag(node_, index_, flag_, state_);
}

void csNodeSetPickGroup(int n_, int group_)
{
	csApi.csNodeSetPickGroup(n_, group_);
}

void csNodeSetProperty(int node_, const char* name_, const char* value_)
{
	csApi.csNodeSetProperty(node_, name_, value_);
}

int csNodeProperties(int node_)
{
	return csApi.csNodeProperties(node_);
}

int csNodeFindProperty(int node_, const char* name_)
{
	return csApi.csNodeFindProperty(node_, name_);
}

const char* csNodePropertyName(int node_, int index_)
{
	return csApi.csNodePropertyName(node_, index_);
}

const char* csNodePropertyValue(int node_, int index_)
{
	return csApi.csNodePropertyValue(node_, index_);
}

void csNodeRemoveProperty(int node_, int index_)
{
	csApi.csNodeRemoveProperty(node_, index_);
}

void csNodeSetParent(int node_, int parent_)
{
	csApi.csNodeSetParent(node_, parent_);
}

int csNodeGetParent(int node_)
{
	return csApi.csNodeGetParent(node_);
}

int csNodeChildren(int node_)
{
	return csApi.csNodeChildren(node_);
}

int csNodeChild(int node_, int index_)
{
	return csApi.csNodeChild(node_, index_);
}

int csNodeFindChild(int node_, const char* name_, int recursive_)
{
	return csApi.csNodeFindChild(node_, name_, recursive_);
}

void csNodeSpeed(int node_, float fps_)
{
	csApi.csNodeSpeed(node_, fps_);
}

void csNodeLoop(int node_, int loop_)
{
	csApi.csNodeLoop(node_, loop_);
}

void csNodeSetFrame(int node_, int start_, int finish_)
{
	csApi.csNodeSetFrame(node_, start_, finish_);
}

int csNodeGetFrame(int node_)
{
	return csApi.csNodeGetFrame(node_);
}

void csNodeAttachToBone(int n_, int n2_, const char* bonename_)
{
	csApi.csNodeAttachToBone(n_, n2_, bonename_);
}

void csNodeLookAt(int node_, float x_, float y_, float z_)
{
	csApi.csNodeLookAt(node_, x_, y_, z_);
}

int csParticleDataCreate(const char* name_)
{
	return csApi.csParticleDataCreate(name_);
}

int csParticleDataLoad(const char* file_)
{
	return csApi.csParticleDataLoad(file_);
}

void csParticleDataSave(int part_data_, const char* file_)
{
	csApi.csParticleDataSave(part_data_, file_);
}

void csParticleDataFree(int part_data_)
{
	csApi.csParticleDataFree(part_data_);
}

int csParticleDataFind(const char* name_)
{
	return csApi.csParticleDataFind(name_);
}

void csParticleDataSetMaterial(int part_data_, const char* mat_name_)
{
	csApi.csParticleDataSetMaterial(part_data_, mat_name_);
}

void csParticleDataSetType(int part_data_, int type_)
{
	csApi.csParticleDataSetType(part_data_, type_);
}

void csParticleDataSetBox(int part_data_, float width_, float height_, float depth_)
{
	csApi.csParticleDataSetBox(part_data_, width_, height_, depth_);
}

void csParticleDataSetDirection(int part_data_, float x_, float y_, float z_)
{
	csApi.csParticleDataSetDirection(part_data_, x_, y_, z_);
}

void csParticleDataSetRate(int part_data_, int min_, int max_)
{
	csApi.csParticleDataSetRate(part_data_, min_, max_);
}

void csParticleDataSetColor(int part_data_, int min_, int max_)
{
	csApi.csParticleDataSetColor(part_data_, min_, max_);
}

void csParticleDataSetLifeTime(int part_data_, int min_, int max_)
{
	csApi.csParticleDataSetLifeTime(part_data_, min_, max_);
}

void csParticleDataSetMaxAngle(int part_data_, int angle_)
{
	csApi.csParticleDataSetMaxAngle(part_data_, angle_);
}

void csParticleDataSetSize(int part_data_, float width_, float height_)
{
	csApi.csParticleDataSetSize(part_data_, width_, height_);
}

void csParticleDataAddFadeOutAffector(int part_data_, int color_, int time_)
{
	csApi.csParticleDataAddFadeOutAffector(part_data_, color_, time_);
}

void csParticleDataAddGravityAffector(int part_data_, float grav_x_, float grav_y_, float grav_z_, int time_)
{
	csApi.csParticleDataAddGravityAffector(part_data_, grav_x_, grav_y_, grav_z_, time_);
}

const char* csParticleDataGetName(int part_)
{
	return csApi.csParticleDataGetName(part_);
}

const char* csParticleDataGetMaterial(int part_)
{
	return csApi.csParticleDataGetMaterial(part_);
}

int csParticleDataGetType(int part_)
{
	return csApi.csParticleDataGetType(part_);
}

float csParticleDataGetBoxWidth(int part_)
{
	return csApi.csParticleDataGetBoxWidth(part_);
}

float csParticleDataGetBoxHeight(int part_)
{
	return csApi.csParticleDataGetBoxHeight(part_);
}

float csParticleDataGetBoxDepth(int part_)
{
	return csApi.csParticleDataGetBoxDepth(part_);
}

float csParticleDataGetDirectionX(int part_)
{
	return csApi.csParticleDataGetDirectionX(part_);
}

float csParticleDataGetDirectionY(int part_)
{
	return csApi.csParticleDataGetDirectionY(part_);
}

float csParticleDataGetDirectionZ(int part_)
{
	return csApi.csParticleDataGetDirectionZ(part_);
}

int csParticleDataGetMinRate(int part_)
{
	return csApi.csParticleDataGetMinRate(part_);
}

int csParticleDataGetMaxRate(int part_)
{
	return csApi.csParticleDataGetMaxRate(part_);
}

int csParticleDataGetMinColor(int part_)
{
	return csApi.csParticleDataGetMinColor(part_);
}

int csParticleDataGetMaxColor(int part_)
{
	return csApi.csParticleDataGetMaxColor(part_);
}

int csParticleDataGetMinLifeTime(int part_)
{
	return csApi.csParticleDataGetMinLifeTime(part_);
}

int csParticleDataGetMaxLifeTime(int part_)
{
	return csApi.csParticleDataGetMaxLifeTime(part_);
}

int csParticleDataGetMaxAngle(int part_)
{
	return csApi.csParticleDataGetMaxAngle(part_);
}

float csParticleDataGetWidth(int part_)
{
	return csApi.csParticleDataGetWidth(part_);
}

float csParticleDataGetHeight(int part_)
{
	return csApi.csParticleDataGetHeight(part_);
}

int csParticleDataAffectors(int part_)
{
	return csApi.csParticleDataAffectors(part_);
}

int csParticleDataGetAffectorType(int part_, int index_)
{
	return csApi.csParticleDataGetAffectorType(part_, index_);
}

int csParticleDataGetAffectorColor(int part_, int index_)
{
	return csApi.csParticleDataGetAffectorColor(part_, index_);
}

int csParticleDataGetAffectorTime(int part_, int index_)
{
	return csApi.csParticleDataGetAffectorTime(part_, index_);
}

float csParticleDataGetAffectorGravityX(int part_, int index_)
{
	return csApi.csParticleDataGetAffectorGravityX(part_, index_);
}

float csParticleDataGetAffectorGravityY(int part_, int index_)
{
	return csApi.csParticleDataGetAffectorGravityY(part_, index_);
}

float csParticleDataGetAffectorGravityZ(int part_, int index_)
{
	return csApi.csParticleDataGetAffectorGravityZ(part_, index_);
}

void csSceneBegin()
{
	csApi.csSceneBegin();
}

void csSceneEnd()
{
	csApi.csSceneEnd();
}

void csSceneRender(int camera_)
{
	csApi.csSceneRender(camera_);
}

void csSceneAmbient(int color_)
{
	csApi.csSceneAmbient(color_);
}

void csSceneShadow(int color_)
{
	csApi.csSceneShadow(color_);
}

void csSceneFog(int color_, float near_, float far_)
{
	csApi.csSceneFog(color_, near_, far_);
}

void csSceneSkybox(int top_, int bottom_, int left_, int right_, int front_, int back_)
{
	csApi.csSceneSkybox(top_, bottom_, left_, right_, front_, back_);
}

void csSceneSkydome(int tex_, float hres_, float yres_, float tex_percent_, float sphere_percent_)
{
	csApi.csSceneSkydome(tex_, hres_, yres_, tex_percent_, sphere_percent_);
}

void csSceneTransformation(int state_, int matrix_)
{
	csApi.csSceneTransformation(state_, matrix_);
}

int csShaderRegister(const char* pixel_shader_, const char* pixel_entry_, int pixel_format_, const char* vertex_shader_, const char* vertex_entry_, int vertex_format_, int base_mat_)
{
	return csApi.csShaderRegister(pixel_shader_, pixel_entry_, pixel_format_, vertex_shader_, vertex_entry_, vertex_format_, base_mat_);
}

int csShaderRegisterFile(const char* pixel_file_, const char* pixel_entry_, int pixel_format_, const char* vertex_file_, const char* vertex_entry_, int vertex_format_, int base_mat_)
{
	return csApi.csShaderRegisterFile(pixel_file_, pixel_entry_, pixel_format_, vertex_file_, vertex_entry_, vertex_format_, base_mat_);
}

int csShaderAsmRegister(const char* pixel_shader_, const char* vertex_shader_, int base_material_)
{
	return csApi.csShaderAsmRegister(pixel_shader_, vertex_shader_, base_material_);
}

int csShaderAsmRegisterFile(const char* pixel_file_, const char* vertex_file_, int base_mat_)
{
	return csApi.csShaderAsmRegisterFile(pixel_file_, vertex_file_, base_mat_);
}

void csShaderPixelConstant(int shader_, const char* name_, int start_register_, int data_, int count_)
{
	csApi.csShaderPixelConstant(shader_, name_, start_register_, data_, count_);
}

void csShaderVertexConstant(int shader_, const char* name_, int start_register_, int data_, int count_)
{
	csApi.csShaderVertexConstant(shader_, name_, start_register_, data_, count_);
}

int csStringToInt(const char* str_)
{
	return csApi.csStringToInt(str_);
}

float csStringToFloat(const char* str_)
{
	return csApi.csStringToFloat(str_);
}

const char* csStringFromInt(int number_)
{
	return csApi.csStringFromInt(number_);
}

const char* csStringFromFloat(float number_)
{
	return csApi.csStringFromFloat(number_);
}

const char* csStringLeft(const char* str_, int number_)
{
	return csApi.csStringLeft(str_, number_);
}

const char* csStringRight(const char* str_, int num_)
{
	return csApi.csStringRight(str_, num_);
}

const char* csStringMid(const char* str_, int pos_, int num_)
{
	return csApi.csStringMid(str_, pos_, num_);
}

const char* csStringReplace(const char* str_, const char* find_, const char* replace_)
{
	return csApi.csStringReplace(str_, find_, replace_);
}

int csStringFind(const char* str_, const char* find_, int offset_)
{
	return csApi.csStringFind(str_, find_, offset_);
}

const char* csStringUpper(const char* str_)
{
	return csApi.csStringUpper(str_);
}

const char* csStringLower(const char* str_)
{
	return csApi.csStringLower(str_);
}

const char* csStringTrim(const char* str_)
{
	return csApi.csStringTrim(str_);
}

const char* csStringChar(int ascii_)
{
	return csApi.csStringChar(ascii_);
}

int csStringAscii(const char* str_)
{
	return csApi.csStringAscii(str_);
}

int csStringLen(const char* str_)
{
	return csApi.csStringLen(str_);
}

const char* csStringField(const char* str_, const char* delimiter_, int index_)
{
	return csApi.csStringField(str_, delimiter_, index_);
}

int csTerrainNode(const char* heightmap_, int parent_, float width_, float height_, float depth_, int col_info_)
{
	return csApi.csTerrainNode(heightmap_, parent_, width_, height_, depth_, col_info_);
}

void csTerrainScaleTexture(int terrain_, float scale1_, float scale2_)
{
	csApi.csTerrainScaleTexture(terrain_, scale1_, scale2_);
}

int csTextureCreate(int width_, int height_)
{
	return csApi.csTextureCreate(width_, height_);
}

int csTextureTargetCreate(int width_, int height_)
{
	return csApi.csTextureTargetCreate(width_, height_);
}

int csTextureLoad(const char* file_, int mipmaps_)
{
	return csApi.csTextureLoad(file_, mipmaps_);
}

void csTextureFree(int tex_)
{
	csApi.csTextureFree(tex_);
}

const char* csTextureFile(int tex_)
{
	return csApi.csTextureFile(tex_);
}

int csTextureWidth(int tex_, int original_)
{
	return csApi.csTextureWidth(tex_, original_);
}

int csTextureHeight(int tex_, int original_)
{
	return csApi.csTextureHeight(tex_, original_);
}

int csTextureLock(int tex_)
{
	return csApi.csTextureLock(tex_);
}

void csTextureUnlock(int tex_)
{
	csApi.csTextureUnlock(tex_);
}

void csTextureColorKey(int tex_, int color_)
{
	csApi.csTextureColorKey(tex_, color_);
}

void csTextureNormalize(int tex_, float amplitude_)
{
	csApi.csTextureNormalize(tex_, amplitude_);
}

int csTextureHWPointer(int tex_)
{
	return csApi.csTextureHWPointer(tex_);
}

int csVectorCreate()
{
	return csApi.csVectorCreate();
}

void csVectorFree(int vector_)
{
	csApi.csVectorFree(vector_);
}

void csVectorAdd(int vector_, int vector2_)
{
	csApi.csVectorAdd(vector_, vector2_);
}

void csVectorAddScale(int vector_, int vector2_, float scale_)
{
	csApi.csVectorAddScale(vector_, vector2_, scale_);
}

int csVectorBetween(int vector_, float x0_, float y0_, float z0_, float x1_, float y1_, float z1_)
{
	return csApi.csVectorBetween(vector_, x0_, y0_, z0_, x1_, y1_, z1_);
}

void csVectorCopy(int vector_, int other_vector_)
{
	csApi.csVectorCopy(vector_, other_vector_);
}

void csVectorCrossProduct(int vector_, int vector2_)
{
	csApi.csVectorCrossProduct(vector_, vector2_);
}

float csVectorDotProduct(int vector_, int other_vector_)
{
	return csApi.csVectorDotProduct(vector_, other_vector_);
}

int csVectorEqual(int vector_, int other_vector_, float epsilon_)
{
	return csApi.csVectorEqual(vector_, other_vector_, epsilon_);
}

float csVectorDistance(int vector_, float x_, float y_, float z_)
{
	return csApi.csVectorDistance(vector_, x_, y_, z_);
}

float csVectorDistanceSquared(int vector_, float x_, float y_, float z_)
{
	return csApi.csVectorDistanceSquared(vector_, x_, y_, z_);
}

void csVectorDiv(int vector_, int vector2_)
{
	csApi.csVectorDiv(vector_, vector2_);
}

void csVectorInterpolate(int vector_, int vector2_, float d_)
{
	csApi.csVectorInterpolate(vector_, vector2_, d_);
}

void csVectorInvert(int vector_)
{
	csApi.csVectorInvert(vector_);
}

float csVectorLength(int vector_)
{
	return csApi.csVectorLength(vector_);
}

float csVectorLengthSquared(int vector_)
{
	return csApi.csVectorLengthSquared(vector_);
}

void csVectorMul(int vector_, int vector2_)
{
	csApi.csVectorMul(vector_, vector2_);
}

void csVectorNormalize(int vector_)
{
	csApi.csVectorNormalize(vector_);
}

void csVectorScale(int vector_, float scale_)
{
	csApi.csVectorScale(vector_, scale_);
}

void csVectorSet(int vector_, float x_, float y_, float z_)
{
	csApi.csVectorSet(vector_, x_, y_, z_);
}

void csVectorSub(int vector_, int vector2_)
{
	csApi.csVectorSub(vector_, vector2_);
}

float csVectorX(int vector_)
{
	return csApi.csVectorX(vector_);
}

float csVectorY(int vector_)
{
	return csApi.csVectorY(vector_);
}

float csVectorZ(int vector_)
{
	return csApi.csVectorZ(vector_);
}

int csXMLRead(const char* file_)
{
	return csApi.csXMLRead(file_);
}

int csXMLWrite(const char* file_)
{
	return csApi.csXMLWrite(file_);
}

void csXMLClose(int xml_)
{
	csApi.csXMLClose(xml_);
}

int csXMLReadNode(int xml_)
{
	return csApi.csXMLReadNode(xml_);
}

int csXMLNodeType(int xml_)
{
	return csApi.csXMLNodeType(xml_);
}

const char* csXMLNodeName(int xml_)
{
	return csApi.csXMLNodeName(xml_);
}

const char* csXMLNodeData(int xml_)
{
	return csApi.csXMLNodeData(xml_);
}

int csXMLAttributeCount(int xml_)
{
	return csApi.csXMLAttributeCount(xml_);
}

const char* csXMLAttributeName(int xml_, int index_)
{
	return csApi.csXMLAttributeName(xml_, index_);
}

const char* csXMLAttributeValue(int xml_, int index_)
{
	return csApi.csXMLAttributeValue(xml_, index_);
}

void csXMLWriteHeader(int xml_)
{
	csApi.csXMLWriteHeader(xml_);
}

void csXMLWriteElement(int xml_, const char* name_, const char* attributes_, int empty_)
{
	csApi.csXMLWriteElement(xml_, name_, attributes_, empty_);
}

void csXMLWriteClosingTag(int xml_, const char* name_)
{
	csApi.csXMLWriteClosingTag(xml_, name_);
}

void csXMLWriteText(int xml_, const char* text_)
{
	csApi.csXMLWriteText(xml_, text_);
}

void csXMLWriteLineBreak(int xml_)
{
	csApi.csXMLWriteLineBreak(xml_);
}
