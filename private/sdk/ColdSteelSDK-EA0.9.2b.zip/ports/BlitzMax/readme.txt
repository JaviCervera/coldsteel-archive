BlitzMax import files for the ColdSteel SDK.

Usage:

1) Copy "usr.mod" folder to the "mods" folder of your BlitzMax installation.
 That's all!

Remember to always have the "coldsteel.dll" file together with the exe of your programs!

Example program:

Import Usr.ColdSteel

csLibInit
csDisplayOpen 800, 600, 32, 0, 0
csDisplayClose
csLibFinish