Please read the 'End User License Agreement (EULA) for the ColdSteel SDK - Indie License' found in the "License" section of ColdSteelSDK.chm before using this software.

http://www.coldsteelengine.com