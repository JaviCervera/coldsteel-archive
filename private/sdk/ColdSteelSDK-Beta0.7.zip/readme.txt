This beta version of ColdSteel is for testing purposes
only. Redistribution of this package or any products made
with it is not allowed.

ColdSteel has been programmed by Javier "Jedive" San Juan.

The author of the map used in the example is �lvaro F. Celis.

www.coldsteelengine.com