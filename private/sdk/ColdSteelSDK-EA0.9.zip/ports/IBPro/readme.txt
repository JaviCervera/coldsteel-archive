IBasic Professional import files for the ColdSteel SDK.

Usage:

1) Copy "coldsteel.incc" to the "bin" folder of IBasic Professional.
2) Copy "coldsteel.lib" to the "libs" folder of IBasic Professional.
 That's all!

Remember to always have the "coldsteel.dll" file together with the exe of your programs!

Example program:

$MAIN 
CSLIBINIT()
CSDISPLAYOPEN(800, 600, 32, 0, 0) 
CSDISPLAYCLOSE()
CSLIBFINISH()