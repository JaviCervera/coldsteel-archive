#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "coldsteel.h"

typedef void (_stdcall* csLibInitPtr)();
typedef void (_stdcall* csLibFinishPtr)();
typedef int (_stdcall* csBillboardNodePtr)(int);
typedef void (_stdcall* csBillboardResizePtr)(int, float, float);
typedef float (_stdcall* csBillboardWidthPtr)(int);
typedef float (_stdcall* csBillboardHeightPtr)(int);
typedef int (_stdcall* csCameraNodePtr)(int);
typedef void (_stdcall* csCameraViewportPtr)(int, float, float, float, float);
typedef void (_stdcall* csCameraRangePtr)(int, float, float);
typedef void (_stdcall* csCameraFovPtr)(int, float);
typedef void (_stdcall* csCameraAspectRatioPtr)(int, float);
typedef void (_stdcall* csCameraProjectionPtr)(int, float, float, float, float, int);
typedef int (_stdcall* csCollisionGetPointPtr)(int, float, float, float, float, float, float);
typedef void (_stdcall* csCollisionGetSlidePtr)(int, float, float, float, float, float, float, float, float, float);
typedef void (_stdcall* csCollisionReturnDataPtr)(int);
typedef float (_stdcall* csCollisionDataXPtr)();
typedef float (_stdcall* csCollisionDataYPtr)();
typedef float (_stdcall* csCollisionDataZPtr)();
typedef void (_stdcall* csDisplayOpenPtr)(int, int, int, int, int);
typedef void (_stdcall* csDisplayClosePtr)();
typedef void (_stdcall* csDisplayCaptionPtr)(const char*);
typedef int (_stdcall* csDisplayClosedPtr)();
typedef int (_stdcall* csDisplayWidthPtr)();
typedef int (_stdcall* csDisplayHeightPtr)();
typedef int (_stdcall* csDisplayFpsPtr)();
typedef int (_stdcall* csDisplayFeaturePtr)(int);
typedef void (_stdcall* csDisplayResizePtr)(int, int);
typedef int (_stdcall* csGetColorPtr)(int, int, int, int);
typedef int (_stdcall* csGetAlphaPtr)(int);
typedef int (_stdcall* csGetRedPtr)(int);
typedef int (_stdcall* csGetGreenPtr)(int);
typedef int (_stdcall* csGetBluePtr)(int);
typedef void (_stdcall* csSetColorPtr)(int);
typedef void (_stdcall* csViewportPtr)(int, int, int, int);
typedef void (_stdcall* csDrawLinePtr)(int, int, int, int);
typedef void (_stdcall* csDrawRectPtr)(int, int, int, int);
typedef void (_stdcall* csDrawTexturePtr)(int, int, int);
typedef void (_stdcall* csDrawTextPtr)(int, const char*, int, int);
typedef int (_stdcall* csTextWidthPtr)(int, const char*);
typedef int (_stdcall* csTextHeightPtr)(int, const char*);
typedef int (_stdcall* csEmitterNodePtr)(int, int);
typedef void (_stdcall* csEmitterAddFadeOutAffectorPtr)(int, int, int);
typedef void (_stdcall* csEmitterAddGravityAffectorPtr)(int, float, float, float, int);
typedef void (_stdcall* csEmitterRemoveAffectorsPtr)(int);
typedef void (_stdcall* csAddZipPtr)(const char*);
typedef int (_stdcall* csFileReadPtr)(const char*);
typedef int (_stdcall* csFileWritePtr)(const char*);
typedef void (_stdcall* csFileClosePtr)(int);
typedef int (_stdcall* csFileSizePtr)(int);
typedef int (_stdcall* csFilePosPtr)(int);
typedef void (_stdcall* csFileSeekPtr)(int, int, int);
typedef int (_stdcall* csFileReadBytePtr)(int);
typedef int (_stdcall* csFileReadShortPtr)(int);
typedef int (_stdcall* csFileReadIntPtr)(int);
typedef float (_stdcall* csFileReadFloatPtr)(int);
typedef const char* (_stdcall* csFileReadStringPtr)(int);
typedef void (_stdcall* csFileReadBytesPtr)(int, int, int);
typedef void (_stdcall* csFileWriteBytePtr)(int, int);
typedef void (_stdcall* csFileWriteShortPtr)(int, int);
typedef void (_stdcall* csFileWriteIntPtr)(int, int);
typedef void (_stdcall* csFileWriteFloatPtr)(int, float);
typedef void (_stdcall* csFileWriteStringPtr)(int, const char*);
typedef void (_stdcall* csFileWriteBytesPtr)(int, int, int);
typedef int (_stdcall* csXMLReadPtr)(const char*);
typedef int (_stdcall* csXMLWritePtr)(const char*);
typedef void (_stdcall* csXMLClosePtr)(int);
typedef int (_stdcall* csXMLReadNodePtr)(int);
typedef int (_stdcall* csXMLNodeTypePtr)(int);
typedef const char* (_stdcall* csXMLNodeNamePtr)(int);
typedef const char* (_stdcall* csXMLNodeDataPtr)(int);
typedef int (_stdcall* csXMLAttributeCountPtr)(int);
typedef const char* (_stdcall* csXMLAttributeNamePtr)(int, int);
typedef const char* (_stdcall* csXMLAttributeValuePtr)(int, int);
typedef void (_stdcall* csXMLWriteHeaderPtr)(int);
typedef void (_stdcall* csXMLWriteElementPtr)(int, const char*, const char*, int);
typedef void (_stdcall* csXMLWriteClosingTagPtr)(int, const char*);
typedef void (_stdcall* csXMLWriteTextPtr)(int, const char*);
typedef void (_stdcall* csXMLWriteLineBreakPtr)(int);
typedef int (_stdcall* csFontLoadPtr)(const char*);
typedef void (_stdcall* csFontFreePtr)(int);
typedef void (_stdcall* csMousePositionPtr)(int, int);
typedef void (_stdcall* csMouseHidePtr)(int);
typedef int (_stdcall* csMouseXPtr)();
typedef int (_stdcall* csMouseYPtr)();
typedef int (_stdcall* csMouseHitPtr)(int);
typedef int (_stdcall* csMouseDownPtr)(int);
typedef int (_stdcall* csMouseGetPtr)();
typedef int (_stdcall* csMouseReleasedPtr)();
typedef int (_stdcall* csKeyHitPtr)(int);
typedef int (_stdcall* csKeyDownPtr)(int);
typedef int (_stdcall* csKeyGetPtr)();
typedef int (_stdcall* csKeyReleasedPtr)();
typedef int (_stdcall* csLightNodePtr)(int);
typedef void (_stdcall* csLightRadiusPtr)(int, float);
typedef void (_stdcall* csLightAmbientPtr)(int, int);
typedef void (_stdcall* csLightDiffusePtr)(int, int);
typedef void (_stdcall* csLightSpecularPtr)(int, int);
typedef int (_stdcall* csMaterialCreatePtr)(const char*);
typedef int (_stdcall* csMaterialLoadPtr)(const char*);
typedef void (_stdcall* csMaterialSavePtr)(int, const char*, const char*);
typedef void (_stdcall* csMaterialFreePtr)(int);
typedef int (_stdcall* csMaterialFindPtr)(const char*);
typedef void (_stdcall* csMaterialSetTypePtr)(int, int);
typedef void (_stdcall* csMaterialSetFlagsPtr)(int, int);
typedef void (_stdcall* csMaterialSetTexturePtr)(int, int, int);
typedef void (_stdcall* csMaterialSetAmbientPtr)(int, int);
typedef void (_stdcall* csMaterialSetDiffusePtr)(int, int);
typedef void (_stdcall* csMaterialSetEmissivePtr)(int, int);
typedef void (_stdcall* csMaterialSetSpecularPtr)(int, int);
typedef void (_stdcall* csMaterialSetShininessPtr)(int, float);
typedef void (_stdcall* csMaterialSetParamPtr)(int, float);
typedef const char* (_stdcall* csMaterialGetNamePtr)(int);
typedef int (_stdcall* csMaterialGetTypePtr)(int);
typedef int (_stdcall* csMaterialGetFlagsPtr)(int);
typedef int (_stdcall* csMaterialGetTexturePtr)(int, int);
typedef int (_stdcall* csMaterialGetAmbientPtr)(int);
typedef int (_stdcall* csMaterialGetDiffusePtr)(int);
typedef int (_stdcall* csMaterialGetEmissivePtr)(int);
typedef int (_stdcall* csMaterialGetSpecularPtr)(int);
typedef float (_stdcall* csMaterialGetShininessPtr)(int);
typedef float (_stdcall* csMaterialGetParamPtr)(int);
typedef int (_stdcall* csMatrixCreatePtr)();
typedef void (_stdcall* csMatrixFreePtr)(int);
typedef void (_stdcall* csMatrixMulPtr)(int, int);
typedef int (_stdcall* csMeshLoadPtr)(const char*);
typedef int (_stdcall* csMeshTerrainLoadPtr)(const char*);
typedef void (_stdcall* csMeshFreePtr)(int);
typedef int (_stdcall* csMeshNodePtr)(int, int, int, int);
typedef int (_stdcall* csMeshOctreeNodePtr)(int, int, int, int);
typedef void (_stdcall* csMeshScalePtr)(int, float, float, float);
typedef void (_stdcall* csMeshFlipPtr)(int);
typedef void (_stdcall* csMeshUpdateNormalsPtr)(int);
typedef void (_stdcall* csMeshVerticesColorPtr)(int, int, int);
typedef void (_stdcall* csMeshPlanarMappingPtr)(int, float);
typedef float (_stdcall* csMeshWidthPtr)(int);
typedef float (_stdcall* csMeshHeightPtr)(int);
typedef float (_stdcall* csMeshDepthPtr)(int);
typedef int (_stdcall* csNodeEmptyPtr)(int);
typedef void (_stdcall* csNodeFreePtr)(int);
typedef int (_stdcall* csNodeTypePtr)(int);
typedef void (_stdcall* csNodeSetNamePtr)(int, const char*);
typedef const char* (_stdcall* csNodeGetNamePtr)(int);
typedef void (_stdcall* csNodePositionPtr)(int, float, float, float);
typedef void (_stdcall* csNodeMovePtr)(int, float, float, float);
typedef void (_stdcall* csNodeRotatePtr)(int, float, float, float);
typedef void (_stdcall* csNodeTurnPtr)(int, float, float, float);
typedef void (_stdcall* csNodeScalePtr)(int, float, float, float);
typedef float (_stdcall* csNodeXPtr)(int, int);
typedef float (_stdcall* csNodeYPtr)(int, int);
typedef float (_stdcall* csNodeZPtr)(int, int);
typedef float (_stdcall* csNodePitchPtr)(int);
typedef float (_stdcall* csNodeYawPtr)(int);
typedef float (_stdcall* csNodeRollPtr)(int);
typedef float (_stdcall* csNodeScaleXPtr)(int);
typedef float (_stdcall* csNodeScaleYPtr)(int);
typedef float (_stdcall* csNodeScaleZPtr)(int);
typedef float (_stdcall* csNodeWidthPtr)(int);
typedef float (_stdcall* csNodeHeightPtr)(int);
typedef float (_stdcall* csNodeDepthPtr)(int);
typedef void (_stdcall* csNodeCastShadowPtr)(int, int);
typedef int (_stdcall* csNodeMaterialsPtr)(int);
typedef int (_stdcall* csNodeGetMaterialPtr)(int, int);
typedef void (_stdcall* csNodeSetMaterialPtr)(int, int, int);
typedef void (_stdcall* csNodeSetMaterialFastPtr)(int, int, int, int, int, int);
typedef void (_stdcall* csNodeCollisionPtr)(int, int, float, float, float);
typedef void (_stdcall* csNodeSetPropertyPtr)(int, const char*, const char*);
typedef int (_stdcall* csNodePropertiesPtr)(int);
typedef int (_stdcall* csNodeFindPropertyPtr)(int, const char*);
typedef const char* (_stdcall* csNodePropertyNamePtr)(int, int);
typedef const char* (_stdcall* csNodePropertyValuePtr)(int, int);
typedef void (_stdcall* csNodeRemovePropertyPtr)(int, int);
typedef void (_stdcall* csNodeSetParentPtr)(int, int);
typedef int (_stdcall* csNodeGetParentPtr)(int);
typedef int (_stdcall* csNodeChildrenPtr)(int);
typedef int (_stdcall* csNodeChildPtr)(int, int);
typedef int (_stdcall* csNodeFindChildPtr)(int, const char*, int);
typedef void (_stdcall* csNodeSpeedPtr)(int, int);
typedef void (_stdcall* csNodeLoopPtr)(int, int);
typedef void (_stdcall* csNodeSetFramePtr)(int, int, int);
typedef int (_stdcall* csNodeGetFramePtr)(int);
typedef int (_stdcall* csParticleDataCreatePtr)(const char*);
typedef int (_stdcall* csParticleDataLoadPtr)(const char*);
typedef void (_stdcall* csParticleDataSavePtr)(int, const char*);
typedef void (_stdcall* csParticleDataFreePtr)(int);
typedef int (_stdcall* csParticleDataFindPtr)(const char*);
typedef void (_stdcall* csParticleDataSetMaterialPtr)(int, const char*);
typedef void (_stdcall* csParticleDataSetTypePtr)(int, int);
typedef void (_stdcall* csParticleDataSetBoxPtr)(int, float, float, float);
typedef void (_stdcall* csParticleDataSetDirectionPtr)(int, float, float, float);
typedef void (_stdcall* csParticleDataSetRatePtr)(int, int, int);
typedef void (_stdcall* csParticleDataSetColorPtr)(int, int, int);
typedef void (_stdcall* csParticleDataSetLifeTimePtr)(int, int, int);
typedef void (_stdcall* csParticleDataSetMaxAnglePtr)(int, int);
typedef void (_stdcall* csParticleDataSetSizePtr)(int, float, float);
typedef void (_stdcall* csParticleDataAddFadeOutAffectorPtr)(int, int, int);
typedef void (_stdcall* csParticleDataAddGravityAffectorPtr)(int, float, float, float, int);
typedef const char* (_stdcall* csParticleDataGetNamePtr)(int);
typedef const char* (_stdcall* csParticleDataGetMaterialPtr)(int);
typedef int (_stdcall* csParticleDataGetTypePtr)(int);
typedef float (_stdcall* csParticleDataGetBoxWidthPtr)(int);
typedef float (_stdcall* csParticleDataGetBoxHeightPtr)(int);
typedef float (_stdcall* csParticleDataGetBoxDepthPtr)(int);
typedef float (_stdcall* csParticleDataGetDirectionXPtr)(int);
typedef float (_stdcall* csParticleDataGetDirectionYPtr)(int);
typedef float (_stdcall* csParticleDataGetDirectionZPtr)(int);
typedef int (_stdcall* csParticleDataGetMinRatePtr)(int);
typedef int (_stdcall* csParticleDataGetMaxRatePtr)(int);
typedef int (_stdcall* csParticleDataGetMinColorPtr)(int);
typedef int (_stdcall* csParticleDataGetMaxColorPtr)(int);
typedef int (_stdcall* csParticleDataGetMinLifeTimePtr)(int);
typedef int (_stdcall* csParticleDataGetMaxLifeTimePtr)(int);
typedef int (_stdcall* csParticleDataGetMaxAnglePtr)(int);
typedef float (_stdcall* csParticleDataGetWidthPtr)(int);
typedef float (_stdcall* csParticleDataGetHeightPtr)(int);
typedef int (_stdcall* csParticleDataAffectorsPtr)(int);
typedef int (_stdcall* csParticleDataGetAffectorTypePtr)(int, int);
typedef int (_stdcall* csParticleDataGetAffectorColorPtr)(int, int);
typedef int (_stdcall* csParticleDataGetAffectorTimePtr)(int, int);
typedef float (_stdcall* csParticleDataGetAffectorGravityXPtr)(int, int);
typedef float (_stdcall* csParticleDataGetAffectorGravityYPtr)(int, int);
typedef float (_stdcall* csParticleDataGetAffectorGravityZPtr)(int, int);
typedef void (_stdcall* csSceneTexturePathPtr)(const char*);
typedef void (_stdcall* csSceneBeginPtr)(int, int);
typedef void (_stdcall* csSceneEndPtr)();
typedef void (_stdcall* csSceneRenderPtr)(int);
typedef void (_stdcall* csSceneAmbientPtr)(int);
typedef void (_stdcall* csSceneFogPtr)(int, float, float);
typedef void (_stdcall* csSceneSkyboxPtr)(int, int, int, int, int, int);
typedef void (_stdcall* csSceneTransformationPtr)(int, int);
typedef int (_stdcall* csShaderRegisterPtr)(const char*, const char*, int, const char*, const char*, int, int);
typedef int (_stdcall* csShaderRegisterFilePtr)(const char*, const char*, int, const char*, const char*, int, int);
typedef int (_stdcall* csShaderAsmRegisterPtr)(const char*, const char*, int);
typedef int (_stdcall* csShaderAsmRegisterFilePtr)(const char*, const char*, int);
typedef void (_stdcall* csShaderPixelConstantPtr)(int, const char*, int, int, int);
typedef void (_stdcall* csShaderVertexConstantPtr)(int, const char*, int, int, int);
typedef int (_stdcall* csStringToIntPtr)(const char*);
typedef float (_stdcall* csStringToFloatPtr)(const char*);
typedef const char* (_stdcall* csStringFromIntPtr)(int);
typedef const char* (_stdcall* csStringFromFloatPtr)(float);
typedef const char* (_stdcall* csStringLeftPtr)(const char*, int);
typedef const char* (_stdcall* csStringRightPtr)(const char*, int);
typedef const char* (_stdcall* csStringMidPtr)(const char*, int, int);
typedef const char* (_stdcall* csStringReplacePtr)(const char*, const char*, const char*);
typedef int (_stdcall* csStringFindPtr)(const char*, const char*, int);
typedef const char* (_stdcall* csStringUpperPtr)(const char*);
typedef const char* (_stdcall* csStringLowerPtr)(const char*);
typedef const char* (_stdcall* csStringTrimPtr)(const char*);
typedef const char* (_stdcall* csStringCharPtr)(int);
typedef int (_stdcall* csStringAsciiPtr)(const char*);
typedef int (_stdcall* csStringLenPtr)(const char*);
typedef const char* (_stdcall* csStringFieldPtr)(const char*, const char*, int);
typedef int (_stdcall* csTerrainNodePtr)(const char*, int, float, float, float, int);
typedef void (_stdcall* csTerrainScaleTexturePtr)(int, float, float);
typedef int (_stdcall* csTextureLoadPtr)(const char*, int);
typedef void (_stdcall* csTextureFreePtr)(int);
typedef const char* (_stdcall* csTextureFilePtr)(int);
typedef int (_stdcall* csTextureWidthPtr)(int, int);
typedef int (_stdcall* csTextureHeightPtr)(int, int);
typedef int (_stdcall* csTextureLockPtr)(int);
typedef void (_stdcall* csTextureUnlockPtr)(int);
typedef void (_stdcall* csTextureColorKeyPtr)(int, int);
typedef void (_stdcall* csTextureNormalizePtr)(int, float);
typedef int (_stdcall* csVectorCreatePtr)();
typedef void (_stdcall* csVectorFreePtr)(int);
typedef void (_stdcall* csVectorAddPtr)(int, int);
typedef void (_stdcall* csVectorAddScalePtr)(int, int, float);
typedef int (_stdcall* csVectorBetweenPtr)(int, float, float, float, float, float, float);
typedef void (_stdcall* csVectorCopyPtr)(int, int);
typedef void (_stdcall* csVectorCrossProductPtr)(int, int);
typedef float (_stdcall* csVectorDotProductPtr)(int, int);
typedef int (_stdcall* csVectorEqualPtr)(int, int, float);
typedef float (_stdcall* csVectorDistancePtr)(int, float, float, float);
typedef float (_stdcall* csVectorDistanceSquaredPtr)(int, float, float, float);
typedef void (_stdcall* csVectorDivPtr)(int, int);
typedef void (_stdcall* csVectorInterpolatePtr)(int, int, float);
typedef void (_stdcall* csVectorInvertPtr)(int);
typedef float (_stdcall* csVectorLengthPtr)(int);
typedef float (_stdcall* csVectorLengthSquaredPtr)(int);
typedef void (_stdcall* csVectorMulPtr)(int, int);
typedef void (_stdcall* csVectorNormalizePtr)(int);
typedef void (_stdcall* csVectorScalePtr)(int, float);
typedef void (_stdcall* csVectorSetPtr)(int, float, float, float);
typedef void (_stdcall* csVectorSubPtr)(int, int);
typedef float (_stdcall* csVectorXPtr)(int);
typedef float (_stdcall* csVectorYPtr)(int);
typedef float (_stdcall* csVectorZPtr)(int);

struct csAPI_t
{
	HMODULE lib;
	csLibInitPtr csLibInit;
	csLibFinishPtr csLibFinish;
	csBillboardNodePtr csBillboardNode;
	csBillboardResizePtr csBillboardResize;
	csBillboardWidthPtr csBillboardWidth;
	csBillboardHeightPtr csBillboardHeight;
	csCameraNodePtr csCameraNode;
	csCameraViewportPtr csCameraViewport;
	csCameraRangePtr csCameraRange;
	csCameraFovPtr csCameraFov;
	csCameraAspectRatioPtr csCameraAspectRatio;
	csCameraProjectionPtr csCameraProjection;
	csCollisionGetPointPtr csCollisionGetPoint;
	csCollisionGetSlidePtr csCollisionGetSlide;
	csCollisionReturnDataPtr csCollisionReturnData;
	csCollisionDataXPtr csCollisionDataX;
	csCollisionDataYPtr csCollisionDataY;
	csCollisionDataZPtr csCollisionDataZ;
	csDisplayOpenPtr csDisplayOpen;
	csDisplayClosePtr csDisplayClose;
	csDisplayCaptionPtr csDisplayCaption;
	csDisplayClosedPtr csDisplayClosed;
	csDisplayWidthPtr csDisplayWidth;
	csDisplayHeightPtr csDisplayHeight;
	csDisplayFpsPtr csDisplayFps;
	csDisplayFeaturePtr csDisplayFeature;
	csDisplayResizePtr csDisplayResize;
	csGetColorPtr csGetColor;
	csGetAlphaPtr csGetAlpha;
	csGetRedPtr csGetRed;
	csGetGreenPtr csGetGreen;
	csGetBluePtr csGetBlue;
	csSetColorPtr csSetColor;
	csViewportPtr csViewport;
	csDrawLinePtr csDrawLine;
	csDrawRectPtr csDrawRect;
	csDrawTexturePtr csDrawTexture;
	csDrawTextPtr csDrawText;
	csTextWidthPtr csTextWidth;
	csTextHeightPtr csTextHeight;
	csEmitterNodePtr csEmitterNode;
	csEmitterAddFadeOutAffectorPtr csEmitterAddFadeOutAffector;
	csEmitterAddGravityAffectorPtr csEmitterAddGravityAffector;
	csEmitterRemoveAffectorsPtr csEmitterRemoveAffectors;
	csAddZipPtr csAddZip;
	csFileReadPtr csFileRead;
	csFileWritePtr csFileWrite;
	csFileClosePtr csFileClose;
	csFileSizePtr csFileSize;
	csFilePosPtr csFilePos;
	csFileSeekPtr csFileSeek;
	csFileReadBytePtr csFileReadByte;
	csFileReadShortPtr csFileReadShort;
	csFileReadIntPtr csFileReadInt;
	csFileReadFloatPtr csFileReadFloat;
	csFileReadStringPtr csFileReadString;
	csFileReadBytesPtr csFileReadBytes;
	csFileWriteBytePtr csFileWriteByte;
	csFileWriteShortPtr csFileWriteShort;
	csFileWriteIntPtr csFileWriteInt;
	csFileWriteFloatPtr csFileWriteFloat;
	csFileWriteStringPtr csFileWriteString;
	csFileWriteBytesPtr csFileWriteBytes;
	csXMLReadPtr csXMLRead;
	csXMLWritePtr csXMLWrite;
	csXMLClosePtr csXMLClose;
	csXMLReadNodePtr csXMLReadNode;
	csXMLNodeTypePtr csXMLNodeType;
	csXMLNodeNamePtr csXMLNodeName;
	csXMLNodeDataPtr csXMLNodeData;
	csXMLAttributeCountPtr csXMLAttributeCount;
	csXMLAttributeNamePtr csXMLAttributeName;
	csXMLAttributeValuePtr csXMLAttributeValue;
	csXMLWriteHeaderPtr csXMLWriteHeader;
	csXMLWriteElementPtr csXMLWriteElement;
	csXMLWriteClosingTagPtr csXMLWriteClosingTag;
	csXMLWriteTextPtr csXMLWriteText;
	csXMLWriteLineBreakPtr csXMLWriteLineBreak;
	csFontLoadPtr csFontLoad;
	csFontFreePtr csFontFree;
	csMousePositionPtr csMousePosition;
	csMouseHidePtr csMouseHide;
	csMouseXPtr csMouseX;
	csMouseYPtr csMouseY;
	csMouseHitPtr csMouseHit;
	csMouseDownPtr csMouseDown;
	csMouseGetPtr csMouseGet;
	csMouseReleasedPtr csMouseReleased;
	csKeyHitPtr csKeyHit;
	csKeyDownPtr csKeyDown;
	csKeyGetPtr csKeyGet;
	csKeyReleasedPtr csKeyReleased;
	csLightNodePtr csLightNode;
	csLightRadiusPtr csLightRadius;
	csLightAmbientPtr csLightAmbient;
	csLightDiffusePtr csLightDiffuse;
	csLightSpecularPtr csLightSpecular;
	csMaterialCreatePtr csMaterialCreate;
	csMaterialLoadPtr csMaterialLoad;
	csMaterialSavePtr csMaterialSave;
	csMaterialFreePtr csMaterialFree;
	csMaterialFindPtr csMaterialFind;
	csMaterialSetTypePtr csMaterialSetType;
	csMaterialSetFlagsPtr csMaterialSetFlags;
	csMaterialSetTexturePtr csMaterialSetTexture;
	csMaterialSetAmbientPtr csMaterialSetAmbient;
	csMaterialSetDiffusePtr csMaterialSetDiffuse;
	csMaterialSetEmissivePtr csMaterialSetEmissive;
	csMaterialSetSpecularPtr csMaterialSetSpecular;
	csMaterialSetShininessPtr csMaterialSetShininess;
	csMaterialSetParamPtr csMaterialSetParam;
	csMaterialGetNamePtr csMaterialGetName;
	csMaterialGetTypePtr csMaterialGetType;
	csMaterialGetFlagsPtr csMaterialGetFlags;
	csMaterialGetTexturePtr csMaterialGetTexture;
	csMaterialGetAmbientPtr csMaterialGetAmbient;
	csMaterialGetDiffusePtr csMaterialGetDiffuse;
	csMaterialGetEmissivePtr csMaterialGetEmissive;
	csMaterialGetSpecularPtr csMaterialGetSpecular;
	csMaterialGetShininessPtr csMaterialGetShininess;
	csMaterialGetParamPtr csMaterialGetParam;
	csMatrixCreatePtr csMatrixCreate;
	csMatrixFreePtr csMatrixFree;
	csMatrixMulPtr csMatrixMul;
	csMeshLoadPtr csMeshLoad;
	csMeshTerrainLoadPtr csMeshTerrainLoad;
	csMeshFreePtr csMeshFree;
	csMeshNodePtr csMeshNode;
	csMeshOctreeNodePtr csMeshOctreeNode;
	csMeshScalePtr csMeshScale;
	csMeshFlipPtr csMeshFlip;
	csMeshUpdateNormalsPtr csMeshUpdateNormals;
	csMeshVerticesColorPtr csMeshVerticesColor;
	csMeshPlanarMappingPtr csMeshPlanarMapping;
	csMeshWidthPtr csMeshWidth;
	csMeshHeightPtr csMeshHeight;
	csMeshDepthPtr csMeshDepth;
	csNodeEmptyPtr csNodeEmpty;
	csNodeFreePtr csNodeFree;
	csNodeTypePtr csNodeType;
	csNodeSetNamePtr csNodeSetName;
	csNodeGetNamePtr csNodeGetName;
	csNodePositionPtr csNodePosition;
	csNodeMovePtr csNodeMove;
	csNodeRotatePtr csNodeRotate;
	csNodeTurnPtr csNodeTurn;
	csNodeScalePtr csNodeScale;
	csNodeXPtr csNodeX;
	csNodeYPtr csNodeY;
	csNodeZPtr csNodeZ;
	csNodePitchPtr csNodePitch;
	csNodeYawPtr csNodeYaw;
	csNodeRollPtr csNodeRoll;
	csNodeScaleXPtr csNodeScaleX;
	csNodeScaleYPtr csNodeScaleY;
	csNodeScaleZPtr csNodeScaleZ;
	csNodeWidthPtr csNodeWidth;
	csNodeHeightPtr csNodeHeight;
	csNodeDepthPtr csNodeDepth;
	csNodeCastShadowPtr csNodeCastShadow;
	csNodeMaterialsPtr csNodeMaterials;
	csNodeGetMaterialPtr csNodeGetMaterial;
	csNodeSetMaterialPtr csNodeSetMaterial;
	csNodeSetMaterialFastPtr csNodeSetMaterialFast;
	csNodeCollisionPtr csNodeCollision;
	csNodeSetPropertyPtr csNodeSetProperty;
	csNodePropertiesPtr csNodeProperties;
	csNodeFindPropertyPtr csNodeFindProperty;
	csNodePropertyNamePtr csNodePropertyName;
	csNodePropertyValuePtr csNodePropertyValue;
	csNodeRemovePropertyPtr csNodeRemoveProperty;
	csNodeSetParentPtr csNodeSetParent;
	csNodeGetParentPtr csNodeGetParent;
	csNodeChildrenPtr csNodeChildren;
	csNodeChildPtr csNodeChild;
	csNodeFindChildPtr csNodeFindChild;
	csNodeSpeedPtr csNodeSpeed;
	csNodeLoopPtr csNodeLoop;
	csNodeSetFramePtr csNodeSetFrame;
	csNodeGetFramePtr csNodeGetFrame;
	csParticleDataCreatePtr csParticleDataCreate;
	csParticleDataLoadPtr csParticleDataLoad;
	csParticleDataSavePtr csParticleDataSave;
	csParticleDataFreePtr csParticleDataFree;
	csParticleDataFindPtr csParticleDataFind;
	csParticleDataSetMaterialPtr csParticleDataSetMaterial;
	csParticleDataSetTypePtr csParticleDataSetType;
	csParticleDataSetBoxPtr csParticleDataSetBox;
	csParticleDataSetDirectionPtr csParticleDataSetDirection;
	csParticleDataSetRatePtr csParticleDataSetRate;
	csParticleDataSetColorPtr csParticleDataSetColor;
	csParticleDataSetLifeTimePtr csParticleDataSetLifeTime;
	csParticleDataSetMaxAnglePtr csParticleDataSetMaxAngle;
	csParticleDataSetSizePtr csParticleDataSetSize;
	csParticleDataAddFadeOutAffectorPtr csParticleDataAddFadeOutAffector;
	csParticleDataAddGravityAffectorPtr csParticleDataAddGravityAffector;
	csParticleDataGetNamePtr csParticleDataGetName;
	csParticleDataGetMaterialPtr csParticleDataGetMaterial;
	csParticleDataGetTypePtr csParticleDataGetType;
	csParticleDataGetBoxWidthPtr csParticleDataGetBoxWidth;
	csParticleDataGetBoxHeightPtr csParticleDataGetBoxHeight;
	csParticleDataGetBoxDepthPtr csParticleDataGetBoxDepth;
	csParticleDataGetDirectionXPtr csParticleDataGetDirectionX;
	csParticleDataGetDirectionYPtr csParticleDataGetDirectionY;
	csParticleDataGetDirectionZPtr csParticleDataGetDirectionZ;
	csParticleDataGetMinRatePtr csParticleDataGetMinRate;
	csParticleDataGetMaxRatePtr csParticleDataGetMaxRate;
	csParticleDataGetMinColorPtr csParticleDataGetMinColor;
	csParticleDataGetMaxColorPtr csParticleDataGetMaxColor;
	csParticleDataGetMinLifeTimePtr csParticleDataGetMinLifeTime;
	csParticleDataGetMaxLifeTimePtr csParticleDataGetMaxLifeTime;
	csParticleDataGetMaxAnglePtr csParticleDataGetMaxAngle;
	csParticleDataGetWidthPtr csParticleDataGetWidth;
	csParticleDataGetHeightPtr csParticleDataGetHeight;
	csParticleDataAffectorsPtr csParticleDataAffectors;
	csParticleDataGetAffectorTypePtr csParticleDataGetAffectorType;
	csParticleDataGetAffectorColorPtr csParticleDataGetAffectorColor;
	csParticleDataGetAffectorTimePtr csParticleDataGetAffectorTime;
	csParticleDataGetAffectorGravityXPtr csParticleDataGetAffectorGravityX;
	csParticleDataGetAffectorGravityYPtr csParticleDataGetAffectorGravityY;
	csParticleDataGetAffectorGravityZPtr csParticleDataGetAffectorGravityZ;
	csSceneTexturePathPtr csSceneTexturePath;
	csSceneBeginPtr csSceneBegin;
	csSceneEndPtr csSceneEnd;
	csSceneRenderPtr csSceneRender;
	csSceneAmbientPtr csSceneAmbient;
	csSceneFogPtr csSceneFog;
	csSceneSkyboxPtr csSceneSkybox;
	csSceneTransformationPtr csSceneTransformation;
	csShaderRegisterPtr csShaderRegister;
	csShaderRegisterFilePtr csShaderRegisterFile;
	csShaderAsmRegisterPtr csShaderAsmRegister;
	csShaderAsmRegisterFilePtr csShaderAsmRegisterFile;
	csShaderPixelConstantPtr csShaderPixelConstant;
	csShaderVertexConstantPtr csShaderVertexConstant;
	csStringToIntPtr csStringToInt;
	csStringToFloatPtr csStringToFloat;
	csStringFromIntPtr csStringFromInt;
	csStringFromFloatPtr csStringFromFloat;
	csStringLeftPtr csStringLeft;
	csStringRightPtr csStringRight;
	csStringMidPtr csStringMid;
	csStringReplacePtr csStringReplace;
	csStringFindPtr csStringFind;
	csStringUpperPtr csStringUpper;
	csStringLowerPtr csStringLower;
	csStringTrimPtr csStringTrim;
	csStringCharPtr csStringChar;
	csStringAsciiPtr csStringAscii;
	csStringLenPtr csStringLen;
	csStringFieldPtr csStringField;
	csTerrainNodePtr csTerrainNode;
	csTerrainScaleTexturePtr csTerrainScaleTexture;
	csTextureLoadPtr csTextureLoad;
	csTextureFreePtr csTextureFree;
	csTextureFilePtr csTextureFile;
	csTextureWidthPtr csTextureWidth;
	csTextureHeightPtr csTextureHeight;
	csTextureLockPtr csTextureLock;
	csTextureUnlockPtr csTextureUnlock;
	csTextureColorKeyPtr csTextureColorKey;
	csTextureNormalizePtr csTextureNormalize;
	csVectorCreatePtr csVectorCreate;
	csVectorFreePtr csVectorFree;
	csVectorAddPtr csVectorAdd;
	csVectorAddScalePtr csVectorAddScale;
	csVectorBetweenPtr csVectorBetween;
	csVectorCopyPtr csVectorCopy;
	csVectorCrossProductPtr csVectorCrossProduct;
	csVectorDotProductPtr csVectorDotProduct;
	csVectorEqualPtr csVectorEqual;
	csVectorDistancePtr csVectorDistance;
	csVectorDistanceSquaredPtr csVectorDistanceSquared;
	csVectorDivPtr csVectorDiv;
	csVectorInterpolatePtr csVectorInterpolate;
	csVectorInvertPtr csVectorInvert;
	csVectorLengthPtr csVectorLength;
	csVectorLengthSquaredPtr csVectorLengthSquared;
	csVectorMulPtr csVectorMul;
	csVectorNormalizePtr csVectorNormalize;
	csVectorScalePtr csVectorScale;
	csVectorSetPtr csVectorSet;
	csVectorSubPtr csVectorSub;
	csVectorXPtr csVectorX;
	csVectorYPtr csVectorY;
	csVectorZPtr csVectorZ;
} csAPI;

void csLibInit()
{
	csAPI.lib = LoadLibrary("coldsteel.dll");
	csAPI.csLibInit = (csLibInitPtr) GetProcAddress(csAPI.lib, "_csLibInit@0");
	csAPI.csLibFinish = (csLibFinishPtr) GetProcAddress(csAPI.lib, "_csLibFinish@0");
	csAPI.csBillboardNode = (csBillboardNodePtr) GetProcAddress(csAPI.lib, "_csBillboardNode@4");
	csAPI.csBillboardResize = (csBillboardResizePtr) GetProcAddress(csAPI.lib, "_csBillboardResize@12");
	csAPI.csBillboardWidth = (csBillboardWidthPtr) GetProcAddress(csAPI.lib, "_csBillboardWidth@4");
	csAPI.csBillboardHeight = (csBillboardHeightPtr) GetProcAddress(csAPI.lib, "_csBillboardHeight@4");
	csAPI.csCameraNode = (csCameraNodePtr) GetProcAddress(csAPI.lib, "_csCameraNode@4");
	csAPI.csCameraViewport = (csCameraViewportPtr) GetProcAddress(csAPI.lib, "_csCameraViewport@20");
	csAPI.csCameraRange = (csCameraRangePtr) GetProcAddress(csAPI.lib, "_csCameraRange@12");
	csAPI.csCameraFov = (csCameraFovPtr) GetProcAddress(csAPI.lib, "_csCameraFov@8");
	csAPI.csCameraAspectRatio = (csCameraAspectRatioPtr) GetProcAddress(csAPI.lib, "_csCameraAspectRatio@8");
	csAPI.csCameraProjection = (csCameraProjectionPtr) GetProcAddress(csAPI.lib, "_csCameraProjection@24");
	csAPI.csCollisionGetPoint = (csCollisionGetPointPtr) GetProcAddress(csAPI.lib, "_csCollisionGetPoint@28");
	csAPI.csCollisionGetSlide = (csCollisionGetSlidePtr) GetProcAddress(csAPI.lib, "_csCollisionGetSlide@40");
	csAPI.csCollisionReturnData = (csCollisionReturnDataPtr) GetProcAddress(csAPI.lib, "_csCollisionReturnData@4");
	csAPI.csCollisionDataX = (csCollisionDataXPtr) GetProcAddress(csAPI.lib, "_csCollisionDataX@0");
	csAPI.csCollisionDataY = (csCollisionDataYPtr) GetProcAddress(csAPI.lib, "_csCollisionDataY@0");
	csAPI.csCollisionDataZ = (csCollisionDataZPtr) GetProcAddress(csAPI.lib, "_csCollisionDataZ@0");
	csAPI.csDisplayOpen = (csDisplayOpenPtr) GetProcAddress(csAPI.lib, "_csDisplayOpen@20");
	csAPI.csDisplayClose = (csDisplayClosePtr) GetProcAddress(csAPI.lib, "_csDisplayClose@0");
	csAPI.csDisplayCaption = (csDisplayCaptionPtr) GetProcAddress(csAPI.lib, "_csDisplayCaption@4");
	csAPI.csDisplayClosed = (csDisplayClosedPtr) GetProcAddress(csAPI.lib, "_csDisplayClosed@0");
	csAPI.csDisplayWidth = (csDisplayWidthPtr) GetProcAddress(csAPI.lib, "_csDisplayWidth@0");
	csAPI.csDisplayHeight = (csDisplayHeightPtr) GetProcAddress(csAPI.lib, "_csDisplayHeight@0");
	csAPI.csDisplayFps = (csDisplayFpsPtr) GetProcAddress(csAPI.lib, "_csDisplayFps@0");
	csAPI.csDisplayFeature = (csDisplayFeaturePtr) GetProcAddress(csAPI.lib, "_csDisplayFeature@4");
	csAPI.csDisplayResize = (csDisplayResizePtr) GetProcAddress(csAPI.lib, "_csDisplayResize@8");
	csAPI.csGetColor = (csGetColorPtr) GetProcAddress(csAPI.lib, "_csGetColor@16");
	csAPI.csGetAlpha = (csGetAlphaPtr) GetProcAddress(csAPI.lib, "_csGetAlpha@4");
	csAPI.csGetRed = (csGetRedPtr) GetProcAddress(csAPI.lib, "_csGetRed@4");
	csAPI.csGetGreen = (csGetGreenPtr) GetProcAddress(csAPI.lib, "_csGetGreen@4");
	csAPI.csGetBlue = (csGetBluePtr) GetProcAddress(csAPI.lib, "_csGetBlue@4");
	csAPI.csSetColor = (csSetColorPtr) GetProcAddress(csAPI.lib, "_csSetColor@4");
	csAPI.csViewport = (csViewportPtr) GetProcAddress(csAPI.lib, "_csViewport@16");
	csAPI.csDrawLine = (csDrawLinePtr) GetProcAddress(csAPI.lib, "_csDrawLine@16");
	csAPI.csDrawRect = (csDrawRectPtr) GetProcAddress(csAPI.lib, "_csDrawRect@16");
	csAPI.csDrawTexture = (csDrawTexturePtr) GetProcAddress(csAPI.lib, "_csDrawTexture@12");
	csAPI.csDrawText = (csDrawTextPtr) GetProcAddress(csAPI.lib, "_csDrawText@16");
	csAPI.csTextWidth = (csTextWidthPtr) GetProcAddress(csAPI.lib, "_csTextWidth@8");
	csAPI.csTextHeight = (csTextHeightPtr) GetProcAddress(csAPI.lib, "_csTextHeight@8");
	csAPI.csEmitterNode = (csEmitterNodePtr) GetProcAddress(csAPI.lib, "_csEmitterNode@8");
	csAPI.csEmitterAddFadeOutAffector = (csEmitterAddFadeOutAffectorPtr) GetProcAddress(csAPI.lib, "_csEmitterAddFadeOutAffector@12");
	csAPI.csEmitterAddGravityAffector = (csEmitterAddGravityAffectorPtr) GetProcAddress(csAPI.lib, "_csEmitterAddGravityAffector@20");
	csAPI.csEmitterRemoveAffectors = (csEmitterRemoveAffectorsPtr) GetProcAddress(csAPI.lib, "_csEmitterRemoveAffectors@4");
	csAPI.csAddZip = (csAddZipPtr) GetProcAddress(csAPI.lib, "_csAddZip@4");
	csAPI.csFileRead = (csFileReadPtr) GetProcAddress(csAPI.lib, "_csFileRead@4");
	csAPI.csFileWrite = (csFileWritePtr) GetProcAddress(csAPI.lib, "_csFileWrite@4");
	csAPI.csFileClose = (csFileClosePtr) GetProcAddress(csAPI.lib, "_csFileClose@4");
	csAPI.csFileSize = (csFileSizePtr) GetProcAddress(csAPI.lib, "_csFileSize@4");
	csAPI.csFilePos = (csFilePosPtr) GetProcAddress(csAPI.lib, "_csFilePos@4");
	csAPI.csFileSeek = (csFileSeekPtr) GetProcAddress(csAPI.lib, "_csFileSeek@12");
	csAPI.csFileReadByte = (csFileReadBytePtr) GetProcAddress(csAPI.lib, "_csFileReadByte@4");
	csAPI.csFileReadShort = (csFileReadShortPtr) GetProcAddress(csAPI.lib, "_csFileReadShort@4");
	csAPI.csFileReadInt = (csFileReadIntPtr) GetProcAddress(csAPI.lib, "_csFileReadInt@4");
	csAPI.csFileReadFloat = (csFileReadFloatPtr) GetProcAddress(csAPI.lib, "_csFileReadFloat@4");
	csAPI.csFileReadString = (csFileReadStringPtr) GetProcAddress(csAPI.lib, "_csFileReadString@4");
	csAPI.csFileReadBytes = (csFileReadBytesPtr) GetProcAddress(csAPI.lib, "_csFileReadBytes@12");
	csAPI.csFileWriteByte = (csFileWriteBytePtr) GetProcAddress(csAPI.lib, "_csFileWriteByte@8");
	csAPI.csFileWriteShort = (csFileWriteShortPtr) GetProcAddress(csAPI.lib, "_csFileWriteShort@8");
	csAPI.csFileWriteInt = (csFileWriteIntPtr) GetProcAddress(csAPI.lib, "_csFileWriteInt@8");
	csAPI.csFileWriteFloat = (csFileWriteFloatPtr) GetProcAddress(csAPI.lib, "_csFileWriteFloat@8");
	csAPI.csFileWriteString = (csFileWriteStringPtr) GetProcAddress(csAPI.lib, "_csFileWriteString@8");
	csAPI.csFileWriteBytes = (csFileWriteBytesPtr) GetProcAddress(csAPI.lib, "_csFileWriteBytes@12");
	csAPI.csXMLRead = (csXMLReadPtr) GetProcAddress(csAPI.lib, "_csXMLRead@4");
	csAPI.csXMLWrite = (csXMLWritePtr) GetProcAddress(csAPI.lib, "_csXMLWrite@4");
	csAPI.csXMLClose = (csXMLClosePtr) GetProcAddress(csAPI.lib, "_csXMLClose@4");
	csAPI.csXMLReadNode = (csXMLReadNodePtr) GetProcAddress(csAPI.lib, "_csXMLReadNode@4");
	csAPI.csXMLNodeType = (csXMLNodeTypePtr) GetProcAddress(csAPI.lib, "_csXMLNodeType@4");
	csAPI.csXMLNodeName = (csXMLNodeNamePtr) GetProcAddress(csAPI.lib, "_csXMLNodeName@4");
	csAPI.csXMLNodeData = (csXMLNodeDataPtr) GetProcAddress(csAPI.lib, "_csXMLNodeData@4");
	csAPI.csXMLAttributeCount = (csXMLAttributeCountPtr) GetProcAddress(csAPI.lib, "_csXMLAttributeCount@4");
	csAPI.csXMLAttributeName = (csXMLAttributeNamePtr) GetProcAddress(csAPI.lib, "_csXMLAttributeName@8");
	csAPI.csXMLAttributeValue = (csXMLAttributeValuePtr) GetProcAddress(csAPI.lib, "_csXMLAttributeValue@8");
	csAPI.csXMLWriteHeader = (csXMLWriteHeaderPtr) GetProcAddress(csAPI.lib, "_csXMLWriteHeader@4");
	csAPI.csXMLWriteElement = (csXMLWriteElementPtr) GetProcAddress(csAPI.lib, "_csXMLWriteElement@16");
	csAPI.csXMLWriteClosingTag = (csXMLWriteClosingTagPtr) GetProcAddress(csAPI.lib, "_csXMLWriteClosingTag@8");
	csAPI.csXMLWriteText = (csXMLWriteTextPtr) GetProcAddress(csAPI.lib, "_csXMLWriteText@8");
	csAPI.csXMLWriteLineBreak = (csXMLWriteLineBreakPtr) GetProcAddress(csAPI.lib, "_csXMLWriteLineBreak@4");
	csAPI.csFontLoad = (csFontLoadPtr) GetProcAddress(csAPI.lib, "_csFontLoad@4");
	csAPI.csFontFree = (csFontFreePtr) GetProcAddress(csAPI.lib, "_csFontFree@4");
	csAPI.csMousePosition = (csMousePositionPtr) GetProcAddress(csAPI.lib, "_csMousePosition@8");
	csAPI.csMouseHide = (csMouseHidePtr) GetProcAddress(csAPI.lib, "_csMouseHide@4");
	csAPI.csMouseX = (csMouseXPtr) GetProcAddress(csAPI.lib, "_csMouseX@0");
	csAPI.csMouseY = (csMouseYPtr) GetProcAddress(csAPI.lib, "_csMouseY@0");
	csAPI.csMouseHit = (csMouseHitPtr) GetProcAddress(csAPI.lib, "_csMouseHit@4");
	csAPI.csMouseDown = (csMouseDownPtr) GetProcAddress(csAPI.lib, "_csMouseDown@4");
	csAPI.csMouseGet = (csMouseGetPtr) GetProcAddress(csAPI.lib, "_csMouseGet@0");
	csAPI.csMouseReleased = (csMouseReleasedPtr) GetProcAddress(csAPI.lib, "_csMouseReleased@0");
	csAPI.csKeyHit = (csKeyHitPtr) GetProcAddress(csAPI.lib, "_csKeyHit@4");
	csAPI.csKeyDown = (csKeyDownPtr) GetProcAddress(csAPI.lib, "_csKeyDown@4");
	csAPI.csKeyGet = (csKeyGetPtr) GetProcAddress(csAPI.lib, "_csKeyGet@0");
	csAPI.csKeyReleased = (csKeyReleasedPtr) GetProcAddress(csAPI.lib, "_csKeyReleased@0");
	csAPI.csLightNode = (csLightNodePtr) GetProcAddress(csAPI.lib, "_csLightNode@4");
	csAPI.csLightRadius = (csLightRadiusPtr) GetProcAddress(csAPI.lib, "_csLightRadius@8");
	csAPI.csLightAmbient = (csLightAmbientPtr) GetProcAddress(csAPI.lib, "_csLightAmbient@8");
	csAPI.csLightDiffuse = (csLightDiffusePtr) GetProcAddress(csAPI.lib, "_csLightDiffuse@8");
	csAPI.csLightSpecular = (csLightSpecularPtr) GetProcAddress(csAPI.lib, "_csLightSpecular@8");
	csAPI.csMaterialCreate = (csMaterialCreatePtr) GetProcAddress(csAPI.lib, "_csMaterialCreate@4");
	csAPI.csMaterialLoad = (csMaterialLoadPtr) GetProcAddress(csAPI.lib, "_csMaterialLoad@4");
	csAPI.csMaterialSave = (csMaterialSavePtr) GetProcAddress(csAPI.lib, "_csMaterialSave@12");
	csAPI.csMaterialFree = (csMaterialFreePtr) GetProcAddress(csAPI.lib, "_csMaterialFree@4");
	csAPI.csMaterialFind = (csMaterialFindPtr) GetProcAddress(csAPI.lib, "_csMaterialFind@4");
	csAPI.csMaterialSetType = (csMaterialSetTypePtr) GetProcAddress(csAPI.lib, "_csMaterialSetType@8");
	csAPI.csMaterialSetFlags = (csMaterialSetFlagsPtr) GetProcAddress(csAPI.lib, "_csMaterialSetFlags@8");
	csAPI.csMaterialSetTexture = (csMaterialSetTexturePtr) GetProcAddress(csAPI.lib, "_csMaterialSetTexture@12");
	csAPI.csMaterialSetAmbient = (csMaterialSetAmbientPtr) GetProcAddress(csAPI.lib, "_csMaterialSetAmbient@8");
	csAPI.csMaterialSetDiffuse = (csMaterialSetDiffusePtr) GetProcAddress(csAPI.lib, "_csMaterialSetDiffuse@8");
	csAPI.csMaterialSetEmissive = (csMaterialSetEmissivePtr) GetProcAddress(csAPI.lib, "_csMaterialSetEmissive@8");
	csAPI.csMaterialSetSpecular = (csMaterialSetSpecularPtr) GetProcAddress(csAPI.lib, "_csMaterialSetSpecular@8");
	csAPI.csMaterialSetShininess = (csMaterialSetShininessPtr) GetProcAddress(csAPI.lib, "_csMaterialSetShininess@8");
	csAPI.csMaterialSetParam = (csMaterialSetParamPtr) GetProcAddress(csAPI.lib, "_csMaterialSetParam@8");
	csAPI.csMaterialGetName = (csMaterialGetNamePtr) GetProcAddress(csAPI.lib, "_csMaterialGetName@4");
	csAPI.csMaterialGetType = (csMaterialGetTypePtr) GetProcAddress(csAPI.lib, "_csMaterialGetType@4");
	csAPI.csMaterialGetFlags = (csMaterialGetFlagsPtr) GetProcAddress(csAPI.lib, "_csMaterialGetFlags@4");
	csAPI.csMaterialGetTexture = (csMaterialGetTexturePtr) GetProcAddress(csAPI.lib, "_csMaterialGetTexture@8");
	csAPI.csMaterialGetAmbient = (csMaterialGetAmbientPtr) GetProcAddress(csAPI.lib, "_csMaterialGetAmbient@4");
	csAPI.csMaterialGetDiffuse = (csMaterialGetDiffusePtr) GetProcAddress(csAPI.lib, "_csMaterialGetDiffuse@4");
	csAPI.csMaterialGetEmissive = (csMaterialGetEmissivePtr) GetProcAddress(csAPI.lib, "_csMaterialGetEmissive@4");
	csAPI.csMaterialGetSpecular = (csMaterialGetSpecularPtr) GetProcAddress(csAPI.lib, "_csMaterialGetSpecular@4");
	csAPI.csMaterialGetShininess = (csMaterialGetShininessPtr) GetProcAddress(csAPI.lib, "_csMaterialGetShininess@4");
	csAPI.csMaterialGetParam = (csMaterialGetParamPtr) GetProcAddress(csAPI.lib, "_csMaterialGetParam@4");
	csAPI.csMatrixCreate = (csMatrixCreatePtr) GetProcAddress(csAPI.lib, "_csMatrixCreate@0");
	csAPI.csMatrixFree = (csMatrixFreePtr) GetProcAddress(csAPI.lib, "_csMatrixFree@4");
	csAPI.csMatrixMul = (csMatrixMulPtr) GetProcAddress(csAPI.lib, "_csMatrixMul@8");
	csAPI.csMeshLoad = (csMeshLoadPtr) GetProcAddress(csAPI.lib, "_csMeshLoad@4");
	csAPI.csMeshTerrainLoad = (csMeshTerrainLoadPtr) GetProcAddress(csAPI.lib, "_csMeshTerrainLoad@4");
	csAPI.csMeshFree = (csMeshFreePtr) GetProcAddress(csAPI.lib, "_csMeshFree@4");
	csAPI.csMeshNode = (csMeshNodePtr) GetProcAddress(csAPI.lib, "_csMeshNode@16");
	csAPI.csMeshOctreeNode = (csMeshOctreeNodePtr) GetProcAddress(csAPI.lib, "_csMeshOctreeNode@16");
	csAPI.csMeshScale = (csMeshScalePtr) GetProcAddress(csAPI.lib, "_csMeshScale@16");
	csAPI.csMeshFlip = (csMeshFlipPtr) GetProcAddress(csAPI.lib, "_csMeshFlip@4");
	csAPI.csMeshUpdateNormals = (csMeshUpdateNormalsPtr) GetProcAddress(csAPI.lib, "_csMeshUpdateNormals@4");
	csAPI.csMeshVerticesColor = (csMeshVerticesColorPtr) GetProcAddress(csAPI.lib, "_csMeshVerticesColor@12");
	csAPI.csMeshPlanarMapping = (csMeshPlanarMappingPtr) GetProcAddress(csAPI.lib, "_csMeshPlanarMapping@8");
	csAPI.csMeshWidth = (csMeshWidthPtr) GetProcAddress(csAPI.lib, "_csMeshWidth@4");
	csAPI.csMeshHeight = (csMeshHeightPtr) GetProcAddress(csAPI.lib, "_csMeshHeight@4");
	csAPI.csMeshDepth = (csMeshDepthPtr) GetProcAddress(csAPI.lib, "_csMeshDepth@4");
	csAPI.csNodeEmpty = (csNodeEmptyPtr) GetProcAddress(csAPI.lib, "_csNodeEmpty@4");
	csAPI.csNodeFree = (csNodeFreePtr) GetProcAddress(csAPI.lib, "_csNodeFree@4");
	csAPI.csNodeType = (csNodeTypePtr) GetProcAddress(csAPI.lib, "_csNodeType@4");
	csAPI.csNodeSetName = (csNodeSetNamePtr) GetProcAddress(csAPI.lib, "_csNodeSetName@8");
	csAPI.csNodeGetName = (csNodeGetNamePtr) GetProcAddress(csAPI.lib, "_csNodeGetName@4");
	csAPI.csNodePosition = (csNodePositionPtr) GetProcAddress(csAPI.lib, "_csNodePosition@16");
	csAPI.csNodeMove = (csNodeMovePtr) GetProcAddress(csAPI.lib, "_csNodeMove@16");
	csAPI.csNodeRotate = (csNodeRotatePtr) GetProcAddress(csAPI.lib, "_csNodeRotate@16");
	csAPI.csNodeTurn = (csNodeTurnPtr) GetProcAddress(csAPI.lib, "_csNodeTurn@16");
	csAPI.csNodeScale = (csNodeScalePtr) GetProcAddress(csAPI.lib, "_csNodeScale@16");
	csAPI.csNodeX = (csNodeXPtr) GetProcAddress(csAPI.lib, "_csNodeX@8");
	csAPI.csNodeY = (csNodeYPtr) GetProcAddress(csAPI.lib, "_csNodeY@8");
	csAPI.csNodeZ = (csNodeZPtr) GetProcAddress(csAPI.lib, "_csNodeZ@8");
	csAPI.csNodePitch = (csNodePitchPtr) GetProcAddress(csAPI.lib, "_csNodePitch@4");
	csAPI.csNodeYaw = (csNodeYawPtr) GetProcAddress(csAPI.lib, "_csNodeYaw@4");
	csAPI.csNodeRoll = (csNodeRollPtr) GetProcAddress(csAPI.lib, "_csNodeRoll@4");
	csAPI.csNodeScaleX = (csNodeScaleXPtr) GetProcAddress(csAPI.lib, "_csNodeScaleX@4");
	csAPI.csNodeScaleY = (csNodeScaleYPtr) GetProcAddress(csAPI.lib, "_csNodeScaleY@4");
	csAPI.csNodeScaleZ = (csNodeScaleZPtr) GetProcAddress(csAPI.lib, "_csNodeScaleZ@4");
	csAPI.csNodeWidth = (csNodeWidthPtr) GetProcAddress(csAPI.lib, "_csNodeWidth@4");
	csAPI.csNodeHeight = (csNodeHeightPtr) GetProcAddress(csAPI.lib, "_csNodeHeight@4");
	csAPI.csNodeDepth = (csNodeDepthPtr) GetProcAddress(csAPI.lib, "_csNodeDepth@4");
	csAPI.csNodeCastShadow = (csNodeCastShadowPtr) GetProcAddress(csAPI.lib, "_csNodeCastShadow@8");
	csAPI.csNodeMaterials = (csNodeMaterialsPtr) GetProcAddress(csAPI.lib, "_csNodeMaterials@4");
	csAPI.csNodeGetMaterial = (csNodeGetMaterialPtr) GetProcAddress(csAPI.lib, "_csNodeGetMaterial@8");
	csAPI.csNodeSetMaterial = (csNodeSetMaterialPtr) GetProcAddress(csAPI.lib, "_csNodeSetMaterial@12");
	csAPI.csNodeSetMaterialFast = (csNodeSetMaterialFastPtr) GetProcAddress(csAPI.lib, "_csNodeSetMaterialFast@24");
	csAPI.csNodeCollision = (csNodeCollisionPtr) GetProcAddress(csAPI.lib, "_csNodeCollision@20");
	csAPI.csNodeSetProperty = (csNodeSetPropertyPtr) GetProcAddress(csAPI.lib, "_csNodeSetProperty@12");
	csAPI.csNodeProperties = (csNodePropertiesPtr) GetProcAddress(csAPI.lib, "_csNodeProperties@4");
	csAPI.csNodeFindProperty = (csNodeFindPropertyPtr) GetProcAddress(csAPI.lib, "_csNodeFindProperty@8");
	csAPI.csNodePropertyName = (csNodePropertyNamePtr) GetProcAddress(csAPI.lib, "_csNodePropertyName@8");
	csAPI.csNodePropertyValue = (csNodePropertyValuePtr) GetProcAddress(csAPI.lib, "_csNodePropertyValue@8");
	csAPI.csNodeRemoveProperty = (csNodeRemovePropertyPtr) GetProcAddress(csAPI.lib, "_csNodeRemoveProperty@8");
	csAPI.csNodeSetParent = (csNodeSetParentPtr) GetProcAddress(csAPI.lib, "_csNodeSetParent@8");
	csAPI.csNodeGetParent = (csNodeGetParentPtr) GetProcAddress(csAPI.lib, "_csNodeGetParent@4");
	csAPI.csNodeChildren = (csNodeChildrenPtr) GetProcAddress(csAPI.lib, "_csNodeChildren@4");
	csAPI.csNodeChild = (csNodeChildPtr) GetProcAddress(csAPI.lib, "_csNodeChild@8");
	csAPI.csNodeFindChild = (csNodeFindChildPtr) GetProcAddress(csAPI.lib, "_csNodeFindChild@12");
	csAPI.csNodeSpeed = (csNodeSpeedPtr) GetProcAddress(csAPI.lib, "_csNodeSpeed@8");
	csAPI.csNodeLoop = (csNodeLoopPtr) GetProcAddress(csAPI.lib, "_csNodeLoop@8");
	csAPI.csNodeSetFrame = (csNodeSetFramePtr) GetProcAddress(csAPI.lib, "_csNodeSetFrame@12");
	csAPI.csNodeGetFrame = (csNodeGetFramePtr) GetProcAddress(csAPI.lib, "_csNodeGetFrame@4");
	csAPI.csParticleDataCreate = (csParticleDataCreatePtr) GetProcAddress(csAPI.lib, "_csParticleDataCreate@4");
	csAPI.csParticleDataLoad = (csParticleDataLoadPtr) GetProcAddress(csAPI.lib, "_csParticleDataLoad@4");
	csAPI.csParticleDataSave = (csParticleDataSavePtr) GetProcAddress(csAPI.lib, "_csParticleDataSave@8");
	csAPI.csParticleDataFree = (csParticleDataFreePtr) GetProcAddress(csAPI.lib, "_csParticleDataFree@4");
	csAPI.csParticleDataFind = (csParticleDataFindPtr) GetProcAddress(csAPI.lib, "_csParticleDataFind@4");
	csAPI.csParticleDataSetMaterial = (csParticleDataSetMaterialPtr) GetProcAddress(csAPI.lib, "_csParticleDataSetMaterial@8");
	csAPI.csParticleDataSetType = (csParticleDataSetTypePtr) GetProcAddress(csAPI.lib, "_csParticleDataSetType@8");
	csAPI.csParticleDataSetBox = (csParticleDataSetBoxPtr) GetProcAddress(csAPI.lib, "_csParticleDataSetBox@16");
	csAPI.csParticleDataSetDirection = (csParticleDataSetDirectionPtr) GetProcAddress(csAPI.lib, "_csParticleDataSetDirection@16");
	csAPI.csParticleDataSetRate = (csParticleDataSetRatePtr) GetProcAddress(csAPI.lib, "_csParticleDataSetRate@12");
	csAPI.csParticleDataSetColor = (csParticleDataSetColorPtr) GetProcAddress(csAPI.lib, "_csParticleDataSetColor@12");
	csAPI.csParticleDataSetLifeTime = (csParticleDataSetLifeTimePtr) GetProcAddress(csAPI.lib, "_csParticleDataSetLifeTime@12");
	csAPI.csParticleDataSetMaxAngle = (csParticleDataSetMaxAnglePtr) GetProcAddress(csAPI.lib, "_csParticleDataSetMaxAngle@8");
	csAPI.csParticleDataSetSize = (csParticleDataSetSizePtr) GetProcAddress(csAPI.lib, "_csParticleDataSetSize@12");
	csAPI.csParticleDataAddFadeOutAffector = (csParticleDataAddFadeOutAffectorPtr) GetProcAddress(csAPI.lib, "_csParticleDataAddFadeOutAffector@12");
	csAPI.csParticleDataAddGravityAffector = (csParticleDataAddGravityAffectorPtr) GetProcAddress(csAPI.lib, "_csParticleDataAddGravityAffector@20");
	csAPI.csParticleDataGetName = (csParticleDataGetNamePtr) GetProcAddress(csAPI.lib, "_csParticleDataGetName@4");
	csAPI.csParticleDataGetMaterial = (csParticleDataGetMaterialPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetMaterial@4");
	csAPI.csParticleDataGetType = (csParticleDataGetTypePtr) GetProcAddress(csAPI.lib, "_csParticleDataGetType@4");
	csAPI.csParticleDataGetBoxWidth = (csParticleDataGetBoxWidthPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetBoxWidth@4");
	csAPI.csParticleDataGetBoxHeight = (csParticleDataGetBoxHeightPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetBoxHeight@4");
	csAPI.csParticleDataGetBoxDepth = (csParticleDataGetBoxDepthPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetBoxDepth@4");
	csAPI.csParticleDataGetDirectionX = (csParticleDataGetDirectionXPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetDirectionX@4");
	csAPI.csParticleDataGetDirectionY = (csParticleDataGetDirectionYPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetDirectionY@4");
	csAPI.csParticleDataGetDirectionZ = (csParticleDataGetDirectionZPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetDirectionZ@4");
	csAPI.csParticleDataGetMinRate = (csParticleDataGetMinRatePtr) GetProcAddress(csAPI.lib, "_csParticleDataGetMinRate@4");
	csAPI.csParticleDataGetMaxRate = (csParticleDataGetMaxRatePtr) GetProcAddress(csAPI.lib, "_csParticleDataGetMaxRate@4");
	csAPI.csParticleDataGetMinColor = (csParticleDataGetMinColorPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetMinColor@4");
	csAPI.csParticleDataGetMaxColor = (csParticleDataGetMaxColorPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetMaxColor@4");
	csAPI.csParticleDataGetMinLifeTime = (csParticleDataGetMinLifeTimePtr) GetProcAddress(csAPI.lib, "_csParticleDataGetMinLifeTime@4");
	csAPI.csParticleDataGetMaxLifeTime = (csParticleDataGetMaxLifeTimePtr) GetProcAddress(csAPI.lib, "_csParticleDataGetMaxLifeTime@4");
	csAPI.csParticleDataGetMaxAngle = (csParticleDataGetMaxAnglePtr) GetProcAddress(csAPI.lib, "_csParticleDataGetMaxAngle@4");
	csAPI.csParticleDataGetWidth = (csParticleDataGetWidthPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetWidth@4");
	csAPI.csParticleDataGetHeight = (csParticleDataGetHeightPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetHeight@4");
	csAPI.csParticleDataAffectors = (csParticleDataAffectorsPtr) GetProcAddress(csAPI.lib, "_csParticleDataAffectors@4");
	csAPI.csParticleDataGetAffectorType = (csParticleDataGetAffectorTypePtr) GetProcAddress(csAPI.lib, "_csParticleDataGetAffectorType@8");
	csAPI.csParticleDataGetAffectorColor = (csParticleDataGetAffectorColorPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetAffectorColor@8");
	csAPI.csParticleDataGetAffectorTime = (csParticleDataGetAffectorTimePtr) GetProcAddress(csAPI.lib, "_csParticleDataGetAffectorTime@8");
	csAPI.csParticleDataGetAffectorGravityX = (csParticleDataGetAffectorGravityXPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetAffectorGravityX@8");
	csAPI.csParticleDataGetAffectorGravityY = (csParticleDataGetAffectorGravityYPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetAffectorGravityY@8");
	csAPI.csParticleDataGetAffectorGravityZ = (csParticleDataGetAffectorGravityZPtr) GetProcAddress(csAPI.lib, "_csParticleDataGetAffectorGravityZ@8");
	csAPI.csSceneTexturePath = (csSceneTexturePathPtr) GetProcAddress(csAPI.lib, "_csSceneTexturePath@4");
	csAPI.csSceneBegin = (csSceneBeginPtr) GetProcAddress(csAPI.lib, "_csSceneBegin@8");
	csAPI.csSceneEnd = (csSceneEndPtr) GetProcAddress(csAPI.lib, "_csSceneEnd@0");
	csAPI.csSceneRender = (csSceneRenderPtr) GetProcAddress(csAPI.lib, "_csSceneRender@4");
	csAPI.csSceneAmbient = (csSceneAmbientPtr) GetProcAddress(csAPI.lib, "_csSceneAmbient@4");
	csAPI.csSceneFog = (csSceneFogPtr) GetProcAddress(csAPI.lib, "_csSceneFog@12");
	csAPI.csSceneSkybox = (csSceneSkyboxPtr) GetProcAddress(csAPI.lib, "_csSceneSkybox@24");
	csAPI.csSceneTransformation = (csSceneTransformationPtr) GetProcAddress(csAPI.lib, "_csSceneTransformation@8");
	csAPI.csShaderRegister = (csShaderRegisterPtr) GetProcAddress(csAPI.lib, "_csShaderRegister@28");
	csAPI.csShaderRegisterFile = (csShaderRegisterFilePtr) GetProcAddress(csAPI.lib, "_csShaderRegisterFile@28");
	csAPI.csShaderAsmRegister = (csShaderAsmRegisterPtr) GetProcAddress(csAPI.lib, "_csShaderAsmRegister@12");
	csAPI.csShaderAsmRegisterFile = (csShaderAsmRegisterFilePtr) GetProcAddress(csAPI.lib, "_csShaderAsmRegisterFile@12");
	csAPI.csShaderPixelConstant = (csShaderPixelConstantPtr) GetProcAddress(csAPI.lib, "_csShaderPixelConstant@20");
	csAPI.csShaderVertexConstant = (csShaderVertexConstantPtr) GetProcAddress(csAPI.lib, "_csShaderVertexConstant@20");
	csAPI.csStringToInt = (csStringToIntPtr) GetProcAddress(csAPI.lib, "_csStringToInt@4");
	csAPI.csStringToFloat = (csStringToFloatPtr) GetProcAddress(csAPI.lib, "_csStringToFloat@4");
	csAPI.csStringFromInt = (csStringFromIntPtr) GetProcAddress(csAPI.lib, "_csStringFromInt@4");
	csAPI.csStringFromFloat = (csStringFromFloatPtr) GetProcAddress(csAPI.lib, "_csStringFromFloat@4");
	csAPI.csStringLeft = (csStringLeftPtr) GetProcAddress(csAPI.lib, "_csStringLeft@8");
	csAPI.csStringRight = (csStringRightPtr) GetProcAddress(csAPI.lib, "_csStringRight@8");
	csAPI.csStringMid = (csStringMidPtr) GetProcAddress(csAPI.lib, "_csStringMid@12");
	csAPI.csStringReplace = (csStringReplacePtr) GetProcAddress(csAPI.lib, "_csStringReplace@12");
	csAPI.csStringFind = (csStringFindPtr) GetProcAddress(csAPI.lib, "_csStringFind@12");
	csAPI.csStringUpper = (csStringUpperPtr) GetProcAddress(csAPI.lib, "_csStringUpper@4");
	csAPI.csStringLower = (csStringLowerPtr) GetProcAddress(csAPI.lib, "_csStringLower@4");
	csAPI.csStringTrim = (csStringTrimPtr) GetProcAddress(csAPI.lib, "_csStringTrim@4");
	csAPI.csStringChar = (csStringCharPtr) GetProcAddress(csAPI.lib, "_csStringChar@4");
	csAPI.csStringAscii = (csStringAsciiPtr) GetProcAddress(csAPI.lib, "_csStringAscii@4");
	csAPI.csStringLen = (csStringLenPtr) GetProcAddress(csAPI.lib, "_csStringLen@4");
	csAPI.csStringField = (csStringFieldPtr) GetProcAddress(csAPI.lib, "_csStringField@12");
	csAPI.csTerrainNode = (csTerrainNodePtr) GetProcAddress(csAPI.lib, "_csTerrainNode@24");
	csAPI.csTerrainScaleTexture = (csTerrainScaleTexturePtr) GetProcAddress(csAPI.lib, "_csTerrainScaleTexture@12");
	csAPI.csTextureLoad = (csTextureLoadPtr) GetProcAddress(csAPI.lib, "_csTextureLoad@8");
	csAPI.csTextureFree = (csTextureFreePtr) GetProcAddress(csAPI.lib, "_csTextureFree@4");
	csAPI.csTextureFile = (csTextureFilePtr) GetProcAddress(csAPI.lib, "_csTextureFile@4");
	csAPI.csTextureWidth = (csTextureWidthPtr) GetProcAddress(csAPI.lib, "_csTextureWidth@8");
	csAPI.csTextureHeight = (csTextureHeightPtr) GetProcAddress(csAPI.lib, "_csTextureHeight@8");
	csAPI.csTextureLock = (csTextureLockPtr) GetProcAddress(csAPI.lib, "_csTextureLock@4");
	csAPI.csTextureUnlock = (csTextureUnlockPtr) GetProcAddress(csAPI.lib, "_csTextureUnlock@4");
	csAPI.csTextureColorKey = (csTextureColorKeyPtr) GetProcAddress(csAPI.lib, "_csTextureColorKey@8");
	csAPI.csTextureNormalize = (csTextureNormalizePtr) GetProcAddress(csAPI.lib, "_csTextureNormalize@8");
	csAPI.csVectorCreate = (csVectorCreatePtr) GetProcAddress(csAPI.lib, "_csVectorCreate@0");
	csAPI.csVectorFree = (csVectorFreePtr) GetProcAddress(csAPI.lib, "_csVectorFree@4");
	csAPI.csVectorAdd = (csVectorAddPtr) GetProcAddress(csAPI.lib, "_csVectorAdd@8");
	csAPI.csVectorAddScale = (csVectorAddScalePtr) GetProcAddress(csAPI.lib, "_csVectorAddScale@12");
	csAPI.csVectorBetween = (csVectorBetweenPtr) GetProcAddress(csAPI.lib, "_csVectorBetween@28");
	csAPI.csVectorCopy = (csVectorCopyPtr) GetProcAddress(csAPI.lib, "_csVectorCopy@8");
	csAPI.csVectorCrossProduct = (csVectorCrossProductPtr) GetProcAddress(csAPI.lib, "_csVectorCrossProduct@8");
	csAPI.csVectorDotProduct = (csVectorDotProductPtr) GetProcAddress(csAPI.lib, "_csVectorDotProduct@8");
	csAPI.csVectorEqual = (csVectorEqualPtr) GetProcAddress(csAPI.lib, "_csVectorEqual@12");
	csAPI.csVectorDistance = (csVectorDistancePtr) GetProcAddress(csAPI.lib, "_csVectorDistance@16");
	csAPI.csVectorDistanceSquared = (csVectorDistanceSquaredPtr) GetProcAddress(csAPI.lib, "_csVectorDistanceSquared@16");
	csAPI.csVectorDiv = (csVectorDivPtr) GetProcAddress(csAPI.lib, "_csVectorDiv@8");
	csAPI.csVectorInterpolate = (csVectorInterpolatePtr) GetProcAddress(csAPI.lib, "_csVectorInterpolate@12");
	csAPI.csVectorInvert = (csVectorInvertPtr) GetProcAddress(csAPI.lib, "_csVectorInvert@4");
	csAPI.csVectorLength = (csVectorLengthPtr) GetProcAddress(csAPI.lib, "_csVectorLength@4");
	csAPI.csVectorLengthSquared = (csVectorLengthSquaredPtr) GetProcAddress(csAPI.lib, "_csVectorLengthSquared@4");
	csAPI.csVectorMul = (csVectorMulPtr) GetProcAddress(csAPI.lib, "_csVectorMul@8");
	csAPI.csVectorNormalize = (csVectorNormalizePtr) GetProcAddress(csAPI.lib, "_csVectorNormalize@4");
	csAPI.csVectorScale = (csVectorScalePtr) GetProcAddress(csAPI.lib, "_csVectorScale@8");
	csAPI.csVectorSet = (csVectorSetPtr) GetProcAddress(csAPI.lib, "_csVectorSet@16");
	csAPI.csVectorSub = (csVectorSubPtr) GetProcAddress(csAPI.lib, "_csVectorSub@8");
	csAPI.csVectorX = (csVectorXPtr) GetProcAddress(csAPI.lib, "_csVectorX@4");
	csAPI.csVectorY = (csVectorYPtr) GetProcAddress(csAPI.lib, "_csVectorY@4");
	csAPI.csVectorZ = (csVectorZPtr) GetProcAddress(csAPI.lib, "_csVectorZ@4");
	csAPI.csLibInit();
}

void csLibFinish()
{
	csAPI.csLibFinish();
	FreeLibrary(csAPI.lib);
}

int csBillboardNode(int parent_)
{
	return csAPI.csBillboardNode(parent_);
}

void csBillboardResize(int billboard_, float width_, float height_)
{
	csAPI.csBillboardResize(billboard_, width_, height_);
}

float csBillboardWidth(int billboard_)
{
	return csAPI.csBillboardWidth(billboard_);
}

float csBillboardHeight(int billboard_)
{
	return csAPI.csBillboardHeight(billboard_);
}

int csCameraNode(int parent_)
{
	return csAPI.csCameraNode(parent_);
}

void csCameraViewport(int cam_, float x1_, float y1_, float x2_, float y2_)
{
	csAPI.csCameraViewport(cam_, x1_, y1_, x2_, y2_);
}

void csCameraRange(int cam_, float near_, float far_)
{
	csAPI.csCameraRange(cam_, near_, far_);
}

void csCameraFov(int cam_, float fov_)
{
	csAPI.csCameraFov(cam_, fov_);
}

void csCameraAspectRatio(int cam_, float ratio_)
{
	csAPI.csCameraAspectRatio(cam_, ratio_);
}

void csCameraProjection(int cam_, float width_, float height_, float near_, float far_, int ortho_)
{
	csAPI.csCameraProjection(cam_, width_, height_, near_, far_, ortho_);
}

int csCollisionGetPoint(int node_, float pos_x_, float pos_y_, float pos_z_, float dest_x_, float dest_y_, float dest_z_)
{
	return csAPI.csCollisionGetPoint(node_, pos_x_, pos_y_, pos_z_, dest_x_, dest_y_, dest_z_);
}

void csCollisionGetSlide(int node_, float prev_x_, float prev_y_, float prev_z_, float pos_x_, float pos_y_, float pos_z_, float rad_x_, float rad_y_, float rad_z_)
{
	csAPI.csCollisionGetSlide(node_, prev_x_, prev_y_, prev_z_, pos_x_, pos_y_, pos_z_, rad_x_, rad_y_, rad_z_);
}

void csCollisionReturnData(int vector_num_)
{
	csAPI.csCollisionReturnData(vector_num_);
}

float csCollisionDataX()
{
	return csAPI.csCollisionDataX();
}

float csCollisionDataY()
{
	return csAPI.csCollisionDataY();
}

float csCollisionDataZ()
{
	return csAPI.csCollisionDataZ();
}

void csDisplayOpen(int width_, int height_, int depth_, int flags_, int win_)
{
	csAPI.csDisplayOpen(width_, height_, depth_, flags_, win_);
}

void csDisplayClose()
{
	csAPI.csDisplayClose();
}

void csDisplayCaption(const char* caption_)
{
	csAPI.csDisplayCaption(caption_);
}

int csDisplayClosed()
{
	return csAPI.csDisplayClosed();
}

int csDisplayWidth()
{
	return csAPI.csDisplayWidth();
}

int csDisplayHeight()
{
	return csAPI.csDisplayHeight();
}

int csDisplayFps()
{
	return csAPI.csDisplayFps();
}

int csDisplayFeature(int feature_)
{
	return csAPI.csDisplayFeature(feature_);
}

void csDisplayResize(int width_, int height_)
{
	csAPI.csDisplayResize(width_, height_);
}

int csGetColor(int alpha_, int red_, int green_, int blue_)
{
	return csAPI.csGetColor(alpha_, red_, green_, blue_);
}

int csGetAlpha(int color_)
{
	return csAPI.csGetAlpha(color_);
}

int csGetRed(int color_)
{
	return csAPI.csGetRed(color_);
}

int csGetGreen(int color_)
{
	return csAPI.csGetGreen(color_);
}

int csGetBlue(int color_)
{
	return csAPI.csGetBlue(color_);
}

void csSetColor(int color_)
{
	csAPI.csSetColor(color_);
}

void csViewport(int x_, int y_, int w_, int h_)
{
	csAPI.csViewport(x_, y_, w_, h_);
}

void csDrawLine(int x_, int y_, int x1_, int y1_)
{
	csAPI.csDrawLine(x_, y_, x1_, y1_);
}

void csDrawRect(int x_, int y_, int w_, int h_)
{
	csAPI.csDrawRect(x_, y_, w_, h_);
}

void csDrawTexture(int tex_, int x_, int y_)
{
	csAPI.csDrawTexture(tex_, x_, y_);
}

void csDrawText(int font_, const char* text_, int x_, int y_)
{
	csAPI.csDrawText(font_, text_, x_, y_);
}

int csTextWidth(int font_, const char* text_)
{
	return csAPI.csTextWidth(font_, text_);
}

int csTextHeight(int font_, const char* text_)
{
	return csAPI.csTextHeight(font_, text_);
}

int csEmitterNode(int particle_data_, int parent_)
{
	return csAPI.csEmitterNode(particle_data_, parent_);
}

void csEmitterAddFadeOutAffector(int emitter_, int color_, int time_)
{
	csAPI.csEmitterAddFadeOutAffector(emitter_, color_, time_);
}

void csEmitterAddGravityAffector(int emitter_, float grav_x_, float grav_y_, float grav_z_, int time_)
{
	csAPI.csEmitterAddGravityAffector(emitter_, grav_x_, grav_y_, grav_z_, time_);
}

void csEmitterRemoveAffectors(int emitter_)
{
	csAPI.csEmitterRemoveAffectors(emitter_);
}

void csAddZip(const char* zip_)
{
	csAPI.csAddZip(zip_);
}

int csFileRead(const char* file_)
{
	return csAPI.csFileRead(file_);
}

int csFileWrite(const char* file_)
{
	return csAPI.csFileWrite(file_);
}

void csFileClose(int file_)
{
	csAPI.csFileClose(file_);
}

int csFileSize(int file_)
{
	return csAPI.csFileSize(file_);
}

int csFilePos(int file_)
{
	return csAPI.csFilePos(file_);
}

void csFileSeek(int file_, int pos_, int relative_)
{
	csAPI.csFileSeek(file_, pos_, relative_);
}

int csFileReadByte(int file_)
{
	return csAPI.csFileReadByte(file_);
}

int csFileReadShort(int file_)
{
	return csAPI.csFileReadShort(file_);
}

int csFileReadInt(int file_)
{
	return csAPI.csFileReadInt(file_);
}

float csFileReadFloat(int file_)
{
	return csAPI.csFileReadFloat(file_);
}

const char* csFileReadString(int file_)
{
	return csAPI.csFileReadString(file_);
}

void csFileReadBytes(int file_, int buf_, int size_)
{
	csAPI.csFileReadBytes(file_, buf_, size_);
}

void csFileWriteByte(int file_, int value_)
{
	csAPI.csFileWriteByte(file_, value_);
}

void csFileWriteShort(int file_, int value_)
{
	csAPI.csFileWriteShort(file_, value_);
}

void csFileWriteInt(int file_, int value_)
{
	csAPI.csFileWriteInt(file_, value_);
}

void csFileWriteFloat(int file_, float value_)
{
	csAPI.csFileWriteFloat(file_, value_);
}

void csFileWriteString(int file_, const char* str_)
{
	csAPI.csFileWriteString(file_, str_);
}

void csFileWriteBytes(int file_, int buf_, int size_)
{
	csAPI.csFileWriteBytes(file_, buf_, size_);
}

int csXMLRead(const char* file_)
{
	return csAPI.csXMLRead(file_);
}

int csXMLWrite(const char* file_)
{
	return csAPI.csXMLWrite(file_);
}

void csXMLClose(int xml_)
{
	csAPI.csXMLClose(xml_);
}

int csXMLReadNode(int xml_)
{
	return csAPI.csXMLReadNode(xml_);
}

int csXMLNodeType(int xml_)
{
	return csAPI.csXMLNodeType(xml_);
}

const char* csXMLNodeName(int xml_)
{
	return csAPI.csXMLNodeName(xml_);
}

const char* csXMLNodeData(int xml_)
{
	return csAPI.csXMLNodeData(xml_);
}

int csXMLAttributeCount(int xml_)
{
	return csAPI.csXMLAttributeCount(xml_);
}

const char* csXMLAttributeName(int xml_, int index_)
{
	return csAPI.csXMLAttributeName(xml_, index_);
}

const char* csXMLAttributeValue(int xml_, int index_)
{
	return csAPI.csXMLAttributeValue(xml_, index_);
}

void csXMLWriteHeader(int xml_)
{
	csAPI.csXMLWriteHeader(xml_);
}

void csXMLWriteElement(int xml_, const char* name_, const char* attributes_, int empty_)
{
	csAPI.csXMLWriteElement(xml_, name_, attributes_, empty_);
}

void csXMLWriteClosingTag(int xml_, const char* name_)
{
	csAPI.csXMLWriteClosingTag(xml_, name_);
}

void csXMLWriteText(int xml_, const char* text_)
{
	csAPI.csXMLWriteText(xml_, text_);
}

void csXMLWriteLineBreak(int xml_)
{
	csAPI.csXMLWriteLineBreak(xml_);
}

int csFontLoad(const char* file_)
{
	return csAPI.csFontLoad(file_);
}

void csFontFree(int font_)
{
	csAPI.csFontFree(font_);
}

void csMousePosition(int x_, int y_)
{
	csAPI.csMousePosition(x_, y_);
}

void csMouseHide(int hide_)
{
	csAPI.csMouseHide(hide_);
}

int csMouseX()
{
	return csAPI.csMouseX();
}

int csMouseY()
{
	return csAPI.csMouseY();
}

int csMouseHit(int button_)
{
	return csAPI.csMouseHit(button_);
}

int csMouseDown(int button_)
{
	return csAPI.csMouseDown(button_);
}

int csMouseGet()
{
	return csAPI.csMouseGet();
}

int csMouseReleased()
{
	return csAPI.csMouseReleased();
}

int csKeyHit(int key_)
{
	return csAPI.csKeyHit(key_);
}

int csKeyDown(int key_)
{
	return csAPI.csKeyDown(key_);
}

int csKeyGet()
{
	return csAPI.csKeyGet();
}

int csKeyReleased()
{
	return csAPI.csKeyReleased();
}

int csLightNode(int parent_)
{
	return csAPI.csLightNode(parent_);
}

void csLightRadius(int light_, float radius_)
{
	csAPI.csLightRadius(light_, radius_);
}

void csLightAmbient(int light_, int color_)
{
	csAPI.csLightAmbient(light_, color_);
}

void csLightDiffuse(int light_, int color_)
{
	csAPI.csLightDiffuse(light_, color_);
}

void csLightSpecular(int light_, int color_)
{
	csAPI.csLightSpecular(light_, color_);
}

int csMaterialCreate(const char* name_)
{
	return csAPI.csMaterialCreate(name_);
}

int csMaterialLoad(const char* file_)
{
	return csAPI.csMaterialLoad(file_);
}

void csMaterialSave(int mat_, const char* file_, const char* rel_path_)
{
	csAPI.csMaterialSave(mat_, file_, rel_path_);
}

void csMaterialFree(int mat_)
{
	csAPI.csMaterialFree(mat_);
}

int csMaterialFind(const char* name_)
{
	return csAPI.csMaterialFind(name_);
}

void csMaterialSetType(int mat_, int newtype_)
{
	csAPI.csMaterialSetType(mat_, newtype_);
}

void csMaterialSetFlags(int mat_, int flags_)
{
	csAPI.csMaterialSetFlags(mat_, flags_);
}

void csMaterialSetTexture(int mat_, int tex_, int layer_)
{
	csAPI.csMaterialSetTexture(mat_, tex_, layer_);
}

void csMaterialSetAmbient(int mat_, int color_)
{
	csAPI.csMaterialSetAmbient(mat_, color_);
}

void csMaterialSetDiffuse(int mat_, int color_)
{
	csAPI.csMaterialSetDiffuse(mat_, color_);
}

void csMaterialSetEmissive(int mat_, int color_)
{
	csAPI.csMaterialSetEmissive(mat_, color_);
}

void csMaterialSetSpecular(int mat_, int color_)
{
	csAPI.csMaterialSetSpecular(mat_, color_);
}

void csMaterialSetShininess(int mat_, float shininess_)
{
	csAPI.csMaterialSetShininess(mat_, shininess_);
}

void csMaterialSetParam(int mat_, float param_)
{
	csAPI.csMaterialSetParam(mat_, param_);
}

const char* csMaterialGetName(int mat_)
{
	return csAPI.csMaterialGetName(mat_);
}

int csMaterialGetType(int mat_)
{
	return csAPI.csMaterialGetType(mat_);
}

int csMaterialGetFlags(int mat_)
{
	return csAPI.csMaterialGetFlags(mat_);
}

int csMaterialGetTexture(int mat_, int layer_)
{
	return csAPI.csMaterialGetTexture(mat_, layer_);
}

int csMaterialGetAmbient(int mat_)
{
	return csAPI.csMaterialGetAmbient(mat_);
}

int csMaterialGetDiffuse(int mat_)
{
	return csAPI.csMaterialGetDiffuse(mat_);
}

int csMaterialGetEmissive(int mat_)
{
	return csAPI.csMaterialGetEmissive(mat_);
}

int csMaterialGetSpecular(int mat_)
{
	return csAPI.csMaterialGetSpecular(mat_);
}

float csMaterialGetShininess(int mat_)
{
	return csAPI.csMaterialGetShininess(mat_);
}

float csMaterialGetParam(int mat_)
{
	return csAPI.csMaterialGetParam(mat_);
}

int csMatrixCreate()
{
	return csAPI.csMatrixCreate();
}

void csMatrixFree(int matrix_)
{
	csAPI.csMatrixFree(matrix_);
}

void csMatrixMul(int matrix_, int matrix2_)
{
	csAPI.csMatrixMul(matrix_, matrix2_);
}

int csMeshLoad(const char* file_)
{
	return csAPI.csMeshLoad(file_);
}

int csMeshTerrainLoad(const char* heightmap_)
{
	return csAPI.csMeshTerrainLoad(heightmap_);
}

void csMeshFree(int mesh_)
{
	csAPI.csMeshFree(mesh_);
}

int csMeshNode(int mesh_, int parent_, int col_info_, int tangent_mesh_)
{
	return csAPI.csMeshNode(mesh_, parent_, col_info_, tangent_mesh_);
}

int csMeshOctreeNode(int mesh_, int parent_, int col_info_, int tangent_mesh_)
{
	return csAPI.csMeshOctreeNode(mesh_, parent_, col_info_, tangent_mesh_);
}

void csMeshScale(int mesh_, float sx_, float sy_, float sz_)
{
	csAPI.csMeshScale(mesh_, sx_, sy_, sz_);
}

void csMeshFlip(int mesh_)
{
	csAPI.csMeshFlip(mesh_);
}

void csMeshUpdateNormals(int mesh_)
{
	csAPI.csMeshUpdateNormals(mesh_);
}

void csMeshVerticesColor(int mesh_, int color_, int change_alpha_)
{
	csAPI.csMeshVerticesColor(mesh_, color_, change_alpha_);
}

void csMeshPlanarMapping(int mesh_, float resolution_)
{
	csAPI.csMeshPlanarMapping(mesh_, resolution_);
}

float csMeshWidth(int mesh_)
{
	return csAPI.csMeshWidth(mesh_);
}

float csMeshHeight(int mesh_)
{
	return csAPI.csMeshHeight(mesh_);
}

float csMeshDepth(int mesh_)
{
	return csAPI.csMeshDepth(mesh_);
}

int csNodeEmpty(int parent_)
{
	return csAPI.csNodeEmpty(parent_);
}

void csNodeFree(int node_)
{
	csAPI.csNodeFree(node_);
}

int csNodeType(int node_)
{
	return csAPI.csNodeType(node_);
}

void csNodeSetName(int node_, const char* name_)
{
	csAPI.csNodeSetName(node_, name_);
}

const char* csNodeGetName(int node_)
{
	return csAPI.csNodeGetName(node_);
}

void csNodePosition(int node_, float x_, float y_, float z_)
{
	csAPI.csNodePosition(node_, x_, y_, z_);
}

void csNodeMove(int node_, float x_, float y_, float z_)
{
	csAPI.csNodeMove(node_, x_, y_, z_);
}

void csNodeRotate(int node_, float pitch_, float yaw_, float roll_)
{
	csAPI.csNodeRotate(node_, pitch_, yaw_, roll_);
}

void csNodeTurn(int node_, float pitch_, float yaw_, float roll_)
{
	csAPI.csNodeTurn(node_, pitch_, yaw_, roll_);
}

void csNodeScale(int node_, float x_, float y_, float z_)
{
	csAPI.csNodeScale(node_, x_, y_, z_);
}

float csNodeX(int node_, int absolute_)
{
	return csAPI.csNodeX(node_, absolute_);
}

float csNodeY(int node_, int absolute_)
{
	return csAPI.csNodeY(node_, absolute_);
}

float csNodeZ(int node_, int absolute_)
{
	return csAPI.csNodeZ(node_, absolute_);
}

float csNodePitch(int node_)
{
	return csAPI.csNodePitch(node_);
}

float csNodeYaw(int node_)
{
	return csAPI.csNodeYaw(node_);
}

float csNodeRoll(int node_)
{
	return csAPI.csNodeRoll(node_);
}

float csNodeScaleX(int node_)
{
	return csAPI.csNodeScaleX(node_);
}

float csNodeScaleY(int node_)
{
	return csAPI.csNodeScaleY(node_);
}

float csNodeScaleZ(int node_)
{
	return csAPI.csNodeScaleZ(node_);
}

float csNodeWidth(int node_)
{
	return csAPI.csNodeWidth(node_);
}

float csNodeHeight(int node_)
{
	return csAPI.csNodeHeight(node_);
}

float csNodeDepth(int node_)
{
	return csAPI.csNodeDepth(node_);
}

void csNodeCastShadow(int node_, int cast_)
{
	csAPI.csNodeCastShadow(node_, cast_);
}

int csNodeMaterials(int node_)
{
	return csAPI.csNodeMaterials(node_);
}

int csNodeGetMaterial(int node_, int mat_index_)
{
	return csAPI.csNodeGetMaterial(node_, mat_index_);
}

void csNodeSetMaterial(int node_, int mat_, int mat_index_)
{
	csAPI.csNodeSetMaterial(node_, mat_, mat_index_);
}

void csNodeSetMaterialFast(int node_, int index_, int type_, int flags_, int tex1_, int tex2_)
{
	csAPI.csNodeSetMaterialFast(node_, index_, type_, flags_, tex1_, tex2_);
}

void csNodeCollision(int node1_, int node2_, float radx_, float rady_, float radz_)
{
	csAPI.csNodeCollision(node1_, node2_, radx_, rady_, radz_);
}

void csNodeSetProperty(int node_, const char* name_, const char* value_)
{
	csAPI.csNodeSetProperty(node_, name_, value_);
}

int csNodeProperties(int node_)
{
	return csAPI.csNodeProperties(node_);
}

int csNodeFindProperty(int node_, const char* name_)
{
	return csAPI.csNodeFindProperty(node_, name_);
}

const char* csNodePropertyName(int node_, int index_)
{
	return csAPI.csNodePropertyName(node_, index_);
}

const char* csNodePropertyValue(int node_, int index_)
{
	return csAPI.csNodePropertyValue(node_, index_);
}

void csNodeRemoveProperty(int node_, int index_)
{
	csAPI.csNodeRemoveProperty(node_, index_);
}

void csNodeSetParent(int node_, int parent_)
{
	csAPI.csNodeSetParent(node_, parent_);
}

int csNodeGetParent(int node_)
{
	return csAPI.csNodeGetParent(node_);
}

int csNodeChildren(int node_)
{
	return csAPI.csNodeChildren(node_);
}

int csNodeChild(int node_, int index_)
{
	return csAPI.csNodeChild(node_, index_);
}

int csNodeFindChild(int node_, const char* name_, int recursive_)
{
	return csAPI.csNodeFindChild(node_, name_, recursive_);
}

void csNodeSpeed(int node_, int fps_)
{
	csAPI.csNodeSpeed(node_, fps_);
}

void csNodeLoop(int node_, int loop_)
{
	csAPI.csNodeLoop(node_, loop_);
}

void csNodeSetFrame(int node_, int start_, int finish_)
{
	csAPI.csNodeSetFrame(node_, start_, finish_);
}

int csNodeGetFrame(int node_)
{
	return csAPI.csNodeGetFrame(node_);
}

int csParticleDataCreate(const char* name_)
{
	return csAPI.csParticleDataCreate(name_);
}

int csParticleDataLoad(const char* file_)
{
	return csAPI.csParticleDataLoad(file_);
}

void csParticleDataSave(int part_data_, const char* file_)
{
	csAPI.csParticleDataSave(part_data_, file_);
}

void csParticleDataFree(int part_data_)
{
	csAPI.csParticleDataFree(part_data_);
}

int csParticleDataFind(const char* name_)
{
	return csAPI.csParticleDataFind(name_);
}

void csParticleDataSetMaterial(int part_data_, const char* mat_name_)
{
	csAPI.csParticleDataSetMaterial(part_data_, mat_name_);
}

void csParticleDataSetType(int part_data_, int type_)
{
	csAPI.csParticleDataSetType(part_data_, type_);
}

void csParticleDataSetBox(int part_data_, float width_, float height_, float depth_)
{
	csAPI.csParticleDataSetBox(part_data_, width_, height_, depth_);
}

void csParticleDataSetDirection(int part_data_, float x_, float y_, float z_)
{
	csAPI.csParticleDataSetDirection(part_data_, x_, y_, z_);
}

void csParticleDataSetRate(int part_data_, int min_, int max_)
{
	csAPI.csParticleDataSetRate(part_data_, min_, max_);
}

void csParticleDataSetColor(int part_data_, int min_, int max_)
{
	csAPI.csParticleDataSetColor(part_data_, min_, max_);
}

void csParticleDataSetLifeTime(int part_data_, int min_, int max_)
{
	csAPI.csParticleDataSetLifeTime(part_data_, min_, max_);
}

void csParticleDataSetMaxAngle(int part_data_, int angle_)
{
	csAPI.csParticleDataSetMaxAngle(part_data_, angle_);
}

void csParticleDataSetSize(int part_data_, float width_, float height_)
{
	csAPI.csParticleDataSetSize(part_data_, width_, height_);
}

void csParticleDataAddFadeOutAffector(int part_data_, int color_, int time_)
{
	csAPI.csParticleDataAddFadeOutAffector(part_data_, color_, time_);
}

void csParticleDataAddGravityAffector(int part_data_, float grav_x_, float grav_y_, float grav_z_, int time_)
{
	csAPI.csParticleDataAddGravityAffector(part_data_, grav_x_, grav_y_, grav_z_, time_);
}

const char* csParticleDataGetName(int part_)
{
	return csAPI.csParticleDataGetName(part_);
}

const char* csParticleDataGetMaterial(int part_)
{
	return csAPI.csParticleDataGetMaterial(part_);
}

int csParticleDataGetType(int part_)
{
	return csAPI.csParticleDataGetType(part_);
}

float csParticleDataGetBoxWidth(int part_)
{
	return csAPI.csParticleDataGetBoxWidth(part_);
}

float csParticleDataGetBoxHeight(int part_)
{
	return csAPI.csParticleDataGetBoxHeight(part_);
}

float csParticleDataGetBoxDepth(int part_)
{
	return csAPI.csParticleDataGetBoxDepth(part_);
}

float csParticleDataGetDirectionX(int part_)
{
	return csAPI.csParticleDataGetDirectionX(part_);
}

float csParticleDataGetDirectionY(int part_)
{
	return csAPI.csParticleDataGetDirectionY(part_);
}

float csParticleDataGetDirectionZ(int part_)
{
	return csAPI.csParticleDataGetDirectionZ(part_);
}

int csParticleDataGetMinRate(int part_)
{
	return csAPI.csParticleDataGetMinRate(part_);
}

int csParticleDataGetMaxRate(int part_)
{
	return csAPI.csParticleDataGetMaxRate(part_);
}

int csParticleDataGetMinColor(int part_)
{
	return csAPI.csParticleDataGetMinColor(part_);
}

int csParticleDataGetMaxColor(int part_)
{
	return csAPI.csParticleDataGetMaxColor(part_);
}

int csParticleDataGetMinLifeTime(int part_)
{
	return csAPI.csParticleDataGetMinLifeTime(part_);
}

int csParticleDataGetMaxLifeTime(int part_)
{
	return csAPI.csParticleDataGetMaxLifeTime(part_);
}

int csParticleDataGetMaxAngle(int part_)
{
	return csAPI.csParticleDataGetMaxAngle(part_);
}

float csParticleDataGetWidth(int part_)
{
	return csAPI.csParticleDataGetWidth(part_);
}

float csParticleDataGetHeight(int part_)
{
	return csAPI.csParticleDataGetHeight(part_);
}

int csParticleDataAffectors(int part_)
{
	return csAPI.csParticleDataAffectors(part_);
}

int csParticleDataGetAffectorType(int part_, int index_)
{
	return csAPI.csParticleDataGetAffectorType(part_, index_);
}

int csParticleDataGetAffectorColor(int part_, int index_)
{
	return csAPI.csParticleDataGetAffectorColor(part_, index_);
}

int csParticleDataGetAffectorTime(int part_, int index_)
{
	return csAPI.csParticleDataGetAffectorTime(part_, index_);
}

float csParticleDataGetAffectorGravityX(int part_, int index_)
{
	return csAPI.csParticleDataGetAffectorGravityX(part_, index_);
}

float csParticleDataGetAffectorGravityY(int part_, int index_)
{
	return csAPI.csParticleDataGetAffectorGravityY(part_, index_);
}

float csParticleDataGetAffectorGravityZ(int part_, int index_)
{
	return csAPI.csParticleDataGetAffectorGravityZ(part_, index_);
}

void csSceneTexturePath(const char* path_)
{
	csAPI.csSceneTexturePath(path_);
}

void csSceneBegin(int clear_flags_, int color_)
{
	csAPI.csSceneBegin(clear_flags_, color_);
}

void csSceneEnd()
{
	csAPI.csSceneEnd();
}

void csSceneRender(int camera_)
{
	csAPI.csSceneRender(camera_);
}

void csSceneAmbient(int color_)
{
	csAPI.csSceneAmbient(color_);
}

void csSceneFog(int color_, float near_, float far_)
{
	csAPI.csSceneFog(color_, near_, far_);
}

void csSceneSkybox(int top_, int bottom_, int left_, int right_, int front_, int back_)
{
	csAPI.csSceneSkybox(top_, bottom_, left_, right_, front_, back_);
}

void csSceneTransformation(int state_, int matrix_)
{
	csAPI.csSceneTransformation(state_, matrix_);
}

int csShaderRegister(const char* pixel_shader_, const char* pixel_entry_, int pixel_format_, const char* vertex_shader_, const char* vertex_entry_, int vertex_format_, int base_mat_)
{
	return csAPI.csShaderRegister(pixel_shader_, pixel_entry_, pixel_format_, vertex_shader_, vertex_entry_, vertex_format_, base_mat_);
}

int csShaderRegisterFile(const char* pixel_file_, const char* pixel_entry_, int pixel_format_, const char* vertex_file_, const char* vertex_entry_, int vertex_format_, int base_mat_)
{
	return csAPI.csShaderRegisterFile(pixel_file_, pixel_entry_, pixel_format_, vertex_file_, vertex_entry_, vertex_format_, base_mat_);
}

int csShaderAsmRegister(const char* pixel_shader_, const char* vertex_shader_, int base_material_)
{
	return csAPI.csShaderAsmRegister(pixel_shader_, vertex_shader_, base_material_);
}

int csShaderAsmRegisterFile(const char* pixel_file_, const char* vertex_file_, int base_mat_)
{
	return csAPI.csShaderAsmRegisterFile(pixel_file_, vertex_file_, base_mat_);
}

void csShaderPixelConstant(int shader_, const char* name_, int start_register_, int data_, int count_)
{
	csAPI.csShaderPixelConstant(shader_, name_, start_register_, data_, count_);
}

void csShaderVertexConstant(int shader_, const char* name_, int start_register_, int data_, int count_)
{
	csAPI.csShaderVertexConstant(shader_, name_, start_register_, data_, count_);
}

int csStringToInt(const char* str_)
{
	return csAPI.csStringToInt(str_);
}

float csStringToFloat(const char* str_)
{
	return csAPI.csStringToFloat(str_);
}

const char* csStringFromInt(int number_)
{
	return csAPI.csStringFromInt(number_);
}

const char* csStringFromFloat(float number_)
{
	return csAPI.csStringFromFloat(number_);
}

const char* csStringLeft(const char* str_, int num_)
{
	return csAPI.csStringLeft(str_, num_);
}

const char* csStringRight(const char* str_, int num_)
{
	return csAPI.csStringRight(str_, num_);
}

const char* csStringMid(const char* str_, int pos_, int num_)
{
	return csAPI.csStringMid(str_, pos_, num_);
}

const char* csStringReplace(const char* str_, const char* find_, const char* replace_)
{
	return csAPI.csStringReplace(str_, find_, replace_);
}

int csStringFind(const char* str_, const char* find_, int offset_)
{
	return csAPI.csStringFind(str_, find_, offset_);
}

const char* csStringUpper(const char* str_)
{
	return csAPI.csStringUpper(str_);
}

const char* csStringLower(const char* str_)
{
	return csAPI.csStringLower(str_);
}

const char* csStringTrim(const char* str_)
{
	return csAPI.csStringTrim(str_);
}

const char* csStringChar(int ascii_)
{
	return csAPI.csStringChar(ascii_);
}

int csStringAscii(const char* str_)
{
	return csAPI.csStringAscii(str_);
}

int csStringLen(const char* str_)
{
	return csAPI.csStringLen(str_);
}

const char* csStringField(const char* str_, const char* delimiter_, int index_)
{
	return csAPI.csStringField(str_, delimiter_, index_);
}

int csTerrainNode(const char* heightmap_, int parent_, float width_, float height_, float depth_, int col_info_)
{
	return csAPI.csTerrainNode(heightmap_, parent_, width_, height_, depth_, col_info_);
}

void csTerrainScaleTexture(int terrain_, float scale1_, float scale2_)
{
	csAPI.csTerrainScaleTexture(terrain_, scale1_, scale2_);
}

int csTextureLoad(const char* file_, int mipmaps_)
{
	return csAPI.csTextureLoad(file_, mipmaps_);
}

void csTextureFree(int tex_)
{
	csAPI.csTextureFree(tex_);
}

const char* csTextureFile(int tex_)
{
	return csAPI.csTextureFile(tex_);
}

int csTextureWidth(int tex_, int original_)
{
	return csAPI.csTextureWidth(tex_, original_);
}

int csTextureHeight(int tex_, int original_)
{
	return csAPI.csTextureHeight(tex_, original_);
}

int csTextureLock(int tex_)
{
	return csAPI.csTextureLock(tex_);
}

void csTextureUnlock(int tex_)
{
	csAPI.csTextureUnlock(tex_);
}

void csTextureColorKey(int tex_, int color_)
{
	csAPI.csTextureColorKey(tex_, color_);
}

void csTextureNormalize(int tex_, float amplitude_)
{
	csAPI.csTextureNormalize(tex_, amplitude_);
}

int csVectorCreate()
{
	return csAPI.csVectorCreate();
}

void csVectorFree(int vector_)
{
	csAPI.csVectorFree(vector_);
}

void csVectorAdd(int vector_, int vector2_)
{
	csAPI.csVectorAdd(vector_, vector2_);
}

void csVectorAddScale(int vector_, int vector2_, float scale_)
{
	csAPI.csVectorAddScale(vector_, vector2_, scale_);
}

int csVectorBetween(int vector_, float x0_, float y0_, float z0_, float x1_, float y1_, float z1_)
{
	return csAPI.csVectorBetween(vector_, x0_, y0_, z0_, x1_, y1_, z1_);
}

void csVectorCopy(int vector_, int other_vector_)
{
	csAPI.csVectorCopy(vector_, other_vector_);
}

void csVectorCrossProduct(int vector_, int vector2_)
{
	csAPI.csVectorCrossProduct(vector_, vector2_);
}

float csVectorDotProduct(int vector_, int other_vector_)
{
	return csAPI.csVectorDotProduct(vector_, other_vector_);
}

int csVectorEqual(int vector_, int other_vector_, float epsilon_)
{
	return csAPI.csVectorEqual(vector_, other_vector_, epsilon_);
}

float csVectorDistance(int vector_, float x_, float y_, float z_)
{
	return csAPI.csVectorDistance(vector_, x_, y_, z_);
}

float csVectorDistanceSquared(int vector_, float x_, float y_, float z_)
{
	return csAPI.csVectorDistanceSquared(vector_, x_, y_, z_);
}

void csVectorDiv(int vector_, int vector2_)
{
	csAPI.csVectorDiv(vector_, vector2_);
}

void csVectorInterpolate(int vector_, int vector2_, float d_)
{
	csAPI.csVectorInterpolate(vector_, vector2_, d_);
}

void csVectorInvert(int vector_)
{
	csAPI.csVectorInvert(vector_);
}

float csVectorLength(int vector_)
{
	return csAPI.csVectorLength(vector_);
}

float csVectorLengthSquared(int vector_)
{
	return csAPI.csVectorLengthSquared(vector_);
}

void csVectorMul(int vector_, int vector2_)
{
	csAPI.csVectorMul(vector_, vector2_);
}

void csVectorNormalize(int vector_)
{
	csAPI.csVectorNormalize(vector_);
}

void csVectorScale(int vector_, float scale_)
{
	csAPI.csVectorScale(vector_, scale_);
}

void csVectorSet(int vector_, float x_, float y_, float z_)
{
	csAPI.csVectorSet(vector_, x_, y_, z_);
}

void csVectorSub(int vector_, int vector2_)
{
	csAPI.csVectorSub(vector_, vector2_);
}

float csVectorX(int vector_)
{
	return csAPI.csVectorX(vector_);
}

float csVectorY(int vector_)
{
	return csAPI.csVectorY(vector_);
}

float csVectorZ(int vector_)
{
	return csAPI.csVectorZ(vector_);
}

