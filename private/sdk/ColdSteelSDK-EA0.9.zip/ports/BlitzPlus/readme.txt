Blitz3D/Plus import files for the ColdSteel SDK.

Usage:

1) Copy "coldsteel.decls" file to the "userlibs" folder of your Blitz3D or BlitzPlus installation.
2) Include "coldsteel.bb" file in all your programs
 That's all!

Remember to always have the "coldsteel.dll" file together with the exe of your programs!

Example program:

Include "coldsteel.bb"

csLibInit
csDisplayOpen 800, 600, 32, 0, 0
csDisplayClose
csLibFinish