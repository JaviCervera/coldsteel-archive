#ifndef _COLDSTEEL_H_
#define _COLDSTEEL_H_

#ifdef __cplusplus
extern "C" {
#endif

#define CSDFE_RENDERTOTEXTURE 0
#define CSDFE_BILINEARFILTER 1
#define CSDFE_HARDWARETNL 2
#define CSDFE_MIPMAP 3
#define CSDFE_STENCILBUFFER 4
#define CSDFE_VERTEXSHADER11 5
#define CSDFE_VERTEXSHADER20 6
#define CSDFE_VERTEXSHADER30 7
#define CSDFE_PIXELSHADER11 8
#define CSDFE_PIXELSHADER12 9
#define CSDFE_PIXELSHADER13 10
#define CSDFE_PIXELSHADER14 11
#define CSDFE_PIXELSHADER20 12
#define CSDFE_PIXELSHADER30 13
#define CSDFE_ARB_VERTEXPROGRAM1 14
#define CSDFE_ARB_FRAGMENTPROGRAM1 15
#define CSDF_FULLSCREEN 1
#define CSDF_VSYNC 2
#define CSDF_ANTIALIAS 4
#define CSDF_OPENGL 65536
#define CSEV_INIT 101
#define CSEV_FINISH 102
#define CSEV_FRAME 103
#define CSEV_DISPLAY_OPEN 201
#define CSEV_KEY_HIT 301
#define CSEV_KEY_RELEASE 302
#define CSEV_MOUSE_MOVE 401
#define CSEV_MOUSE_HIT 402
#define CSEV_MOUSE_RELEASE 403
#define CSMB_LEFT 1
#define CSMB_RIGHT 2
#define CSMB_MIDDLE 3
#define CSKEY_LBUTTON 0x01
#define CSKEY_RBUTTON 0x02
#define CSKEY_CANCEL 0x03
#define CSKEY_MBUTTON 0x04
#define CSKEY_XBUTTON1 0x05
#define CSKEY_XBUTTON2 0x06
#define CSKEY_BACK 0x08
#define CSKEY_TAB 0x09
#define CSKEY_CLEAR 0x0C
#define CSKEY_RETURN 0x0D
#define CSKEY_ENTER 0x0D
#define CSKEY_SHIFT 0x10
#define CSKEY_CONTROL 0x11
#define CSKEY_MENU 0x12
#define CSKEY_PAUSE 0x13
#define CSKEY_CAPITAL 0x14
#define CSKEY_KANA 0x15
#define CSKEY_HANGUEL 0x15
#define CSKEY_HANGUL 0x15
#define CSKEY_JUNJA 0x17
#define CSKEY_FINAL 0x18
#define CSKEY_HANJA 0x19
#define CSKEY_KANJI 0x19
#define CSKEY_ESC 0x1B
#define CSKEY_ESCAPE 0x1B
#define CSKEY_CONVERT 0x1C
#define CSKEY_NONCONVERT 0x1D
#define CSKEY_ACCEPT 0x1E
#define CSKEY_MODECHANGE 0x1F
#define CSKEY_SPACE 0x20
#define CSKEY_PRIOR 0x21
#define CSKEY_NEXT 0x22
#define CSKEY_END 0x23
#define CSKEY_HOME 0x24
#define CSKEY_LEFT 0x25
#define CSKEY_UP 0x26
#define CSKEY_RIGHT 0x27
#define CSKEY_DOWN 0x28
#define CSKEY_SELECT 0x29
#define CSKEY_PRINT 0x2A
#define CSKEY_EXECUT 0x2B
#define CSKEY_SNAPSHOT 0x2C
#define CSKEY_INSERT 0x2D
#define CSKEY_DELETE 0x2E
#define CSKEY_HELP 0x2F
#define CSKEY_0 0x30
#define CSKEY_1 0x31
#define CSKEY_2 0x32
#define CSKEY_3 0x33
#define CSKEY_4 0x34
#define CSKEY_5 0x35
#define CSKEY_6 0x36
#define CSKEY_7 0x37
#define CSKEY_8 0x38
#define CSKEY_9 0x39
#define CSKEY_A 0x41
#define CSKEY_B 0x42
#define CSKEY_C 0x43
#define CSKEY_D 0x44
#define CSKEY_E 0x45
#define CSKEY_F 0x46
#define CSKEY_G 0x47
#define CSKEY_H 0x48
#define CSKEY_I 0x49
#define CSKEY_J 0x4A
#define CSKEY_K 0x4B
#define CSKEY_L 0x4C
#define CSKEY_M 0x4D
#define CSKEY_N 0x4E
#define CSKEY_O 0x4F
#define CSKEY_P 0x50
#define CSKEY_Q 0x51
#define CSKEY_R 0x52
#define CSKEY_S 0x53
#define CSKEY_T 0x54
#define CSKEY_U 0x55
#define CSKEY_V 0x56
#define CSKEY_W 0x57
#define CSKEY_X 0x58
#define CSKEY_Y 0x59
#define CSKEY_Z 0x5A
#define CSKEY_LWIN 0x5B
#define CSKEY_RWIN 0x5C
#define CSKEY_APPS 0x5D
#define CSKEY_SLEEP 0x5F
#define CSKEY_NUMPAD0 0x60
#define CSKEY_NUMPAD1 0x61
#define CSKEY_NUMPAD2 0x62
#define CSKEY_NUMPAD3 0x63
#define CSKEY_NUMPAD4 0x64
#define CSKEY_NUMPAD5 0x65
#define CSKEY_NUMPAD6 0x66
#define CSKEY_NUMPAD7 0x67
#define CSKEY_NUMPAD8 0x68
#define CSKEY_NUMPAD9 0x69
#define CSKEY_MULTIPLY 0x6A
#define CSKEY_ADD 0x6B
#define CSKEY_SEPARATOR 0x6C
#define CSKEY_SUBTRACT 0x6D
#define CSKEY_DECIMAL 0x6E
#define CSKEY_DIVIDE 0x6F
#define CSKEY_F1 0x70
#define CSKEY_F2 0x71
#define CSKEY_F3 0x72
#define CSKEY_F4 0x73
#define CSKEY_F5 0x74
#define CSKEY_F6 0x75
#define CSKEY_F7 0x76
#define CSKEY_F8 0x77
#define CSKEY_F9 0x78
#define CSKEY_F10 0x79
#define CSKEY_F11 0x7A
#define CSKEY_F12 0x7B
#define CSKEY_F13 0x7C
#define CSKEY_F14 0x7D
#define CSKEY_F15 0x7E
#define CSKEY_F16 0x7F
#define CSKEY_F17 0x80
#define CSKEY_F18 0x81
#define CSKEY_F19 0x82
#define CSKEY_F20 0x83
#define CSKEY_F21 0x84
#define CSKEY_F22 0x85
#define CSKEY_F23 0x86
#define CSKEY_F24 0x87
#define CSKEY_NUMLOCK 0x90
#define CSKEY_SCROLL 0x91
#define CSKEY_LSHIFT 0xA0
#define CSKEY_RSHIFT 0xA1
#define CSKEY_LCONTROL 0xA2
#define CSKEY_RCONTROL 0xA3
#define CSKEY_LMENU 0xA4
#define CSKEY_RMENU 0xA5
#define CSKEY_COMMA 0xBC
#define CSKEY_PLUS 0xBB
#define CSKEY_MINUS 0xBD
#define CSKEY_PERIOD 0xBE
#define CSKEY_ATTN 0xF6
#define CSKEY_CRSEL 0xF7
#define CSKEY_EXSEL 0xF8
#define CSKEY_EREOF 0xF9
#define CSKEY_PLAY 0xFA
#define CSKEY_ZOOM 0xFB
#define CSKEY_PA1 0xFD
#define CSKEY_OEM_CLEAR 0xFE
#define CSMF_FULLBRIGHT 1
#define CSMF_FLATSHADING 2
#define CSMF_FOG 4
#define CSMF_NOCULL 8
#define CSMF_WIREFRAME 16
#define CSMF_NOZDEPTH 32
#define CSMF_NOZWRITE 64
#define CSMF_ANISOTROPIC 128
#define CSMT_MODULATE 1
#define CSMT_MODULATE2X 2
#define CSMT_MODULATE4X 3
#define CSMT_DETAIL 4
#define CSMT_ADD 5
#define CSMT_VERTEX_ALPHA 6
#define CSMT_ALPHA 7
#define CSMT_MASKED 8
#define CSMT_REFLECTION 9
#define CSMT_REFLECTION_ALPHA 10
#define CSMT_NORMAL 11
#define CSMT_PARALLAX 12
#define CSCI_NULL 0
#define CSCI_BBOX 1
#define CSCI_TRIANGLES 2
#define CSCI_OCTREE 3
#define CSNT_EMPTY 0
#define CSNT_BILLBOARD 1
#define CSNT_BODY 2
#define CSNT_CAMERA 3
#define CSNT_EMITTER 4
#define CSNT_LIGHT 5
#define CSNT_MESH 6
#define CSNT_MESH_OCTREE 7
#define CSNT_TERRAIN 8
#define CSNT_WATER 9
#define CSPT_POINT 0
#define CSPT_BOX 1
#define CSCF_BACKBUFFER 1
#define CSCF_ZBUFFER 2
#define CSTS_VIEW 0
#define CSTS_WORLD 1
#define CSTS_PROJECTION 2
#define CSPSF_11 0
#define CSPSF_12 1
#define CSPSF_13 2
#define CSPSF_14 3
#define CSPSF_20 4
#define CSPSF_2A 5
#define CSPSF_2B 6
#define CSPSF_30 7
#define CSVSF_11 0
#define CSVSF_20 1
#define CSVSF_2A 2
#define CSVSF_30 3
#define CSXML_NONE 0
#define CSXML_ELEMENT 1
#define CSXML_ELEMENTEND 2
#define CSXML_TEXT 3
#define CSXML_COMMENT 4
#define CSXML_UNKNOWN 5
void csCoreInit();
void csCoreFinish();
int csBillboardNode(int parent_);
void csBillboardResize(int billboard_, float width_, float height_);
float csBillboardWidth(int billboard_);
float csBillboardHeight(int billboard_);
int csCameraNode(int parent_);
void csCameraViewport(int cam_, float x1_, float y1_, float x2_, float y2_);
void csCameraRange(int cam_, float near_, float far_);
void csCameraFov(int cam_, float fov_);
void csCameraAspectRatio(int cam_, float ratio_);
void csCameraProjection(int cam_, float width_, float height_, float near_, float far_, int ortho_);
void csCameraLine(int cam_, int x_, int y_, int line_vec_start_, int line_vec_end_);
int csCameraPickNode(int cam_, int x_, int y_, int group_);
void csCameraToScreen(int cam_, float x_, float y_, float z_, int vec_out_);
void csCameraRenderTarget(int cam_, int texture_);
void csCollisionSlide(int node_, float pos_x_, float pos_y_, float pos_z_, float dest_x_, float dest_y_, float dest_z_, float rad_x_, float rad_y_, float rad_z_, int vec_pos_, int vec_tri_a_, int vec_tri_b_, int vec_tri_c_);
int csCollisionLinePick(int node_, float pos_x_, float pos_y_, float pos_z_, float dest_x_, float dest_y_, float dest_z_, int vec_pos_, int vec_tri_a_, int vec_tri_b_, int vec_tri_c_);
int csCollisionLineNode(float pos_x_, float pos_y_, float pos_z_, float dest_x_, float dest_y_, float dest_z_);
void csPackageAdd(const char* pak_);
int csDirList(const char* dir_);
void csDirClose(int dir_);
void csDirFileCount(int dir_);
const char* csDirFileName(int dir_, int index_);
int csDirFileIsDir(int dir_, int index_);
void csDisplayOpen(int width_, int height_, int depth_, int flags_, int win_);
void csDisplayClose();
void csDisplayCaption(const char* caption_);
int csDisplayClosed();
int csDisplayWidth();
int csDisplayHeight();
int csDisplayFps();
int csDisplayFeature(int feature_);
void csDisplayResize(int width_, int height_);
int csDisplayActive();
int csGetColor(int red_, int green_, int blue_, int alpha_);
int csGetRed(int color_);
int csGetGreen(int color_);
int csGetBlue(int color_);
int csGetAlpha(int color_);
void csSetColor(int color_);
void csViewport(int x_, int y_, int w_, int h_);
void csDrawLine(int x_, int y_, int x1_, int y1_);
void csDrawRect(int x_, int y_, int w_, int h_);
void csDrawTexture(int tex_, int x_, int y_);
void csDrawText(int font_, const char* text_, int x_, int y_);
int csTextWidth(int font_, const char* text_);
int csTextHeight(int font_, const char* text_);
int csEffectRegister(const char* effect_, int base_mat_);
int csEffectRegisterFile(const char* effect_file_, int base_mat_);
void csEffectSetTechnique(int effect_, const char* technique_);
void csEffectSetTexture(int effect_, const char* var_name_, int texture_);
void csEffectSetBool(int effect_, const char* var_name_, int value_);
void csEffectSetInt(int effect_, const char* var_name_, int value_);
void csEffectSetFloat(int effect_, const char* var_name_, float value_);
void csEffectSetVector(int effect_, const char* var_name_, int vector_);
void csEffectSetMatrix(int effect_, const char* var_name_, int matrix_);
int csEmitterNode(int particle_data_, int parent_);
void csEmitterAddFadeOutAffector(int emitter_, int color_, int time_);
void csEmitterAddGravityAffector(int emitter_, float grav_x_, float grav_y_, float grav_z_, int time_);
void csEmitterRemoveAffectors(int emitter_);
int csEventGet();
int csEventPoll();
void csEventPost(int id_, int from_, int to_, float a_, float b_, float c_, const char* str_);
int csEventId();
int csEventFrom();
int csEventTo();
float csEventA();
float csEventB();
float csEventC();
const char* csEventData();
int csFileRead(const char* file_);
int csFileWrite(const char* file_);
void csFileClose(int file_);
int csFileSize(int file_);
int csFilePos(int file_);
void csFileSeek(int file_, int pos_, int relative_);
int csFileReadByte(int file_);
int csFileReadShort(int file_);
int csFileReadInt(int file_);
float csFileReadFloat(int file_);
const char* csFileReadString(int file_);
void csFileReadBytes(int file_, int buf_, int size_);
void csFileWriteByte(int file_, int value_);
void csFileWriteShort(int file_, int value_);
void csFileWriteInt(int file_, int value_);
void csFileWriteFloat(int file_, float value_);
void csFileWriteString(int file_, const char* str_);
void csFileWriteBytes(int file_, int buf_, int size_);
int csFontLoad(const char* file_);
void csFontFree(int font_);
void csMousePosition(int x_, int y_);
void csMouseHide(int hide_);
int csMouseX();
int csMouseY();
int csMouseHit(int button_);
int csMouseDown(int button_);
int csMouseGet();
int csMouseReleased();
int csKeyHit(int key_);
int csKeyDown(int key_);
int csKeyGet();
int csKeyReleased();
const char* csJoyName(int id_);
int csJoyButton(int id_, int button_);
float csJoyAxis(int id_, int axis_);
int csJoyNumAxes(int id_);
int csLightNode(int parent_);
void csLightRadius(int light_, float radius_);
void csLightAmbient(int light_, int color_);
void csLightDiffuse(int light_, int color_);
void csLightSpecular(int light_, int color_);
int csMaterialCreate(const char* name_);
int csMaterialLoad(const char* file_);
void csMaterialSave(int mat_, const char* file_, const char* rel_path_);
void csMaterialFree(int mat_);
int csMaterialFind(const char* name_);
void csMaterialSetType(int mat_, int newtype_);
void csMaterialSetFlags(int mat_, int flags_);
void csMaterialSetTexture(int mat_, int tex_, int layer_);
void csMaterialSetAmbient(int mat_, int color_);
void csMaterialSetDiffuse(int mat_, int color_);
void csMaterialSetEmissive(int mat_, int color_);
void csMaterialSetSpecular(int mat_, int color_);
void csMaterialSetShininess(int mat_, float shininess_);
void csMaterialSetParam(int mat_, float param_);
const char* csMaterialGetName(int mat_);
int csMaterialGetType(int mat_);
int csMaterialGetFlags(int mat_);
int csMaterialGetTexture(int mat_, int layer_);
int csMaterialGetAmbient(int mat_);
int csMaterialGetDiffuse(int mat_);
int csMaterialGetEmissive(int mat_);
int csMaterialGetSpecular(int mat_);
float csMaterialGetShininess(int mat_);
float csMaterialGetParam(int mat_);
float csMathFloor(float val_);
float csMathCeil(float val_);
float csMathAbs(float val_);
float csMathSqr(float val_);
float csMathSin(float val_);
float csMathCos(float val_);
float csMathTan(float val_);
float csMathASin(float val_);
float csMathACos(float val_);
float csMathATan(float val_);
float csMathATan2(float x_, float y_);
float csMathExp(float val_);
float csMathLog(float val_);
float csMathLog10(float val_);
int csMathRand(int min_, int max_);
void csMathRandSeed(int seed_);
int csMatrixCreate();
void csMatrixFree(int matrix_);
void csMatrixAdd(int matrix_, int matrix2_);
void csMatrixCopy(int matrix_, int matrix2_);
void csMatrixDiv(int matrix_, int matrix2_);
float csMatrixElement(int matrix_, int row_, int column_);
int csMatrixEqual(int matrix_, int matrix2_);
void csMatrixGetRotation(int matrix_, int vector_);
void csMatrixGetTranslation(int matrix_, int vector_);
void csMatrixIdentity(int matrix_);
void csMatrixInterpolate(int matrix_, int matrix2_, float time_);
int csMatrixInvert(int matrix_);
void csMatrixMul(int matrix_, int matrix2_);
void csMatrixSet(int matrix_, int row_, int column_, float val_);
void csMatrixSetRotation(int matrix_, int vector_);
void csMatrixSetScale(int matrix_, int vector_);
void csMatrixSetTranslation(int matrix_, int vector_);
void csMatrixSub(int matrix_, int matrix2_);
void csMatrixTranspose(int matrix_);
int csMeshLoad(const char* file_);
int csMeshTerrainLoad(const char* heightmap_);
void csMeshFree(int mesh_);
int csMeshNode(int mesh_, int parent_, int col_info_, int tangent_mesh_);
int csMeshOctreeNode(int mesh_, int parent_, int col_info_, int tangent_mesh_);
void csMeshScale(int mesh_, float sx_, float sy_, float sz_);
void csMeshFlip(int mesh_);
void csMeshUpdateNormals(int mesh_);
void csMeshVerticesColor(int mesh_, int color_, int change_alpha_);
void csMeshPlanarMapping(int mesh_, float resolution_);
float csMeshWidth(int mesh_);
float csMeshHeight(int mesh_);
float csMeshDepth(int mesh_);
int csNodeEmpty(int parent_);
void csNodeFree(int node_);
int csNodeType(int node_);
void csNodeSetName(int node_, const char* name_);
const char* csNodeGetName(int node_);
void csNodePosition(int node_, float x_, float y_, float z_);
void csNodeMove(int node_, float x_, float y_, float z_);
void csNodeRotate(int node_, float pitch_, float yaw_, float roll_);
void csNodeTurn(int node_, float pitch_, float yaw_, float roll_);
void csNodeScale(int node_, float x_, float y_, float z_);
float csNodeX(int node_, int absolute_);
float csNodeY(int node_, int absolute_);
float csNodeZ(int node_, int absolute_);
float csNodePitch(int node_);
float csNodeYaw(int node_);
float csNodeRoll(int node_);
float csNodeScaleX(int node_);
float csNodeScaleY(int node_);
float csNodeScaleZ(int node_);
float csNodeWidth(int node_);
float csNodeHeight(int node_);
float csNodeDepth(int node_);
void csNodeCastShadow(int node_, int cast_);
void csNodeHide(int node_, int state_);
int csNodeMaterials(int node_);
int csNodeGetMaterial(int node_, int mat_index_);
void csNodeSetMaterial(int node_, int mat_, int mat_index_);
void csNodeSetMaterialFast(int node_, int index_, int type_, int flags_, int tex1_, int tex2_);
void csNodeSetPickGroup(int n_, int group_);
void csNodeSetProperty(int node_, const char* name_, const char* value_);
int csNodeProperties(int node_);
int csNodeFindProperty(int node_, const char* name_);
const char* csNodePropertyName(int node_, int index_);
const char* csNodePropertyValue(int node_, int index_);
void csNodeRemoveProperty(int node_, int index_);
void csNodeSetParent(int node_, int parent_);
int csNodeGetParent(int node_);
int csNodeChildren(int node_);
int csNodeChild(int node_, int index_);
int csNodeFindChild(int node_, const char* name_, int recursive_);
void csNodeSpeed(int node_, int fps_);
void csNodeLoop(int node_, int loop_);
void csNodeSetFrame(int node_, int start_, int finish_);
int csNodeGetFrame(int node_);
void csNodeAttachToBone(int n_, int n2_, const char* bonename_);
void csNodeLookAt(int node_, float x_, float y_, float z_);
int csParticleDataCreate(const char* name_);
int csParticleDataLoad(const char* file_);
void csParticleDataSave(int part_data_, const char* file_);
void csParticleDataFree(int part_data_);
int csParticleDataFind(const char* name_);
void csParticleDataSetMaterial(int part_data_, const char* mat_name_);
void csParticleDataSetType(int part_data_, int type_);
void csParticleDataSetBox(int part_data_, float width_, float height_, float depth_);
void csParticleDataSetDirection(int part_data_, float x_, float y_, float z_);
void csParticleDataSetRate(int part_data_, int min_, int max_);
void csParticleDataSetColor(int part_data_, int min_, int max_);
void csParticleDataSetLifeTime(int part_data_, int min_, int max_);
void csParticleDataSetMaxAngle(int part_data_, int angle_);
void csParticleDataSetSize(int part_data_, float width_, float height_);
void csParticleDataAddFadeOutAffector(int part_data_, int color_, int time_);
void csParticleDataAddGravityAffector(int part_data_, float grav_x_, float grav_y_, float grav_z_, int time_);
const char* csParticleDataGetName(int part_);
const char* csParticleDataGetMaterial(int part_);
int csParticleDataGetType(int part_);
float csParticleDataGetBoxWidth(int part_);
float csParticleDataGetBoxHeight(int part_);
float csParticleDataGetBoxDepth(int part_);
float csParticleDataGetDirectionX(int part_);
float csParticleDataGetDirectionY(int part_);
float csParticleDataGetDirectionZ(int part_);
int csParticleDataGetMinRate(int part_);
int csParticleDataGetMaxRate(int part_);
int csParticleDataGetMinColor(int part_);
int csParticleDataGetMaxColor(int part_);
int csParticleDataGetMinLifeTime(int part_);
int csParticleDataGetMaxLifeTime(int part_);
int csParticleDataGetMaxAngle(int part_);
float csParticleDataGetWidth(int part_);
float csParticleDataGetHeight(int part_);
int csParticleDataAffectors(int part_);
int csParticleDataGetAffectorType(int part_, int index_);
int csParticleDataGetAffectorColor(int part_, int index_);
int csParticleDataGetAffectorTime(int part_, int index_);
float csParticleDataGetAffectorGravityX(int part_, int index_);
float csParticleDataGetAffectorGravityY(int part_, int index_);
float csParticleDataGetAffectorGravityZ(int part_, int index_);
void csSceneBegin(int clear_flags_, int color_);
void csSceneEnd();
void csSceneRender(int camera_);
void csSceneAmbient(int color_);
void csSceneFog(int color_, float near_, float far_);
void csSceneSkybox(int top_, int bottom_, int left_, int right_, int front_, int back_);
void csSceneTransformation(int state_, int matrix_);
int csShaderRegister(const char* pixel_shader_, const char* pixel_entry_, int pixel_format_, const char* vertex_shader_, const char* vertex_entry_, int vertex_format_, int base_mat_);
int csShaderRegisterFile(const char* pixel_file_, const char* pixel_entry_, int pixel_format_, const char* vertex_file_, const char* vertex_entry_, int vertex_format_, int base_mat_);
int csShaderAsmRegister(const char* pixel_shader_, const char* vertex_shader_, int base_material_);
int csShaderAsmRegisterFile(const char* pixel_file_, const char* vertex_file_, int base_mat_);
void csShaderPixelConstant(int shader_, const char* name_, int start_register_, int data_, int count_);
void csShaderVertexConstant(int shader_, const char* name_, int start_register_, int data_, int count_);
int csStringToInt(const char* str_);
float csStringToFloat(const char* str_);
const char* csStringFromInt(int number_);
const char* csStringFromFloat(float number_);
const char* csStringLeft(const char* str_, int number_);
const char* csStringRight(const char* str_, int num_);
const char* csStringMid(const char* str_, int pos_, int num_);
const char* csStringReplace(const char* str_, const char* find_, const char* replace_);
int csStringFind(const char* str_, const char* find_, int offset_);
const char* csStringUpper(const char* str_);
const char* csStringLower(const char* str_);
const char* csStringTrim(const char* str_);
const char* csStringChar(int ascii_);
int csStringAscii(const char* str_);
int csStringLen(const char* str_);
const char* csStringField(const char* str_, const char* delimiter_, int index_);
int csTerrainNode(const char* heightmap_, int parent_, float width_, float height_, float depth_, int col_info_);
void csTerrainScaleTexture(int terrain_, float scale1_, float scale2_);
int csTextureCreate(int width_, int height_);
int csTextureTargetCreate(int width_, int height_);
int csTextureLoad(const char* file_, int mipmaps_);
void csTextureFree(int tex_);
const char* csTextureFile(int tex_);
int csTextureWidth(int tex_, int original_);
int csTextureHeight(int tex_, int original_);
int csTextureLock(int tex_);
void csTextureUnlock(int tex_);
void csTextureColorKey(int tex_, int color_);
void csTextureNormalize(int tex_, float amplitude_);
int csTextureHWPointer(int tex_);
int csVectorCreate();
void csVectorFree(int vector_);
void csVectorAdd(int vector_, int vector2_);
void csVectorAddScale(int vector_, int vector2_, float scale_);
int csVectorBetween(int vector_, float x0_, float y0_, float z0_, float x1_, float y1_, float z1_);
void csVectorCopy(int vector_, int other_vector_);
void csVectorCrossProduct(int vector_, int vector2_);
float csVectorDotProduct(int vector_, int other_vector_);
int csVectorEqual(int vector_, int other_vector_, float epsilon_);
float csVectorDistance(int vector_, float x_, float y_, float z_);
float csVectorDistanceSquared(int vector_, float x_, float y_, float z_);
void csVectorDiv(int vector_, int vector2_);
void csVectorInterpolate(int vector_, int vector2_, float d_);
void csVectorInvert(int vector_);
float csVectorLength(int vector_);
float csVectorLengthSquared(int vector_);
void csVectorMul(int vector_, int vector2_);
void csVectorNormalize(int vector_);
void csVectorScale(int vector_, float scale_);
void csVectorSet(int vector_, float x_, float y_, float z_);
void csVectorSub(int vector_, int vector2_);
float csVectorX(int vector_);
float csVectorY(int vector_);
float csVectorZ(int vector_);
int csXMLRead(const char* file_);
int csXMLWrite(const char* file_);
void csXMLClose(int xml_);
int csXMLReadNode(int xml_);
int csXMLNodeType(int xml_);
const char* csXMLNodeName(int xml_);
const char* csXMLNodeData(int xml_);
int csXMLAttributeCount(int xml_);
const char* csXMLAttributeName(int xml_, int index_);
const char* csXMLAttributeValue(int xml_, int index_);
void csXMLWriteHeader(int xml_);
void csXMLWriteElement(int xml_, const char* name_, const char* attributes_, int empty_);
void csXMLWriteClosingTag(int xml_, const char* name_);
void csXMLWriteText(int xml_, const char* text_);
void csXMLWriteLineBreak(int xml_);

#ifdef __cplusplus
}
#endif

#endif // _COLDSTEEL_H_
