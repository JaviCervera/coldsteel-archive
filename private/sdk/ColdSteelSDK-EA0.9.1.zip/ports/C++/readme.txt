C++ import files for the ColdSteel SDK.

Usage:

1) Add the files "coldsteel.c" and "coldsteel.h" to your Win32 project. It works in both C and C++ projects.
 That's all!

Remember to always have the "coldsteel.dll" file together with the exe of your programs!

Example program:

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "coldsteel.h"

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
  csLibInit();
  csDisplayOpen(800, 600, 32, false, false);
  csDisplayClose();
  csLibFinish();
  return 0;
}