#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <time.h>
#include "coldsteel.h"

float secs()
{
  return (float) clock() / CLOCKS_PER_SEC;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
  //Init lib (by now user and serial are not required)
  csLibInit();
  
  //Display
  csDisplayOpen(800, 600, 32, CSDF_OPENGL, false);
  csDisplayCaption("ColdSteel Temple Example - C++");
  csMouseHide(true);
  
  //Ambient light
  csSceneAmbient(csGetColor(255, 255, 255, 255));

  //Fog
  csSceneFog(csGetColor(0,20,20,120), 0, 12500);

  //Load skybox
  int top = csTextureLoad("../../media/skybox/rocky_up.jpg", true);
  int bottom = csTextureLoad("../../media/skybox/rocky_dn.jpg", true);
  int left = csTextureLoad("../../media/skybox/rocky_lf.jpg", true);
  int right = csTextureLoad("../../media/skybox/rocky_rt.jpg", true);
  int front = csTextureLoad("../../media/skybox/rocky_ft.jpg", true);
  int back = csTextureLoad("../../media/skybox/rocky_bk.jpg", true);
  csSceneSkybox(top, bottom, left, right, front, back);

  //Load map
  csSceneTexturePath("../../media/maps/temple01/");
  int mesh = csMeshLoad("../../media/maps/temple01/temple01.my3d");
  int map = csMeshOctreeNode(mesh, false, CSCI_OCTREE, false);
  csMeshFree(mesh);

  //Load skydome
  int texture = csTextureLoad("../../media/textures/clouds.jpg", true);
  mesh = csMeshLoad("../../media/models/skydome.my3d");
  int skydome = csMeshNode(mesh, false, CSCI_NULL, false);
  csNodeSetMaterialFast(skydome, 0, CSMT_ADD, CSMF_FULLBRIGHT, texture, false);
  csMeshFree(mesh);

  //Load particles
  texture = csTextureLoad("../../media/textures/particle_white.bmp", true);
  int pdata = csParticleDataCreate("flare");
  csParticleDataSetType(pdata, CSPT_BOX);
  csParticleDataSetBox(pdata, 14, 1, 14);
  csParticleDataSetDirection(pdata, 0, 0.03, 0);
  csParticleDataSetRate(pdata, 60, 200);
  csParticleDataSetColor(pdata, csGetColor(0,255,255,100), csGetColor(0,0,255,0));
  csParticleDataSetLifeTime(pdata, 100, 3400);
  csParticleDataSetMaxAngle(pdata, 108);
  csParticleDataSetSize(pdata, 300, 300);
  int emitter = csEmitterNode(pdata, 0);
  csEmitterAddFadeOutAffector(emitter, 0, 1000);
  csEmitterAddGravityAffector(emitter, 0, 0.3, 0, 2400);
  csNodeSetMaterialFast(emitter, 0, CSMT_ADD, CSMF_FULLBRIGHT, texture, false);
  csNodePosition(emitter, -5200, 850, 2000);
  csNodeScale(emitter, 50, 50, 50);

  //Create sun billboard
  int sun = csBillboardNode(false);
  csBillboardResize(sun, 30000, 30000);
  csNodeSetMaterialFast(sun, 0, CSMT_ADD, CSMF_FULLBRIGHT, texture, false);
  csNodePosition(sun, 25000, 25000, 0);

  //Create camera
  int cam = csCameraNode(false);
  csCameraRange(cam, 1, 50000);
  csCameraFov(cam, 1.1);
  csNodePosition(cam, 240, 305, 2150);
  csNodeRotate(cam, 0, 90, 0);

  //Move mouse to screen center
  csMousePosition(csDisplayWidth()/2, csDisplayHeight()/2);
  int mx = csMouseX();
  int my = csMouseY();
  int mxs = 0;
  int mys = 0;
  
  float lastframe = secs();
  int vec_out = csVectorCreate();
  float oldcamx, oldcamy, oldcamz;
  while (!csKeyHit(CSKEY_ESC))
  {
    float frametime = secs() - lastframe;
    lastframe = secs();
    float elapsed = frametime;

    //Check if we must exit
    if (csDisplayClosed()) break;

    //Get mouse movement
    mxs = csMouseX() - mx;
    mys = csMouseY() - my;
    csMousePosition(csDisplayWidth()/2, csDisplayHeight()/2);
    mx = csMouseX(); my = csMouseY();

    //Rotate camera
    float pitch = csNodePitch(cam) + (mys * 0.4);
    if (pitch < -80) pitch = -80;
    if (pitch > 80) pitch = 80;
    csNodeRotate(cam, pitch, csNodeYaw(cam) + (mxs * 0.4), 0);

    //Move camera
	oldcamx = csNodeX(cam, false);
	oldcamy = csNodeY(cam, false);
	oldcamz = csNodeZ(cam, false);
    if (csKeyDown(CSKEY_UP)) csNodeMove(cam, 0, 0, 512 * elapsed);
    if (csKeyDown(CSKEY_DOWN)) csNodeMove(cam, 0, 0, -512 * elapsed);
    if (csKeyDown(CSKEY_LEFT)) csNodeMove(cam, -512 * elapsed, 0, 0);
    if (csKeyDown(CSKEY_RIGHT)) csNodeMove(cam, 512 * elapsed, 0, 0);
    csNodePosition(cam, csNodeX(cam,false), csNodeY(cam,false) - (512 * elapsed), csNodeZ(cam,false));
	csCollisionSlide(map, oldcamx, oldcamy, oldcamz, csNodeX(cam, false), csNodeY(cam, false), csNodeZ(cam, false), 32, 128, 32, vec_out, 0, 0, 0);
	csNodePosition(cam, csVectorX(vec_out), csVectorY(vec_out), csVectorZ(vec_out));

    //Rotate skydome
    csNodeTurn(skydome, 0, 3 * elapsed, 0);

    csSceneBegin(CSCF_BACKBUFFER | CSCF_ZBUFFER, csGetColor(0, 0, 0, 0));
    csSceneRender(cam);
    csSceneEnd();
  }
  
  csVectorFree(vec_out);

  csDisplayClose();
  csLibFinish();
  return 0;
}
