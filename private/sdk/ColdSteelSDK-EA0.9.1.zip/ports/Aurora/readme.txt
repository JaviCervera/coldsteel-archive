Aurora import files for the ColdSteel SDK.

Usage:

1) Copy "coldsteel.inc" to the "bin" folder of Aurora.
2) Copy "coldsteel.lib" to the "libs" folder of Aurora.
 That's all!

Remember to always have the "coldsteel.dll" file together with the exe of your programs!

Example program:

global sub main()
{ 
	csLibInit();
	csDisplayOpen(800, 600, 32, 0, 0) ;
	csDisplayClose();
	csLibFinish();
}