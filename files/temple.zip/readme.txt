This techdemo has been made with a beta version of ColdSteel Pro.
Please do not redistribute it.

Programming by Javier "Jedive" San Juan.
Graphics by Alvaro F. Celis.

www.coldsteelengine.com